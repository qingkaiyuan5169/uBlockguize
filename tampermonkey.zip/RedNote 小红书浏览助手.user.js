// ==UserScript==
// @name               RedNote 小红书浏览助手
// @name:zh-CN         RedNote 小红书浏览助手
// @name:en            RedNote Enhancer Tools
// @description        增强功能：查看封面、复制文案、无水印视频下载、用户主页作品批量下载和导出。
// @description:zh-CN  增强功能：查看封面、复制文案、无水印视频下载、用户主页作品批量下载和导出。
// @description:en     Enhanced Features: View Cover, Copy Caption, NO Watermark Video Download, Batch Download and Export from User Profile.
// @namespace          https://www.runningcheese.com/userscripts
// @author             RunningCheese
// @version            1.6
// @match              https://www.xiaohongshu.com/*
// @icon               https://www.xiaohongshu.com/favicon.ico
// @grant              GM_addStyle
// @grant              GM_setValue
// @grant              GM_getValue
// @grant              GM_registerMenuCommand
// @grant              unsafeWindow
// @require            https://cdnjs.cloudflare.com/ajax/libs/jszip/3.9.1/jszip.min.js
// @license            MIT
// @downloadURL https://update.greasyfork.org/scripts/463750/RedNote%20%E5%B0%8F%E7%BA%A2%E4%B9%A6%E6%B5%8F%E8%A7%88%E5%8A%A9%E6%89%8B.user.js
// @updateURL https://update.greasyfork.org/scripts/463750/RedNote%20%E5%B0%8F%E7%BA%A2%E4%B9%A6%E6%B5%8F%E8%A7%88%E5%8A%A9%E6%89%8B.meta.js
// ==/UserScript==

(function() {
    'use strict';

    let ttPolicy;
    if (window.trustedTypes && window.trustedTypes.createPolicy) {
        try {
            ttPolicy = window.trustedTypes.createPolicy('xhs-assistant-' + Math.random().toString(36).substring(2, 9), {
                createHTML: (string) => string
            });
        } catch (e) {
            ttPolicy = { createHTML: (string) => string };
        }
    } else {
        ttPolicy = { createHTML: (string) => string };
    }

    // 简化的元素创建工具
    const elements = {
        createAs(nodeType, config, appendTo) {
            const element = document.createElement(nodeType);
            if (config) {
                Object.entries(config).forEach(([key, value]) => {
                    if (key === 'innerHTML') {
                        element.innerHTML = ttPolicy.createHTML(value);
                    } else {
                        element[key] = value;
                    }
                });
            }
            if (appendTo) appendTo.appendChild(element);
            return element;
        },
        getAs(selector) {
            return document.body.querySelector(selector);
        }
    };

    // 创建预览图片元素
    const preview = elements.createAs("img", {
        id: "preview",
        style: `
            position: fixed;
            z-index: 1000000000;
            max-width: 50vw;
            max-height: 70vh;
            border: 2px solid #fff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            display: none;
            object-fit: contain;
            background-color: #f8f8f8;
        `
    }, document.body);

    // 添加点击事件监听器
    preview.addEventListener('click', function() {
        this.style.display = 'none';
    });

    // 点击网页其他区域时关闭缩略图
    document.addEventListener('click', function(e) {
        if (e.target.closest('#preview') || e.target.closest('#xhs-thumbnail-btn')) {
            return;
        }
        preview.style.display = 'none';
    });

    // 添加CSS样式
    const style = elements.createAs('style', {
        textContent: `
            .xhs-icon-btn {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                cursor: pointer;
                transition: background-color 0.3s, transform 0.2s;
                background-color: #ff2442;
                color: white;
                box-shadow: 0 4px 10px rgba(255, 36, 66, 0.3);
                text-decoration: none;
            }

            .xhs-icon-btn:hover {
                background-color: #e0203a;
                transform: scale(1.05);
            }

            .xhs-icon-btn svg {
                width: 20px;
                height: 20px;
                fill: currentColor;
            }
        `
    }, document.head);

    // 小红书浏览助手主体
    const xhsViewer = {
        buttonAdded: false,
        buttonCheckInterval: null,

        // 检查是否在笔记页面
        isNotePage() {
            return /^https:\/\/www\.xiaohongshu\.com\/explore\/(.*)$/.test(window.location.href);
        },

        // 获取小红书封面/图片URL
        getThumbnailUrl() {
            // 1. 尝试获取视频封面
            const video = document.querySelector('.media-container video') || document.querySelector('video');
            if (video && video.poster) {
                return video.poster;
            }

            // 2. 尝试获取图片笔记的第一张图或当前激活的图
            const activeImg = document.querySelector('.note-slider .swiper-slide-active .slider-img') || document.querySelector('.media-container .slider-img');
            if (activeImg && activeImg.style.backgroundImage) {
                const match = activeImg.style.backgroundImage.match(/url\(["']?(.*?)["']?\)/);
                if (match && match[1]) {
                    return match[1];
                }
            }

            // 3. 从 __INITIAL_STATE__ 中提取封面图（最可靠）
            try {
                const noteData = this.extractNoteInfo(window.location.href);
                if (noteData) {
                    // 视频笔记：从 video.media 中取封面
                    if (noteData.type === "video" && noteData.video) {
                        const cover = noteData.video.media?.image?.urlDefault || noteData.video.media?.image?.url;
                        if (cover) return cover;
                    }
                    // 图片笔记：取第一张图作为封面
                    if (noteData.imageList && noteData.imageList.length > 0) {
                        const url = noteData.imageList[0].urlDefault || noteData.imageList[0].url;
                        if (url) return url;
                    }
                }
            } catch (e) {
                console.error('从 __INITIAL_STATE__ 提取封面失败:', e);
            }

            // 4. 尝试获取 meta 标签中的分享图（初始加载有效）
            const meta = document.querySelector('meta[property="og:image"], meta[name="og:image"]');
            if (meta && meta.content) {
                return meta.content;
            }

            return null;
        },

        // 复制笔记文案
        copyText() {
            const titleEl = document.querySelector('.title') || document.querySelector('#detail-title') || document.querySelector('.note-content .title');
            const descEl = document.querySelector('.desc') || document.querySelector('#detail-desc') || document.querySelector('.note-content .desc');

            let text = '';
            if (titleEl) text += titleEl.textContent.trim() + '\n\n';
            if (descEl) text += descEl.textContent.trim();

            if (text) {
                navigator.clipboard.writeText(text).then(() => {
                    this.showToast('文案已复制到剪贴板！');
                }).catch(err => {
                    console.error('复制失败:', err);
                    this.showToast('复制文案失败，请允许剪贴板权限');
                });
            } else {
                this.showToast('未找到文案内容');
            }
        },

        // 下载相关方法
        detailUrlPattern: {
            "xiaohongshu": /http:\/\/sns-webpic-qc\.xhscdn\.com\/\d+\/[0-9a-z]+\/(\S+)!/,
            "rednote": /http:\/\/sns-web-i10\.rednotecdn\.com\/\d+\/[0-9a-z]+\/(\S+)!/
        },

        generateVideoUrl(note) {
            try {
                const links = [];
                // 优先使用原片链接
                const originKey = note.video?.consumer?.originVideoKey;
                if (originKey) links.push(`https://sns-video-bd.xhscdn.com/${originKey}`);

                // 遍历所有编码类型（h265/av1 等）的所有清晰度
                const renditions = Object.values(note.video?.media?.stream || {})
                    .flat()
                    .filter(Boolean)
                    .map(s => ({ url: s.backupUrls?.[0] || s.masterUrl, height: s.height }))
                    .filter(s => s.url);

                // 按清晰度从高到低排序
                renditions.sort((a, b) => (b.height ?? 0) - (a.height ?? 0));
                links.push(...renditions.map(s => s.url));
                return links;
            } catch (error) {
                console.error("提取视频链接失败:", error);
                return [];
            }
        },

        generateImageUrl(note, currentSite) {
            let images = note.imageList;
            const regex = this.detailUrlPattern[currentSite];
            let urls = [];
            try {
                images.forEach((item) => {
                    const url = item.urlDefault || item.url;
                    let match = url.match(regex);
                    if (match && match[1]) {
                        urls.push(`https://ci.xiaohongshu.com/${match[1]}?imageView2/format/jpeg`);
                    }
                })
                return urls;
            } catch (error) {
                console.error("提取图片链接失败:", error);
                return [];
            }
        },

        extractImageWebpUrls(note, urls) {
            try {
                let items = [];
                let {imageList} = note;
                if (urls.length !== imageList.length) {
                    console.error("图片数量不一致！");
                    return [];
                }
                for (const [index, item] of imageList.entries()) {
                    const url = item.urlDefault || item.url;
                    if (url) {
                        items.push({
                            webp: url, index: index + 1, url: urls[index]
                        });
                    } else {
                        console.error("提取图片预览链接失败", item);
                        break;
                    }
                }
                return items;
            } catch (error) {
                console.error("生成图片对象时发生错误:", error);
                return [];
            }
        },

        triggerDownload(name, blob) {
            const blobUrl = URL.createObjectURL(blob);
            const tempLink = document.createElement("a");
            tempLink.href = blobUrl;
            tempLink.download = name;
            document.body.appendChild(tempLink);
            tempLink.click();
            document.body.removeChild(tempLink);
            URL.revokeObjectURL(blobUrl);
        },

        async downloadFile(link, name, trigger = true, retries = 5) {
            for (let attempt = 1; attempt <= retries; attempt++) {
                try {
                    const response = await fetch(link, {
                        "headers": {
                            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
                            "accept-language": "zh-SG,zh;q=0.9",
                        }, "method": "GET", "referrerPolicy": "no-referrer",
                    });
                    if (!response.ok) continue;
                    const blob = await response.blob();
                    if (trigger) {
                        this.triggerDownload(name, blob);
                        return true;
                    } else {
                        return blob;
                    }
                } catch (error) {
                    if (attempt === retries) return false;
                }
            }
            return false;
        },

        async downloadFiles(items, name) {
            const downloadResults = [];
            const downloadPromises = items.map(async (item) => {
                let fileName = item.index ? `${name}_${item.index}.jpeg` : `${name}.jpeg`;
                const result = await this.downloadFile(item.url, fileName, false);
                if (result) {
                    downloadResults.push({name: fileName, file: result});
                    return true;
                }
                return false;
            });

            const results = await Promise.all(downloadPromises);
            if (results.every(result => result === true)) {
                try {
                    if (typeof JSZip === 'undefined') {
                        this.showToast("JSZip 库加载失败，无法打包下载文件！");
                        return false;
                    }
                    const zip = new JSZip();
                    downloadResults.forEach((item) => {
                        zip.file(item.name, item.file);
                    });
                    const content = await zip.generateAsync({type: "blob", compression: "STORE"});
                    this.triggerDownload(`${name}.zip`, content);
                    return true;
                } catch (error) {
                    console.error('生成 ZIP 文件失败:', error);
                    return false;
                }
            }
            return false;
        },

        truncateString(str, maxLength) {
            if (str.length > maxLength) {
                const halfLength = Math.floor(maxLength / 2) - 1;
                return str.slice(0, halfLength) + '...' + str.slice(-halfLength);
            }
            return str;
        },

        extractName(currentUrl) {
            let name = document.title.replace(/ - 小红书$/, "").replace(/ - RedNote$/, "")
                               .replace(/[^\u4e00-\u9fa5a-zA-Z0-9 ~!@#$%&()_\-+=\[\];"',.！（）【】：“”，。《》？]/g, "");
            name = this.truncateString(name, 64);
            let match = currentUrl.match(/\/([0-9a-z]+?)\?/);
            let id = match ? match[1] : null;
            return name === "" ? (id || "download") : name;
        },

        extractNoteInfo(currentUrl) {
            const _window = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;
            const data = _window.__INITIAL_STATE__?.noteData?.data?.noteData;
            if (data) return data;
            const regex = /\/explore\/([^?]+)/;
            const match = currentUrl.match(regex);
            if (match && _window.__INITIAL_STATE__?.note?.noteDetailMap) {
                return _window.__INITIAL_STATE__.note.noteDetailMap[match[1]]?.note;
            }
            return null;
        },

        async exploreDeal(note, currentSite, currentUrl) {
            try {
                let links = note.type === "normal" ? this.generateImageUrl(note, currentSite) : this.generateVideoUrl(note);
                if (links.length > 0) {
                    const name = this.extractName(currentUrl);
                    this.showToast("正在下载文件，请稍候...");
                    if (note.type === "video") {
                        let success = false;
                        for (const link of links) {
                            success = await this.downloadFile(link, `${name}.mp4`);
                            if (success) break;
                        }
                        if (!success) this.showToast("下载视频失败！");
                    } else {
                        let items = this.extractImageWebpUrls(note, links);
                        if (items.length === 0) {
                            this.showToast("解析图片数据失败！");
                        } else if (items.length === 1) {
                            let success = await this.downloadFile(items[0].url, `${name}.jpeg`);
                            if (!success) this.showToast("下载图片失败！");
                        } else {
                            let success = await this.downloadFiles(items, name);
                            if (!success) this.showToast("下载图片失败！");
                        }
                    }
                } else {
                    this.showToast("未找到可下载的文件链接！");
                }
            } catch (error) {
                console.error("处理下载链接时发生错误:", error);
                this.showToast("处理下载发生错误！");
            }
        },

        async extractDownloadLinks() {
            let currentUrl = window.location.href;
            let currentSiteMatch = currentUrl.match(/www\.(xiaohongshu|rednote)\.com/);
            if (!currentSiteMatch) {
                this.showToast("无法识别当前站点！");
                return;
            }
            let currentSite = currentSiteMatch[1];

            if (currentUrl.includes(`https://www.${currentSite}.com/explore/`) || currentUrl.includes(
                `https://www.${currentSite}.com/discovery/item/`)) {
                let note = this.extractNoteInfo(currentUrl);
                if (note) {
                    await this.exploreDeal(note, currentSite, currentUrl);
                } else {
                    this.showToast("读取笔记数据失败！");
                }
            } else {
                this.showToast("请在笔记详情页点击下载！");
            }
        },

        // 显示提示消息
        showToast(message) {
            const toast = elements.createAs("div", {
                style: `
                    position: fixed;
                    top: 12%;
                    left: 50%;
                    transform: translateX(-50%);
                    background-color: #ff2442;
                    color: #fff;
                    padding: 16px 18px;
                    min-height: 20px;
                    min-width: 150px;
                    line-height: 1.2;
                    border-radius: 13px;
                    font-size: 14px;
                    font-family: sans-serif;
                    font-weight: bold;
                    z-index: 1000000000;
                    pointer-events: none;
                    opacity: 0;
                    transition: opacity 0.25s ease;
                    box-shadow: 0 2px 8px rgba(255,36,66,0.25), 0 0 0 0.5px rgba(255,36,66,0.1);
                    box-sizing: border-box;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                `,
                textContent: message
            }, document.body);

            // 触发重排后再显示，让 transition 生效
            requestAnimationFrame(() => {
                toast.style.opacity = '1';
            });

            setTimeout(() => {
                toast.style.opacity = '0';
                setTimeout(() => {
                    if (document.body.contains(toast)) {
                        document.body.removeChild(toast);
                    }
                }, 250);
            }, 1000);
        },

        // 添加按钮到页面浮动容器
        addButtons() {
            let buttonContainer = elements.getAs('#xhs-helper-buttons');

            // 只有在笔记页面才显示/创建按钮
            if (!this.isNotePage()) {
                if (buttonContainer) buttonContainer.style.display = 'none';
                return;
            }

            if (!buttonContainer) {
                buttonContainer = elements.createAs('div', {
                    id: 'xhs-helper-buttons',
                    style: `
                        position: fixed;
                        top: 50%;
                        right: 30px;
                        transform: translateY(-50%);
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        gap: 15px;
                        z-index: 999999;
                    `
                }, document.body);
            }

            buttonContainer.style.display = 'flex';

            // 创建封面按钮
            if (!elements.getAs('#xhs-thumbnail-btn')) {
                elements.createAs('a', {
                    id: 'xhs-thumbnail-btn',
                    href: 'javascript:void(0);',
                    className: 'xhs-icon-btn',
                    title: '点击预览/隐藏封面',
                     innerHTML: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M6.002 5.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/><path d="M2.002 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2h-12zm12 1a1 1 0 0 1 1 1v6.5l-3.777-1.947a.5.5 0 0 0-.577.093l-3.71 3.71-2.66-1.772a.5.5 0 0 0-.63.062L1.002 12V3a1 1 0 0 1 1-1h12z"/></svg>',
                    onclick: (e) => this.toggleThumbnailPreview(e)
                }, buttonContainer);
            }

            // 创建复制文案按钮 (替代原字幕按钮)
            if (!elements.getAs('#xhs-subtitle-btn')) {
                elements.createAs('a', {
                    id: 'xhs-subtitle-btn',
                    href: 'javascript:void(0);',
                    className: 'xhs-icon-btn',
                    title: '一键复制文案',
                    innerHTML: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.5a1 1 0 0 0-.8.4l-1.9 2.533a1 1 0 0 1-1.6 0L5.3 12.4a1 1 0 0 0-.8-.4H2a2 2 0 0 1-2-2V2zm7.194 2.766a1.688 1.688 0 0 0-.227-.272 1.467 1.467 0 0 0-.469-.324l-.008-.004A1.785 1.785 0 0 0 5.734 4C4.776 4 4 4.746 4 5.667c0 .92.776 1.666 1.734 1.666.343 0 .662-.095.931-.26-.137.389-.39.804-.81 1.22a.405.405 0 0 0 .011.59c.173.16.447.155.614-.01 1.334-1.329 1.37-2.758.941-3.706a2.461 2.461 0 0 0-.227-.4zM11 7.073c-.136.389-.39.804-.81 1.22a.405.405 0 0 0 .012.59c.172.16.446.155.613-.01 1.334-1.329 1.37-2.758.942-3.706a2.466 2.466 0 0 0-.228-.4 1.686 1.686 0 0 0-.227-.273 1.466 1.466 0 0 0-.469-.324l-.008-.004A1.785 1.785 0 0 0 10.07 4c-.957 0-1.734.746-1.734 1.667 0 .92.777 1.666 1.734 1.666.343 0 .662-.095.931-.26z"/></svg>',
                onclick: () => this.copyText()
                }, buttonContainer);
            }

            // 创建下载按钮
            if (!elements.getAs('#xhs-download-btn')) {
                elements.createAs('a', {
                    id: 'xhs-download-btn',
                    href: 'javascript:void(0);',
                    className: 'xhs-icon-btn',
                    title: '下载无水印图片/视频',
                    innerHTML: '<svg width="14" height="14" viewBox="0 0 14 14"><path fill="currentColor" fill-rule="evenodd" d="M7 14A7 7 0 1 0 7 0a7 7 0 0 0 0 14m3.146-5.69l-2.793 2.793a.5.5 0 0 1-.707 0L3.854 8.31a.5.5 0 0 1 .353-.853H6V3.75a1 1 0 0 1 2 0v3.707h1.793a.5.5 0 0 1 .353.853" clip-rule="evenodd"/></svg>',
                    onclick: () => this.extractDownloadLinks()
                }, buttonContainer);
            }

            this.buttonAdded = true;
        },

        // 显示缩略图预览
        showThumbnailPreview(event) {
            const thumbnailUrl = this.getThumbnailUrl();
            if (thumbnailUrl) {
                preview.src = thumbnailUrl;
                const rect = event.currentTarget.getBoundingClientRect();

                preview.onload = () => {
                    // 确保预览图显示并设置尺寸
                    preview.style.display = 'block';

                    const previewRect = preview.getBoundingClientRect();

                    // 定位在按钮的左侧，留出 20px 间距
                    preview.style.left = (rect.left - previewRect.width - 20) + 'px';

                    // 垂直居中对齐当前悬浮的按钮
                    let topPos = rect.top + (rect.height / 2) - (previewRect.height / 2);

                    // 边界保护
                    if (topPos < 20) topPos = 20;
                    if (topPos + previewRect.height > window.innerHeight - 20) {
                        topPos = window.innerHeight - previewRect.height - 20;
                    }

                    preview.style.top = topPos + 'px';
                };
            }
        },

        // 隐藏缩略图预览
        hideThumbnailPreview() {
            preview.style.display = 'none';
        },

        // 点击切换缩略图预览的显示与隐藏
        toggleThumbnailPreview(event) {
            if (preview.style.display === 'block') {
                this.hideThumbnailPreview();
            } else {
                const thumbnailUrl = this.getThumbnailUrl();
                if (thumbnailUrl) {
                    this.showThumbnailPreview(event);
                } else {
                    this.showToast('未找到封面图片');
                }
            }
        },

        // 检测并执行来自用户主页的自动下载
        checkAutoDownload() {
            const noteId = sessionStorage.getItem('xhs_auto_dl');
            if (!noteId || !this.isNotePage()) return;
            sessionStorage.removeItem('xhs_auto_dl');

            let attempts = 0;
            const maxAttempts = 20;
            const tryDownload = () => {
                attempts++;
                const noteData = this.extractNoteInfo(window.location.href);
                if (noteData && (noteData.imageList?.length > 0 || noteData.video)) {
                    // 内容已加载，等待 DOM 稳定后触发下载
                    setTimeout(() => {
                        this.extractDownloadLinks();
                    }, 600);
                } else if (attempts < maxAttempts) {
                    setTimeout(tryDownload, 500);
                }
            };
            // 等待页面渲染
            setTimeout(tryDownload, 800);
        },

        // 启动按钮检查
        startButtonCheck() {
            if (this.buttonCheckInterval) {
                clearInterval(this.buttonCheckInterval);
            }

            this.buttonCheckInterval = setInterval(() => {
                this.addButtons();
            }, 1500);
        },

        // 初始化
        init() {
            this.addButtons();
            this.checkAutoDownload();
            this.startButtonCheck();
            console.log('小红书浏览助手初始化成功');

            // 监听页面变化，小红书弹窗笔记会改变 URL
            let lastUrl = location.href;
            new MutationObserver(() => {
                if (lastUrl !== location.href) {
                    lastUrl = location.href;
                    // 延迟处理，等待页面元素加载
                    setTimeout(() => {
                        this.addButtons();
                        this.checkAutoDownload();
                    }, 800);
                }
            }).observe(document.body, {
                childList: true,
                subtree: true
            });
        }
    };

    // ═══════════════════════════════════════════
    //  Module C: 用户主页批量下载
    // ═══════════════════════════════════════════

    (function() {

        // ── constants ──
        const uRe = /^\/user\/profile\//;
        const API_HOST = "edith.xiaohongshu.com";

        const E = {
            USER_NOTES: "/api/sns/web/v1/user/notes",
            USER_INFO: "/api/sns/web/v1/user/otherinfo",
        };

        const S = {
            cp: window.location.pathname,
            cid: "",
            notes: new Map(),
            dl: false,
            enabled: false,
        };

        const ZS = 100 * 1024 * 1024;
        const DC = 3;

        // ── helpers ──
        const nt = (v, fb = "") => v === null || v === undefined ? fb : String(v);
        const up = () => uRe.test(window.location.pathname);
        const sf = (v, fb = "未命名", ml = 80) => { const c = nt(v, fb).replace(/[\\/:*?"<>|\s]+/g, "").replace(/\.+$/g, "").slice(0, ml); return c || fb; };
        const sl = (ms) => new Promise((r) => setTimeout(r, ms));
        const fu = (inp) => { if (typeof inp === "string") return inp; if (inp instanceof URL) return inp.href; return nt(inp?.url); };
        const pj = (txt) => { try { return JSON.parse(txt); } catch (e) { return null; } };
        const gE = (url, fb) => { try { const m = /\.([a-z0-9]{2,5})$/i.exec(new URL(url, window.location.href).pathname); return m ? m[1].toLowerCase() : fb; } catch (_) { return fb; } };

        // ── toast ──
        let _t = null;
        const tst = (msg, sticky) => {
            let el = document.getElementById("xhs-toast");
            if (!el) {
                el = document.createElement("div");
                el.id = "xhs-toast";
                el.style.cssText = "position:fixed;top:5%;left:50%;transform:translateX(-50%);background:#ff2442;color:#fff;padding:16px 18px;min-height:20px;min-width:180px;line-height:1.2;border-radius:13px;font-size:14px;font-family:sans-serif;z-index:2147483647;pointer-events:none;opacity:0;transition:opacity 0.25s ease;box-shadow:0 2px 8px rgba(255,36,66,0.25);box-sizing:border-box;display:flex;align-items:center;justify-content:center;";
                document.body.appendChild(el);
            }
            clearTimeout(_t);
            el.textContent = msg;
            el.style.opacity = "1";
            if (!sticky) { _t = setTimeout(() => { el.style.opacity = "0"; }, 1500); }
        };

        // ── note info extraction from API response ──
        const fa = (item = {}) => {
            const nc = item.note_card || {};
            const cover = nc.cover || {};
            const imgList = nc.image_list || [];
            const user = item.user || {};
            const interact = nc.interact_info || {};
            return {
                note_id: nt(item.id),
                title: nt(nc.display_title || nc.title || item.display_title),
                type: nc.type === "video" ? "video" : "normal",
                coverUrl: nt(cover.url_default || cover.url_pre || ""),
                imgUrls: Array.isArray(imgList) ? imgList.map(i => nt(i.url_default || i.url || "")).filter(Boolean) : [],
                userId: nt(user.user_id),
                nick: nt(user.nickname, "未知作者"),
                liked: nt(interact.liked_count, "0"),
            };
        };

        const fuInfo = (ui = {}) => ({ uid: nt(ui.user_id), nick: nt(ui.nickname) });

        // ── state management ──
        const rs = () => { S.cp = window.location.pathname; S.cid = ""; S.notes.clear(); rv(); };
        const es = () => { if (S.cp !== window.location.pathname) rs(); };

        // ── network hooks ──
        const su = (url) => {
            if (!up()) return false;
            try {
                const u = new URL(url, window.location.href);
                return u.hostname === API_HOST && (
                    u.pathname.includes("/user/notes") ||
                    u.pathname.includes("/user/otherinfo") ||
                    u.pathname.includes("/user/profile") ||
                    u.pathname.includes("/user/note")
                );
            } catch (_) { return false; }
        };

        const ha = (url, txt) => {
            if (!su(url)) return;
            es();
            const d = pj(txt);
            if (!d) return;
            const data = d.data || d;
            if (!data) return;

            // User info
            if (url.includes("/user/otherinfo") || url.includes("/user/profile")) {
                const user = data.user || data;
                const ui = fuInfo(user);
                if (!ui.uid) return;
                if (S.cid && S.cid !== ui.uid) { S.notes.clear(); rv(); }
                S.cid = ui.uid;
                Array.from(S.notes.entries()).forEach(([k, v]) => { if (v.userId && v.userId !== ui.uid) S.notes.delete(k); });
                rv();
                return;
            }

            // User notes
            if (url.includes("/user/notes") || url.includes("/user/note")) {
                const items = data.items || [];
                if (!Array.isArray(items)) return;
                let userChanged = false;
                items.forEach(item => {
                    const note = fa(item);
                    if (!note.note_id) return;
                    // Filter by current user if we know them
                    if (S.cid && note.userId && note.userId !== S.cid) return;
                    if (!S.notes.has(note.note_id)) {
                        S.notes.set(note.note_id, note);
                        if (note.userId && !S.cid) { S.cid = note.userId; userChanged = true; }
                    }
                });
                rv();
            }
        };

        const hx = () => {
            const _o = XMLHttpRequest.prototype.open;
            const _s = XMLHttpRequest.prototype.send;
            XMLHttpRequest.prototype.open = function (m, url) { this._u = nt(url); return _o.apply(this, arguments); };
            XMLHttpRequest.prototype.send = function (body) { this.addEventListener("load", function () { try { ha(this._u || "", nt(this.responseText)); } catch (_) {} }); return _s.apply(this, arguments); };
        };

        const hf = () => {
            if (typeof window.fetch !== "function") return;
            const _f = window.fetch;
            window.fetch = async function (...args) {
                const r = await _f.apply(this, arguments);
                const url = fu(args[0]);
                if (su(url)) { r.clone().text().then((t) => ha(url, t)).catch(() => {}); }
                return r;
            };
        };

        // ── download helpers ──
        const fA = async (url) => { if (!url) throw new Error("下载地址为空"); const r = await fetch(url); if (!r.ok) throw new Error(`HTTP error! status: ${r.status}`); return new Uint8Array(await r.arrayBuffer()); };
        const fL = async (url) => { if (!url) throw new Error("下载地址为空"); const r = await fetch(url); if (!r.ok) throw new Error(`HTTP error! status: ${r.status}`); return r.blob(); };
        const dB = (blob, fn) => { const sn = (fn || "download").replace(/[\\/:*?"<>|]+/g, "_").trim() || "download"; const u = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = u; a.download = sn; a.style.display = "none"; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000); };

        const uz = (zo, bn) => {
            if (!Object.prototype.hasOwnProperty.call(zo, bn)) return bn;
            const di = bn.lastIndexOf(".");
            const b = di > 0 ? bn.slice(0, di) : bn;
            const e = di > 0 ? bn.slice(di) : "";
            let n = 2;
            let c = `${b}_${n}${e}`;
            while (Object.prototype.hasOwnProperty.call(zo, c)) { n++; c = `${b}_${n}${e}`; }
            return c;
        };

        const zA = async (zo, label) => {
            if (typeof JSZip === "undefined") throw new Error("JSZip 未加载，无法打包文件");
            const zip = new JSZip();
            Object.entries(zo).forEach(([name, data]) => { zip.file(name, data); });
            return await zip.generateAsync({ type: "blob", compression: "STORE" }, (meta) => {
                tst(`${label} ${meta.percent.toFixed(0)}%`, true);
            });
        };

        const sZ = (zo, cs) => {
            const chunks = [];
            let cc = {}, sz = 0;
            Object.entries(zo).forEach(([k, v]) => { const es = v.length || v.byteLength || 0; if (sz > 0 && sz + es > cs) { chunks.push(cc); cc = {}; sz = 0; } cc[k] = v; sz += es; });
            if (Object.keys(cc).length > 0) chunks.push(cc);
            return chunks;
        };

        const zC = async (zo, an) => {
            const chunks = sZ(zo, ZS);
            const sa = sf(an, "未知作者", 40);
            for (let idx = 0; idx < chunks.length; idx++) {
                const cur = idx + 1;
                const pre = chunks.length > 1 ? `压缩 ${cur}/${chunks.length}` : "压缩中";
                tst(pre);
                try {
                    const zd = await zA(chunks[idx], pre);
                    const zn = chunks.length > 1 ? `${sa}_part${cur}.zip` : `${sa}.zip`;
                    dB(zd, zn);
                    if (chunks.length > 1 && cur < chunks.length) await sl(1000);
                } catch (e) { throw e; }
            }
            return chunks.length;
        };

        const rC = async (items, limit, wrk) => { let cur = 0; const ws = Array.from({ length: Math.min(limit, items.length) }, async () => { while (cur < items.length) { const i = cur++; await wrk(items[i], i); } }); await Promise.all(ws); };

        // ── fetch note detail from explore page ──
        const fetchNoteDetail = async (noteId) => {
            try {
                const url = `https://www.xiaohongshu.com/explore/${noteId}`;
                const r = await fetch(url, {
                    headers: { "User-Agent": navigator.userAgent, "Accept": "text/html" }
                });
                if (!r.ok) return null;
                const html = await r.text();
                // Try to extract __INITIAL_STATE__ (use [\s\S] for multiline matching)
                const match = html.match(/window\.__INITIAL_STATE__\s*=\s*(\{[\s\S]*?\});?<\/script>/);
                if (!match) {
                    // Try alternate: React hydratation data
                    const altMatch = html.match(/<script>window\.__NUXT__\s*=\s*(\{[\s\S]*?\});?<\/script>/);
                    if (!altMatch) return null;
                    const state = JSON.parse(altMatch[1]);
                    return state?.noteData?.data?.noteData || null;
                }
                const state = JSON.parse(match[1]);
                // Navigate multiple possible paths to find note data
                let noteData = null;
                try { noteData = state.noteData?.data?.noteData; } catch (_) {}
                if (!noteData) { try { noteData = state.note?.noteDetailMap?.[noteId]?.note; } catch (_) {} }
                if (!noteData) {
                    try {
                        const map = state.note?.noteDetailMap || {};
                        noteData = Object.values(map).find(n => n?.note?.note_id === noteId)?.note || null;
                    } catch (_) {}
                }
                if (!noteData) { try { noteData = state.feeds?.[0]?.noteData; } catch (_) {} }
                return noteData;
            } catch (_) { return null; }
        };

        // ── download a single note ──
        const downloadNote = async (note) => {
            const detail = await fetchNoteDetail(note.note_id);
            if (!detail) { tst(`✘ 获取笔记 ${note.note_id} 失败`); return false; }

            try {
                const name = sf(note.title, note.note_id, 40);
                if (detail.type === "video") {
                    // Video download
                    const videoKey = detail.video?.consumer?.originVideoKey;
                    let videoUrl = "";
                    if (videoKey) {
                        videoUrl = `https://sns-video-bd.xhscdn.com/${videoKey}`;
                    } else {
                        try {
                            const stream = detail.video?.media?.stream;
                            if (stream?.h265) {
                                const arr = stream.h265;
                                videoUrl = arr[arr.length - 1]?.masterUrl || "";
                            } else if (stream?.h264) {
                                const arr = stream.h264;
                                videoUrl = arr[arr.length - 1]?.masterUrl || "";
                            }
                        } catch (_) {}
                    }
                    if (!videoUrl) { tst(`✘ 未找到视频链接`); return false; }
                    const blob = await fL(videoUrl);
                    dB(blob, `${name}.mp4`);
                    return true;
                } else {
                    // Image note download
                    const urls = [];
                    const images = detail.imageList || [];
                    const regex = /http:\/\/sns-webpic-qc\.xhscdn\.com\/\d+\/[0-9a-z]+\/(\S+)!/;
                    const regex2 = /http:\/\/sns-web-i10\.rednotecdn\.com\/\d+\/[0-9a-z]+\/(\S+)!/;
                    images.forEach((img) => {
                        const url = img.urlDefault || img.url || "";
                        let match = url.match(regex);
                        if (match && match[1]) {
                            urls.push(`https://ci.xiaohongshu.com/${match[1]}?imageView2/format/jpeg`);
                        } else {
                            match = url.match(regex2);
                            if (match && match[1]) {
                                urls.push(`https://ci.xiaohongshu.com/${match[1]}?imageView2/format/jpeg`);
                            } else if (url) {
                                urls.push(url);
                            }
                        }
                    });
                    if (urls.length === 0) { tst(`✘ 未找到图片`); return false; }

                    if (urls.length === 1) {
                        const blob = await fL(urls[0]);
                        dB(blob, `${name}.jpeg`);
                    } else {
                        const zo = {};
                        for (let i = 0; i < urls.length; i++) {
                            try {
                                const data = await fA(urls[i]);
                                zo[uz(zo, `${name}/image_${String(i + 1).padStart(2, "0")}.jpeg`)] = data;
                            } catch (_) {}
                        }
                        if (Object.keys(zo).length === 0) return false;
                        await zC(zo, name);
                    }
                    return true;
                }
            } catch (_) { return false; }
        };

        // ── batch download ──
        const dZ = async (notes) => {
            const failed = [];
            let successCount = 0;
            for (let i = 0; i < notes.length; i++) {
                const note = notes[i];
                tst(`下载中 ${i + 1}/${notes.length}`, true);
                const ok = await downloadNote(note);
                if (ok) successCount++;
                else failed.push(note.title || note.note_id);
                if (i < notes.length - 1) await sl(800);
            }
            if (failed.length === 0) {
                tst(`✔ ${successCount}个笔记全部保存完毕`);
            } else {
                tst(`${successCount}个成功，${failed.length}个失败`);
            }
        };

        const dS = async (note) => {
            tst("开始下载...");
            const ok = await downloadNote(note);
            if (ok) tst("✔ 下载成功");
            else tst("✘ 下载失败");
        };

        const te = () => {
            S.enabled = !S.enabled;
            const tb = document.getElementById('xhs-toggle');
            if (tb) { tb.textContent = S.enabled ? '关闭自动下载' : '启用自动下载'; tb.classList.toggle('xhs-tb-on', S.enabled); }
            if (!S.enabled) {
                // 停用时移除所有 data 标记，下次启用会重新注入
                document.querySelectorAll('[data-xhs-checked]').forEach((el) => el.removeAttribute('data-xhs-checked'));
                document.querySelectorAll('[data-xhs-card-processed]').forEach((el) => el.removeAttribute('data-xhs-card-processed'));
                document.querySelectorAll('[data-xhs-download-setup]').forEach((el) => el.removeAttribute('data-xhs-download-setup'));
            }
            icl();
        };
        const findCard = (link) => {
            // Try specific selectors first
            const bySelector = link.closest('li, section, article, [class*="noteItem"], [class*="note-item"], [class*="feeds-item"], [class*="waterfall"], [class*="card"], [class*="item-container"]');
            if (bySelector) return bySelector;
            // Walk up the DOM tree to find a reasonable card container
            let el = link.parentElement;
            for (let i = 0; i < 6 && el; i++) {
                const tag = el.tagName.toLowerCase();
                const cls = typeof el.className === 'string' ? el.className : '';
                // Cards typically contain an image and have size
                if (tag === 'li' || tag === 'section' || tag === 'article') return el;
                if (cls.includes('note') || cls.includes('card') || cls.includes('feed') || cls.includes('item') || cls.includes('waterfall')) return el;
                const rect = el.getBoundingClientRect();
                if (rect.width > 100 && rect.height > 100) return el;
                el = el.parentElement;
            }
            return link.parentElement;
        };

        // ── UI: inject download-on-click on note cards ──
        const icl = () => {
            if (!S.enabled) return;
            // Method 1: Find links to explore pages
            const links = document.querySelectorAll('a[href*="/explore/"]:not([data-xhs-checked]), a[href*="/discovery/item/"]:not([data-xhs-checked])');
            links.forEach((link) => {
                link.setAttribute('data-xhs-checked', '1');
                const href = link.getAttribute('href') || '';
                const m = /\/explore\/([a-zA-Z0-9]+)/.exec(href) || /\/discovery\/item\/([a-zA-Z0-9]+)/.exec(href);
                if (!m) return;
                const noteId = m[1];
                // DOM fallback: if no API data, create basic entry from link
                if (!S.notes.has(noteId)) {
                    S.notes.set(noteId, {
                        note_id: noteId,
                        title: "",
                        type: "normal",
                        coverUrl: "",
                        imgUrls: [],
                        userId: S.cid || "",
                        nick: "",
                    });
                }
                const card = findCard(link);
                // Skip if too small (not a real card)
                const rect = card.getBoundingClientRect();
                if (rect.width < 50 || rect.height < 50) return;
                injectDownloadOnClick(card, noteId, link);
            });

            // Method 2: Find card elements directly (covers non-<a> links)
            const cardSelectors = '[class*="noteItem"], [class*="note-item"], [class*="feeds-item"], [class*="waterfall_item"], [class*="waterfallItem"]';
            document.querySelectorAll(cardSelectors + ':not([data-xhs-card-processed])').forEach((card) => {
                card.setAttribute('data-xhs-card-processed', '1');
                // Try to find note ID from link within the card
                const cardLink = card.querySelector('a[href*="/explore/"], a[href*="/discovery/item/"]');
                if (!cardLink) return;
                const href = cardLink.getAttribute('href') || '';
                const m = /\/explore\/([a-zA-Z0-9]+)/.exec(href) || /\/discovery\/item\/([a-zA-Z0-9]+)/.exec(href);
                if (!m) return;
                const noteId = m[1];
                const rect = card.getBoundingClientRect();
                if (rect.width < 50 || rect.height < 50) return;
                // DOM fallback
                if (!S.notes.has(noteId)) {
                    S.notes.set(noteId, {
                        note_id: noteId,
                        title: "",
                        type: "normal",
                        coverUrl: "",
                        imgUrls: [],
                        userId: S.cid || "",
                        nick: "",
                    });
                }
                const cs = getComputedStyle(card);
                if (cs.position === 'static') card.style.position = 'relative';
                const ov = cs.overflow;
                if (ov === 'hidden' || ov === 'clip') card.style.overflow = 'visible';
                injectDownloadOnClick(card, noteId, cardLink);
            });
        };

        const injectDownloadOnClick = (card, noteId, link) => {
            if (card.dataset.xhsDownloadSetup) return;
            card.dataset.xhsDownloadSetup = '1';
            const cs = getComputedStyle(card);
            if (cs.position === 'static') card.style.position = 'relative';
            const ov = cs.overflow;
            if (ov === 'hidden' || ov === 'clip') card.style.overflow = 'visible';
            // 添加光标样式提示可点击下载
            card.style.cursor = 'pointer';
            // 点击笔记时允许正常导航到详情页，并设置自动下载标记
            card.addEventListener('click', () => {
                if (!S.enabled) return;
                sessionStorage.setItem('xhs_auto_dl', noteId);
            }, true);
            link.addEventListener('click', () => {
                if (!S.enabled) return;
                sessionStorage.setItem('xhs_auto_dl', noteId);
            }, true);
        };

        const rv = () => { icl(); };

        // 使工具栏可拖拽移动（整个菜单可拖动，移动超过阈值才算拖拽，不影响按钮点击）
        const initDrag = (el) => {
            el.addEventListener('pointerdown', function(e) {
                if (e.button !== 0) return;                    // 仅左键/触摸
                e.preventDefault();
                const startX = e.clientX, startY = e.clientY;
                const rect = el.getBoundingClientRect();
                const offX = e.clientX - rect.left;
                const offY = e.clientY - rect.top;
                let dragging = false;

                const onMove = (ev) => {
                    if (!dragging) {
                        // 移动未超过阈值视为点击，不启动拖拽
                        if (Math.abs(ev.clientX - startX) < 4 && Math.abs(ev.clientY - startY) < 4) return;
                        dragging = true;
                        // 从 transform 居中定位切换为显式 left/top，并清除 bottom 固定，否则元素会被上下两端钉住无法移动
                        el.style.left = rect.left + 'px';
                        el.style.top = rect.top + 'px';
                        el.style.bottom = 'auto';
                        el.style.transform = 'none';
                        el.style.margin = '0';
                    }
                    el.style.left = Math.max(0, Math.min(ev.clientX - offX, window.innerWidth - el.offsetWidth)) + 'px';
                    el.style.top = Math.max(0, Math.min(ev.clientY - offY, window.innerHeight - el.offsetHeight)) + 'px';
                };
                const onUp = () => {
                    window.removeEventListener('pointermove', onMove);
                    window.removeEventListener('pointerup', onUp);
                    window.removeEventListener('pointercancel', onUp);
                };
                window.addEventListener('pointermove', onMove);
                window.addEventListener('pointerup', onUp);
                window.addEventListener('pointercancel', onUp);
            });
        };

        const itb = () => {
            if (!document.body) return;
            // 不在用户主页时移除工具栏
            if (!up()) {
                const tb = document.getElementById('xhs-toolbar');
                if (tb) tb.remove();
                return;
            }
            const exist = document.getElementById('xhs-toolbar');
            if (exist && exist.parentNode) return;
            const tb = exist || document.createElement('div');
            tb.id = 'xhs-toolbar';
            const label = S.enabled ? '关闭自动下载' : '启用自动下载';
            const cls = S.enabled ? ' xhs-tb-on' : '';
            tb.innerHTML = '<button id="xhs-toggle" class="xhs-tb-btn' + cls + '">' + label + '</button><button id="xhs-get-links" class="xhs-tb-btn">获取作品链接</button>';
            if (!tb.parentNode) document.body.appendChild(tb);
            initDrag(tb);
            document.getElementById('xhs-toggle').addEventListener('click', te);
            document.getElementById('xhs-get-links').addEventListener('click', () => {
                // 从 __INITIAL_STATE__ 读取笔记数据（含 xsec_token）
                const state = unsafeWindow.__INITIAL_STATE__;
                const rawNotes = state?.user?.notes?._rawValue?.[0];
                if (!rawNotes || !Array.isArray(rawNotes)) {
                    tst('获取失败，请确认当前页面为用户主页');
                    return;
                }
                const items = rawNotes.filter(item => item?.id && item?.xsecToken);
                if (items.length === 0) {
                    tst('未找到任何作品');
                    return;
                }
                // 生成 Markdown 内容
                const fmtLikes = (n) => n >= 10000 ? (n / 10000).toFixed(1).replace(/\.0$/, '') + 'w' : String(n);
                const lines = items.map((item, i) => {
                    const title = item.noteCard?.displayTitle || `作品 ${i + 1}`;
                    const author = item.noteCard?.user?.nickName || '';
                    const interact = item.noteCard?.interactInfo || item.noteCard?.interact || {};
                    const likes = fmtLikes(Number(interact.likedCount || interact.liked_count || 0));
                    const url = `https://www.xiaohongshu.com/discovery/item/${item.id}?source=webshare&xhsshare=pc_web&xsec_token=${item.xsecToken}&xsec_source=pc_share`;
                    return `${i + 1}. [${title}](${url})  👍 ${likes}`;
                });
                const nick = items[0]?.noteCard?.user?.nickName || '小红书';
                const md = `# ${nick} 的作品\n\n${lines.join('\n')}\n`;
                // 下载为 .md 文件
                const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = `${nick}_作品列表_${new Date().toISOString().slice(0, 10)}.md`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(a.href);
                tst(`已保存 ${items.length} 个作品`);
            });
        };

        const rB = (cb) => { if (document.body) { cb(); return; } document.addEventListener("DOMContentLoaded", cb, { once: true }); };

        // ── only run on /user/profile/ page ──
        if (!up()) return;

        const nu = () => window.location.pathname;
        let _lp = nu();
        const ot = () => {
            const cur = nu();
            if (cur !== _lp) {
                _lp = cur;
                // 离开用户主页时移除工具栏
                if (!up()) {
                    const tb = document.getElementById('xhs-toolbar');
                    if (tb) tb.remove();
                    document.querySelectorAll('[data-xhs-checked]').forEach((el) => el.removeAttribute('data-xhs-checked'));
                    document.querySelectorAll('[data-xhs-card-processed]').forEach((el) => el.removeAttribute('data-xhs-card-processed'));
                    document.querySelectorAll('[data-xhs-download-setup]').forEach((el) => el.removeAttribute('data-xhs-download-setup'));
                    return;
                }
                S.notes.clear();
                document.querySelectorAll('[data-xhs-checked]').forEach((el) => el.removeAttribute('data-xhs-checked'));
                document.querySelectorAll('[data-xhs-card-processed]').forEach((el) => el.removeAttribute('data-xhs-card-processed'));
                document.querySelectorAll('[data-xhs-download-setup]').forEach((el) => el.removeAttribute('data-xhs-download-setup'));
            }
        };
        const opH = history.pushState;
        const rpH = history.replaceState;
        history.pushState = function () { opH.apply(this, arguments); ot(); };
        history.replaceState = function () { rpH.apply(this, arguments); ot(); };
        window.addEventListener("popstate", ot);
        setInterval(ot, 500);
        setInterval(() => { itb(); icl(); }, 800);

        GM_addStyle(`
            #xhs-toolbar {
                position: fixed;
                bottom: 20px;
                left: 50%;
                transform: translateX(-50%);
                z-index: 2147483646;
                display: flex;
                align-items: center;
                gap: 10px;
                padding: 10px 18px;
                background: rgba(0,0,0,0.6);
                backdrop-filter: blur(16px);
                border-radius: 20px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.3);
                border: 1px solid #333;
                cursor: grab;
                user-select: none;
            }
            #xhs-toolbar:active { cursor: grabbing; }
            .xhs-tb-btn {
                height: 32px;
                padding: 0 20px;
                min-width: 180px;
                border: none;
                border-radius: 16px;
                background: rgba(255,255,255,0.18);
                color: #fff;
                font-size: 13px;
                font-weight: 500;
                cursor: pointer;
                white-space: nowrap;
                transition: background .15s;
                font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif;
            }
            .xhs-tb-btn:hover { background: rgba(255,255,255,0.28); }
            .xhs-tb-btn:disabled { opacity: 0.35; cursor: not-allowed; }
            .xhs-tb-on { background: #ff2442; }
            .xhs-tb-on:hover { background: #e0203a; }
        `);

        hx();
        hf();
        rB(itb);

    })();

    // 等待页面加载完成后初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => xhsViewer.init(), 1000);
        });
    } else {
        setTimeout(() => xhsViewer.init(), 1000);
    }
})();