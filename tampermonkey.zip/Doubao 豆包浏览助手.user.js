// ==UserScript==
// @name               Doubao 豆包浏览助手
// @name:zh-CN         Doubao 豆包浏览助手
// @name:en            Doubao Enhancer Tools
// @description        增强功能：侧边目录导航；去除豆包AI生图水印，选择并下载无水印原图。请遵守法律、行政法规，尊重社会公德和伦理道德。如您生成或使用的内容导致公众混淆或者误认，因此所发生的后果和责任均由您自行承担。
// @description:zh-CN  增强功能：侧边目录导航；去除豆包AI生图水印，选择并下载无水印原图。请遵守法律、行政法规，尊重社会公德和伦理道德。如您生成或使用的内容导致公众混淆或者误认，因此所发生的后果和责任均由您自行承担。
// @description:en     Enhanced Features: Sidebar Navigation. Remove watermarks, select and download watermark-free originals from Doubao AI images;
// @namespace          https://www.runningcheese.com/userscripts
// @author             RunningCheese
// @version            1.3
// @match              https://www.doubao.com/chat*
// @grant              GM_xmlhttpRequest
// @connect            byteimg.com
// @license            MIT
// @icon               https://t1.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://www.doubao.com
// @downloadURL https://update.greasyfork.org/scripts/578957/Doubao%20%E8%B1%86%E5%8C%85%E6%B5%8F%E8%A7%88%E5%8A%A9%E6%89%8B.user.js
// @updateURL https://update.greasyfork.org/scripts/578957/Doubao%20%E8%B1%86%E5%8C%85%E6%B5%8F%E8%A7%88%E5%8A%A9%E6%89%8B.meta.js
// ==/UserScript==


(function() {
    'use strict';

    let ttPolicy;
    if (window.trustedTypes && window.trustedTypes.createPolicy) {
        try {
            ttPolicy = window.trustedTypes.createPolicy('doubao-assistant-' + Math.random().toString(36).substring(2, 9), {
                createHTML: (string) => string
            });
        } catch (e) {
            ttPolicy = { createHTML: (string) => string };
        }
    } else {
        ttPolicy = { createHTML: (string) => string };
    }

    const elements = {
        createAs(nodeType, config, appendTo) {
            const element = document.createElement(nodeType);
            if (config) {
                Object.entries(config).forEach(([key, value]) => {
                    if (key === 'innerHTML') {
                        element.innerHTML = ttPolicy.createHTML(value);
                    } else {
                        element[key] = value;
                    }
                });
            }
            if (appendTo) appendTo.appendChild(element);
            return element;
        },
        getAs(selector) {
            return document.body.querySelector(selector);
        }
    };

    const style = elements.createAs('style', {
        textContent: `
            .doubao-toast {
                position: fixed;
                top: 5%;
                left: 50%;
                transform: translateX(-50%);
                background: #3F7FEA;
                color: #fff;
                padding: 16px 18px;
                min-height: 20px;
                min-width: 180px;
                line-height: 1.2;
                border-radius: 13px;
                font-size: 14px;
                font-family: sans-serif;
                z-index: 2147483647;
                pointer-events: none;
                opacity: 0;
                transition: opacity 0.25s ease;
                box-shadow: 0 2px 8px rgba(0,122,255,0.25), 0 0 0 0.5px rgba(0,122,255,0.1);
                box-sizing: border-box;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .db-wm-menu-item {
               font-weight:500;
               margin:4px;
            }
            .db-wm-menu-item:hover {
                background: rgba(0, 0, 0, 0.04) !important;
                border-radius: 12px;
                color: #165DFF;
            }
            .doubao-batch-dl-btn {
                display: inline-flex;
                align-items: center;
                gap: 4px;
                margin-right:6px;
                padding: 5px 12px;
                border: none;
                border-radius: 8px;
                background: #165DFF;
                color: #fff;
                font-size: 12px;
                cursor: pointer;
                font-weight: 500;
                transition: opacity 0.2s;
                user-select: none;
                white-space: nowrap;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            }
            .doubao-batch-dl-btn:hover {
                opacity: 0.9;
            }
            .doubao-batch-dl-btn:active {
                transform: scale(0.97);
            }

            .doubao-select-overlay {
                position: fixed;
                top: 0; left: 0; right: 0; bottom: 0;
                background: rgba(0, 0, 0, 0.55);
                z-index: 1000000001;
                display: flex;
                align-items: center;
                justify-content: center;
                animation: doubao-fade-in 0.2s ease;
            }
            @keyframes doubao-fade-in {
                from { opacity: 0; }
                to { opacity: 1; }
            }

            .doubao-select-dialog {
                background: #fff;
                border-radius: 12px;
                width: 90vw;
                max-width: 720px;
                max-height: 85vh;
                display: flex;
                flex-direction: column;
                box-shadow: 0 8px 40px rgba(0,0,0,0.25);
                animation: doubao-scale-in 0.25s ease;
            }
            @keyframes doubao-scale-in {
                from { opacity: 0; transform: scale(0.92); }
                to { opacity: 1; transform: scale(1); }
            }

            .doubao-select-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 16px 20px;
                border-bottom: 1px solid #eee;
                flex-shrink: 0;
            }
            .doubao-select-header .title {
                font-size: 16px;
                font-weight: 600;
                color: #1f1f1f;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            }
            .doubao-select-header .close-btn {
                width: 32px; height: 32px;
                border-radius: 50%;
                border: none;
                background: #f5f5f5;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: background 0.2s;
                font-size: 16px;
                color: #666;
            }
            .doubao-select-header .close-btn:hover {
                background: #e8e8e8;
            }

            .doubao-select-toolbar {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 10px 20px;
                border-bottom: 1px solid #f0f0f0;
                flex-shrink: 0;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            }
            .doubao-select-toolbar .toolbar-left {
                display: flex;
                align-items: center;
                gap: 16px;
            }
            .doubao-select-toolbar .tool-btn {
                font-size: 13px;
                color: #165DFF;
                cursor: pointer;
                user-select: none;
                border: none;
                background: none;
                padding: 4px 0;
            }
            .doubao-select-toolbar .tool-btn:hover {
                opacity: 0.8;
            }
            .doubao-select-toolbar .tool-btn.danger {
                color: #f53f3f;
            }
            .doubao-select-toolbar .tool-divider {
                width: 1px;
                height: 14px;
                background: #e5e5e5;
            }
            .doubao-select-toolbar .count-text {
                font-size: 13px;
                color: #999;
            }

            .doubao-select-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
                gap: 12px;
                padding: 16px 20px;
                overflow-y: auto;
                flex: 1;
            }

            .doubao-select-item {
                position: relative;
                border-radius: 8px;
                overflow: hidden;
                cursor: pointer;
                border: 3px solid transparent;
                transition: border-color 0.15s;
                aspect-ratio: 1;
                background: #f5f5f5;
            }
            .doubao-select-item:hover {
                border-color: #d0d0d0;
            }
            .doubao-select-item.checked {
                border-color: #165DFF;
            }
            .doubao-select-item img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                display: block;
            }
            .doubao-select-item .checkbox {
                position: absolute;
                top: 8px;
                right: 8px;
                width: 24px;
                height: 24px;
                border-radius: 50%;
                background: rgba(255,255,255,0.85);
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 12px;
                color: transparent;
                transition: all 0.2s;
                box-shadow: 0 1px 4px rgba(0,0,0,0.15);
            }
            .doubao-select-item.checked .checkbox {
                background: #165DFF;
                color: #fff;
            }
            .doubao-select-item .index-badge {
                position: absolute;
                top: 8px;
                left: 8px;
                background: rgba(0,0,0,0.55);
                color: #fff;
                font-size: 11px;
                padding: 2px 7px;
                border-radius: 10px;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            }

            .doubao-select-footer {
                display: flex;
                align-items: center;
                justify-content: flex-end;
                gap: 10px;
                padding: 14px 20px;
                border-top: 1px solid #eee;
                flex-shrink: 0;
            }
            .doubao-select-footer .cancel-btn {
                padding: 8px 20px;
                border-radius: 6px;
                border: 1px solid #ddd;
                background: #fff;
                color: #666;
                font-size: 14px;
                cursor: pointer;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            }
            .doubao-select-footer .cancel-btn:hover {
                background: #f5f5f5;
            }
            .doubao-select-footer .confirm-btn {
                padding: 8px 24px;
                border-radius: 6px;
                border: none;
                background: #165DFF;
                color: #fff;
                font-size: 14px;
                cursor: pointer;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
                font-weight: 500;
                transition: opacity 0.2s;
            }
            .doubao-select-footer .confirm-btn:hover {
                opacity: 0.9;
            }
            .doubao-select-footer .confirm-btn:disabled {
                opacity: 0.4;
                cursor: not-allowed;
            }

        `
    }, document.head);

    function showToast(message, duration) {
        duration = duration || 3000;
        const existing = document.querySelector('.doubao-toast');
        if (existing) existing.remove();

        const toast = elements.createAs('div', {
            className: 'doubao-toast',
            textContent: message
        }, document.body);

        // 触发重排后显示（opacity: 0 → 1 触发 transition）
        void toast.offsetWidth;
        toast.style.opacity = '1';

        if (duration > 0) {
            setTimeout(() => {
                toast.style.opacity = '0';
                setTimeout(() => {
                    if (toast.parentNode) toast.remove();
                }, 250);
            }, duration);
        }
        return toast;
    }

    const QuestionState = {
        doubaoMessages: [],
        doubaoConversationId: null,
        activeIndex: -1,
        highlightedEl: null
    };

    const _originalXHROpen = XMLHttpRequest.prototype.open;
    const _originalXHRSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function(method, url) {
        this._qnavUrl = url;
        return _originalXHROpen.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function(body) {
        this.addEventListener('load', function() {
            if (this._qnavUrl && this._qnavUrl.includes('im/chain/single')) {
                try {
                    parseDoubaoResponse(JSON.parse(this.responseText));
                } catch (_) {}
            }
        });
        return _originalXHRSend.apply(this, arguments);
    };

    function parseDoubaoResponse(data) {
        if (!data) return;
        const body = data.downlink_body && data.downlink_body.pull_singe_chain_downlink_body;
        const msgs = body && Array.isArray(body.messages) ? body.messages : [];
        const conversationId = (msgs[0] && msgs[0].conversation_id) || (body && body.conversation_id) || null;

        const isNewConversation = conversationId != null && conversationId !== QuestionState.doubaoConversationId;
        if (isNewConversation) {
            QuestionState.doubaoConversationId = conversationId;
            QuestionState.doubaoMessages = [];
        }

        msgs.forEach(function(msg) {
            if (msg.user_type !== 1) return;
            const id = msg.message_id;
            let text = "";
            if (msg.content_block && Array.isArray(msg.content_block)) {
                msg.content_block.forEach(function(block) {
                    if (block.content && block.content.text_block && block.content.text_block.text) {
                        text += block.content.text_block.text + " ";
                    }
                });
            }
            if (!text && msg.content) text = msg.content;
            if (!text && msg.base_content) text = msg.base_content;
            text = text.trim();
            const indexInConv = msg.index_in_conv != null ? parseInt(String(msg.index_in_conv), 10) : undefined;

            if (id && text) {
                const existing = QuestionState.doubaoMessages.find(function(m) { return m.id === id; });
                if (!existing) {
                    QuestionState.doubaoMessages.push({ id: id, text: text, isUser: true, indexInConv: indexInConv });
                } else if (existing.indexInConv === undefined && indexInConv !== undefined) {
                    existing.indexInConv = indexInConv;
                }
            }
        });

        QuestionState.doubaoMessages.sort(function(a, b) {
            const ia = a.indexInConv != null ? a.indexInConv : 1e9;
            const ib = b.indexInConv != null ? b.indexInConv : 1e9;
            return ia - ib;
        });

        const panel = document.getElementById('question-nav-panel');
        if (panel) refreshQuestionList(panel);
    }

    function getVListRowTransformY(el) {
        const row = el && el.closest ? el.closest('.v_list_row') : null;
        if (!row) return null;
        const raw = row.style.getPropertyValue('--vlist-row-transform-y') || getComputedStyle(row).getPropertyValue('--vlist-row-transform-y');
        if (!raw) return null;
        const px = parseFloat(String(raw).trim());
        return Number.isFinite(px) ? px : null;
    }

    function getRenderedSendRowBounds() {
        const rows = document.querySelectorAll('.v_list_row');
        let minY = null, maxY = null, minIndex = null, maxIndex = null;
        rows.forEach(function(row) {
            if (!row.querySelector('[data-testid="send_message"]')) return;
            const raw = row.style.getPropertyValue('--vlist-row-transform-y') || getComputedStyle(row).getPropertyValue('--vlist-row-transform-y');
            if (!raw) return;
            const px = parseFloat(String(raw).trim());
            if (!Number.isFinite(px)) return;
            const msgEl = row.querySelector('[data-message-id]');
            const id = msgEl && msgEl.getAttribute('data-message-id');
            const rec = id ? QuestionState.doubaoMessages.find(function(m) { return m.id === id; }) : null;
            const idx = rec && rec.indexInConv != null ? rec.indexInConv : null;
            if (minY === null || px < minY) { minY = px; }
            if (maxY === null || px > maxY) { maxY = px; }
            if (idx != null) {
                minIndex = minIndex === null ? idx : Math.min(minIndex, idx);
                maxIndex = maxIndex === null ? idx : Math.max(maxIndex, idx);
            }
        });
        return { minY: minY, maxY: maxY, minIndex: minIndex, maxIndex: maxIndex };
    }

    function scrollToMessageByIndex(container, indexInConv, messageId) {
        const waitMsAfterJump = 380;
        const maxJumps = 60;

        function findEl() {
            return document.querySelector('[data-message-id="' + messageId + '"]');
        }

        function scrollToEl(el) {
            const ty = getVListRowTransformY(el);
            if (ty != null && container) {
                container.scrollTop = Math.max(0, ty - 20);
            } else {
                el.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }

        return new Promise(function(resolve) {
            function check() {
                const el = findEl();
                if (el) {
                    scrollToEl(el);
                    resolve(true);
                    return true;
                }
                return false;
            }

            function waitThen(next) {
                setTimeout(function() {
                    if (check()) return;
                    next();
                }, waitMsAfterJump);
            }

            function tryJumpUp(jumps, lastMinY) {
                if (check()) return;
                if (jumps >= maxJumps) { resolve(false); return; }
                const bounds = getRenderedSendRowBounds();
                if (bounds.minY == null) {
                    if (container.scrollTop <= 0) { resolve(false); return; }
                    waitThen(function() { tryJumpUp(jumps + 1, lastMinY); });
                    return;
                }
                if (container.scrollTop <= 0 && bounds.minY >= (lastMinY !== undefined ? lastMinY : Infinity)) {
                    resolve(false);
                    return;
                }
                container.scrollTop = Math.max(0, bounds.minY - 20);
                waitThen(function() { tryJumpUp(jumps + 1, bounds.minY); });
            }

            function tryJumpDown(jumps, lastMaxY) {
                if (check()) return;
                if (jumps >= maxJumps) { resolve(false); return; }
                const bounds = getRenderedSendRowBounds();
                const maxScroll = container.scrollHeight - container.clientHeight;
                if (bounds.maxY == null) {
                    if (container.scrollTop >= maxScroll) { resolve(false); return; }
                    waitThen(function() { tryJumpDown(jumps + 1, lastMaxY); });
                    return;
                }
                if (container.scrollTop >= maxScroll && bounds.maxY <= (lastMaxY !== undefined ? lastMaxY : -1)) {
                    resolve(false);
                    return;
                }
                container.scrollTop = Math.min(maxScroll, bounds.maxY - container.clientHeight * 0.3);
                waitThen(function() { tryJumpDown(jumps + 1, bounds.maxY); });
            }

            if (check()) return;

            const bounds = getRenderedSendRowBounds();
            const targetIndex = indexInConv;
            const needGoUp = bounds.minIndex != null && targetIndex < bounds.minIndex;
            const needGoDown = bounds.maxIndex != null && targetIndex > bounds.maxIndex;

            if (bounds.minY != null && bounds.maxY != null) {
                if (needGoUp) {
                    container.scrollTop = Math.max(0, bounds.minY - 20);
                    waitThen(function() { tryJumpUp(1, bounds.minY); });
                } else if (needGoDown) {
                    const maxScroll = container.scrollHeight - container.clientHeight;
                    container.scrollTop = Math.min(maxScroll, bounds.maxY - container.clientHeight * 0.3);
                    waitThen(function() { tryJumpDown(1, bounds.maxY); });
                } else {
                    container.scrollTop = Math.max(0, bounds.minY - 20);
                    waitThen(function() { tryJumpDown(1, bounds.maxY); });
                }
            } else {
                if (bounds.minY != null) {
                    container.scrollTop = Math.max(0, bounds.minY - 20);
                    waitThen(function() { tryJumpUp(1, bounds.minY); });
                } else {
                    resolve(false);
                }
            }
        });
    }

    function findDoubaoScrollContainer() {
        const sample = document.querySelector('[data-message-id]');
        if (sample) {
            let p = sample.parentElement;
            while (p && p !== document.body) {
                const style = getComputedStyle(p);
                const oy = style.overflowY || style.overflow;
                if ((oy === 'auto' || oy === 'scroll') && p.scrollHeight > p.clientHeight) return p;
                p = p.parentElement;
            }
        }
        const scrollables = document.querySelectorAll('[data-testid="message-block-container"], [class*="scroll"], main');
        for (let i = 0; i < scrollables.length; i++) {
            const el = scrollables[i];
            const style = getComputedStyle(el);
            const oy = style.overflowY || style.overflow;
            if ((oy === 'auto' || oy === 'scroll') && el.scrollHeight > el.clientHeight) return el;
        }
        return document.scrollingElement || document.documentElement;
    }

    function getQuestions() {
        if (QuestionState.doubaoMessages.length > 0) {
            return QuestionState.doubaoMessages.map(function(msg) {
                const el = document.querySelector('[data-message-id="' + msg.id + '"]');
                return { text: msg.text, id: msg.id, indexInConv: msg.indexInConv, el: el, isRendered: !!el };
            });
        }
        const domItems = Array.from(document.querySelectorAll('[data-testid="message_content"]'));
        const userItems = domItems.filter(function(el) { return el.classList.contains('justify-end') || el.closest('.justify-end'); });
        return userItems.map(function(el) { return { text: el.textContent.trim(), el: el, isRendered: true }; });
    }

    function createNavPanel() {
        const panel = document.createElement('div');
        panel.id = 'question-nav-panel';
        panel.innerHTML = ttPolicy.createHTML(
            '<div class="qnav-resize-handle" title="拖动调整宽度"></div>' +
            '<div class="qnav-header">' +
                '<span class="qnav-title">▼ 提问列表</span>' +
                '<span class="qnav-close" title="关闭">✕</span>' +
            '</div>' +
            '<div class="qnav-list"></div>'
        );

        const navStyle = document.createElement('style');
        navStyle.textContent = '\
            #question-nav-panel {\
                position: fixed; width: 220px; max-height: 80vh;\
                top: 50%; transform: translateY(-50%); right: 16px;\
                background: #fff;\
                border: 1px solid #e0e0e0; border-radius: 8px;\
                box-shadow: 0 4px 12px rgba(0,0,0,0.25); z-index: 99999;\
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; font-size: 14px;\
                display: flex; flex-direction: column;\
                transition: width 0.2s, max-height 0.2s;\
            }\
            #question-nav-panel .qnav-resize-handle {\
                position: absolute; left: 0; top: 0; bottom: 0; width: 6px; cursor: ew-resize; z-index: 10;\
            }\
            #question-nav-panel .qnav-header {\
                display: flex; align-items: center; justify-content: space-between;\
                padding: 8px 10px; cursor: move; user-select: none;\
                border-bottom: 1px solid #eee; border-radius: 8px 8px 0 0;\
                color: #333; font-size: 14px;\
            }\
            #question-nav-panel .qnav-title { color: #333; font-weight: 600; }\
            #question-nav-panel .qnav-close {\
                cursor: pointer; margin-left: 8px; color: #999; width: 20px; height: 20px;\
                display: flex; align-items: center; justify-content: center; border-radius: 50%;\
                transition: all 0.2s ease; flex-shrink: 0; font-size: 14px;\
            }\
            #question-nav-panel .qnav-close:hover { background: #dadada; color: #333; }\
            #question-nav-panel .qnav-list {\
                overflow-y: auto; padding: 4px; flex: 1; min-height: 0;\
                background: #fff; border-radius: 0 0 8px 8px;\
            }\
            #question-nav-panel .qnav-item {\
                display: block; width: 100%; height: 32px; padding: 0 10px; line-height: 32px;\
                text-align: left; background: transparent; border: none; border-radius: 6px;\
                color: #333; cursor: pointer; font-size: 14px;\
                transition: all 0.2s ease;\
                white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\
            }\
            #question-nav-panel .qnav-item:hover { background: #dadada; color: #333; }\
            #question-nav-panel .qnav-item.qnav-item-active { background: #e8e8e8; color: #333; font-weight: 600; }\
            #question-nav-panel .qnav-item.qnav-not-rendered { opacity: 0.5; }\
            .qnav-control-bar {\
                position: fixed;\
                top: 50%;\
                right: 16px;\
                transform: translateY(-50%);\
                display: flex;\
                flex-direction: column;\
                gap: 8px;\
                z-index: 99998;\
            }\
            .qnav-ctrl-btn {\
                width: 36px;\
                height: 36px;\
                border: 1px solid #e0e0e0;\
                border-radius: 8px;\
                background: #fff;\
                color: #555;\
                font-size: 16px;\
                cursor: pointer;\
                display: flex;\
                align-items: center;\
                justify-content: center;\
                box-shadow: 0 2px 8px rgba(0,0,0,0.12);\
                transition: all 0.2s ease;\
                padding: 0;\
                line-height: 1;\
                user-select: none;\
            }\
            .qnav-ctrl-btn:hover {\
                background: #f0f0f0;\
                color: #333;\
                box-shadow: 0 2px 12px rgba(0,0,0,0.2);\
                border-color: #ccc;\
            }\
            .qnav-ctrl-btn:active {\
                background: #e0e0e0;\
                transform: scale(0.95);\
            }\
            @keyframes qnav-highlight {\
                0% { box-shadow: 0 0 0 0 rgba(66, 133, 244, 0.5); }\
                50% { box-shadow: 0 0 0 8px rgba(66, 133, 244, 0); }\
                100% { box-shadow: 0 0 0 0 rgba(66, 133, 244, 0); }\
            }\
            .qnav-page-highlight {\
                animation: qnav-highlight 1.2s ease-out;\
                background: rgba(66, 133, 244, 0.08);\
                border-radius: 8px;\
            }\
        ';
        document.head.appendChild(navStyle);
        document.body.appendChild(panel);
        panel.style.display = 'none';

        const closeBtn = panel.querySelector('.qnav-close');
        closeBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            panel.style.display = 'none';
            const toggleBtn = document.querySelector('.qnav-ctrl-toggle');
            if (toggleBtn) toggleBtn.classList.add('qnav-panel-hidden');
        });

        document.addEventListener('keydown', function escHandler(e) {
            if (e.key === 'Escape') {
                panel.style.display = 'none';
                const toggleBtn = document.querySelector('.qnav-ctrl-toggle');
                if (toggleBtn) toggleBtn.classList.add('qnav-panel-hidden');
            }
        });

        const header = panel.querySelector('.qnav-header');
        header.addEventListener('mousedown', function(e) {
            if (e.button !== 0) return;
            const rect = panel.getBoundingClientRect();
            const startX = e.clientX, startY = e.clientY, startLeft = rect.left, startTop = rect.top;
            panel.style.top = startTop + 'px';
            panel.style.transform = 'none';
            const onMove = function(ev) {
                panel.style.right = 'auto';
                panel.style.left = (startLeft + ev.clientX - startX) + 'px';
                panel.style.top = (startTop + ev.clientY - startY) + 'px';
            };
            const onUp = function() { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
            window.addEventListener('mousemove', onMove);
            window.addEventListener('mouseup', onUp);
        });

        const handle = panel.querySelector('.qnav-resize-handle');
        handle.addEventListener('mousedown', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const rect = panel.getBoundingClientRect();
            const startX = e.clientX, startW = rect.width, rightEdge = rect.right;
            const onMove = function(ev) {
                const dx = ev.clientX - startX;
                const newW = Math.max(120, Math.min(500, startW - dx));
                panel.style.left = 'auto';
                panel.style.right = (window.innerWidth - rightEdge) + 'px';
                panel.style.width = newW + 'px';
            };
            const onUp = function() { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
            window.addEventListener('mousemove', onMove);
            window.addEventListener('mouseup', onUp);
        });

        return panel;
    }

    function highlightPageEl(el) {
        if (QuestionState.highlightedEl && QuestionState.highlightedEl !== el) {
            QuestionState.highlightedEl.classList.remove('qnav-page-highlight');
        }
        QuestionState.highlightedEl = el;
        el.classList.remove('qnav-page-highlight');
        void el.offsetWidth;
        el.classList.add('qnav-page-highlight');
    }

    function createControlBar() {
        const bar = document.createElement('div');
        bar.className = 'qnav-control-bar';
        bar.innerHTML = '\
            <button class="qnav-ctrl-btn qnav-ctrl-prev" title="上一个提问"><span style="display:flex;align-items:center;justify-content:center;transform:rotate(90deg);font-size:20px;width:20px;height:20px;margin-left:4px">‹</span></button>\
            <button class="qnav-ctrl-btn qnav-ctrl-toggle" title="显示/隐藏导航列表">☰</button>\
            <button class="qnav-ctrl-btn qnav-ctrl-next" title="下一个提问"><span style="display:flex;align-items:center;justify-content:center;transform:rotate(90deg);font-size:20px;width:20px;height:20px;margin-left:4px">›</span></button>\
        ';

        const getPanel = function() { return document.getElementById('question-nav-panel'); };
        const toggleBtn = bar.querySelector('.qnav-ctrl-toggle');
        toggleBtn.classList.add('qnav-panel-hidden');

        function navigateToItem(targetIndex) {
            const panel = getPanel();
            if (!panel) return;
            const items = getQuestions();
            if (items.length === 0) return;
            if (targetIndex < 0 || targetIndex >= items.length) return;
            QuestionState.activeIndex = targetIndex;
            refreshQuestionList(panel);
            const item = items[targetIndex];
            let el = item.el;
            if (!el && item.id) el = document.querySelector('[data-message-id="' + item.id + '"]');
            if (el) {
                highlightPageEl(el);
                const container = findDoubaoScrollContainer();
                const ty = getVListRowTransformY(el);
                if (container && ty != null) {
                    container.scrollTop = Math.max(0, ty - 20);
                } else {
                    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
                return;
            }
            if (item.indexInConv != null) {
                const container = findDoubaoScrollContainer();
                if (container) {
                    scrollToMessageByIndex(container, item.indexInConv, item.id).then(function(found) {
                        if (found) {
                            const foundEl = document.querySelector('[data-message-id="' + item.id + '"]');
                            if (foundEl) highlightPageEl(foundEl);
                        }
                    });
                }
            }
        }

        bar.querySelector('.qnav-ctrl-prev').addEventListener('click', function() {
            navigateToItem(QuestionState.activeIndex - 1);
        });

        bar.querySelector('.qnav-ctrl-next').addEventListener('click', function() {
            navigateToItem(QuestionState.activeIndex + 1);
        });

        toggleBtn.addEventListener('click', function() {
            const panel = getPanel();
            if (!panel) return;
            if (panel.style.display === 'none') {
                const barRect = bar.getBoundingClientRect();
                panel.style.display = '';
                panel.style.top = '';
                panel.style.left = '';
                panel.style.transform = '';
                panel.style.right = (window.innerWidth - barRect.left + 4) + 'px';
                toggleBtn.classList.remove('qnav-panel-hidden');
                refreshQuestionList(panel);
            } else {
                panel.style.display = 'none';
                toggleBtn.classList.add('qnav-panel-hidden');
            }
        });

        document.body.appendChild(bar);
        return bar;
    }

    function refreshQuestionList(panel) {
        const listEl = panel.querySelector('.qnav-list');
        const items = getQuestions();

        listEl.innerHTML = '';
        if (items.length === 0) {
            listEl.innerHTML = '<div style="color:#666;padding:8px;font-size:12px;">列表为空 / 待加载</div>';
            return;
        }

        items.forEach(function(item, index) {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'qnav-item';
            btn.textContent = (index + 1) + '、' + item.text.replace(/\s+/g, ' ').slice(0, 40);
            btn.title = item.isRendered ? '点击滚动到此处' : '此提问不在当前屏幕范围内（虚拟列表），请滚动页面加载';
            if (!item.isRendered) btn.classList.add('qnav-not-rendered');

            if (index === QuestionState.activeIndex) {
                btn.classList.add('qnav-item-active');
            }

            btn.addEventListener('click', function() {
                QuestionState.activeIndex = index;
                let el = item.el;
                if (!el && item.id) el = document.querySelector('[data-message-id="' + item.id + '"]');

                if (el) {
                    highlightPageEl(el);
                    const container = findDoubaoScrollContainer();
                    const ty = getVListRowTransformY(el);
                    if (container && ty != null) {
                        container.scrollTop = Math.max(0, ty - 20);
                    } else {
                        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }
                    listEl.querySelectorAll('.qnav-item').forEach(function(b) { b.classList.remove('qnav-item-active'); });
                    btn.classList.add('qnav-item-active');
                    btn.classList.remove('qnav-not-rendered');
                    return;
                }

                if (item.indexInConv != null) {
                    const container = findDoubaoScrollContainer();
                    if (!container) {
                        alert('未找到可滚动的对话容器，请手动滚动页面。');
                        return;
                    }
                    listEl.querySelectorAll('.qnav-item').forEach(function(b) { b.classList.remove('qnav-item-active'); });
                    btn.classList.add('qnav-item-active');
                    scrollToMessageByIndex(container, item.indexInConv, item.id).then(function(found) {
                        if (found) {
                            btn.classList.remove('qnav-not-rendered');
                            const foundEl = document.querySelector('[data-message-id="' + item.id + '"]');
                            if (foundEl) highlightPageEl(foundEl);
                        }
                    });
                } else {
                    alert('该提问暂未渲染（被虚拟列表回收），请手动滚动页面寻找。');
                }
            });
            listEl.appendChild(btn);
        });
    }

    function initQuestionNav() {
        let panel = document.getElementById('question-nav-panel');
        if (!panel) panel = createNavPanel();
        refreshQuestionList(panel);
        let bar = document.querySelector('.qnav-control-bar');
        if (!bar) bar = createControlBar();
    }

    var rawUrlSet = {};
    var collectedImageInfos = [];

    function addRawUrl(url) {
        if (url && !rawUrlSet[url]) {
            rawUrlSet[url] = true;
        }
    }

    function addImageInfo(info) {
        if (!info) return;
        var exists = collectedImageInfos.some(function(item) {
            return item.previewImage.url === info.previewImage.url;
        });
        if (!exists) {
            collectedImageInfos.push(info);
        }
    }

    function findAllKeys(obj, key) {
        const results = [];
        function search(current) {
            if (current && typeof current === 'object') {
                if (!Array.isArray(current) && Object.prototype.hasOwnProperty.call(current, key)) {
                    results.push(current[key]);
                }
                const items = Array.isArray(current) ? current : Object.values(current);
                for (const item of items) {
                    search(item);
                }
            }
        }
        search(obj);
        return results;
    }

    var _parse = JSON.parse;
    JSON.parse = function(data, reviver) {
        var jsonData = _parse(data, reviver);
        try {
            if (typeof data !== 'string') return jsonData;
            if (data.indexOf('creations') === -1 && data.indexOf('image_ori') === -1) return jsonData;

            var creations = findAllKeys(jsonData, 'creations');
            if (creations.length > 0) {
                creations.forEach(function(creation) {
                    if (!Array.isArray(creation)) return;
                    creation.forEach(function(item) {
                        var img = item.image;
                        if (!img) return;

                        if (img.image_ori_raw && img.image_ori_raw.url) {
                            var rawUrl = img.image_ori_raw.url;
                            addRawUrl(rawUrl);
                            if (img.image_preview && img.image_preview.url) {
                                var dlUrl = img.image_ori ? img.image_ori.url : '';
                                addImageInfo({
                                    previewImage: { url: img.image_preview.url },
                                    downloadImage: { url: dlUrl || img.image_preview.url },
                                    rawUrl: rawUrl
                                });
                            }
                            if (img.image_ori) img.image_ori.url = rawUrl;
                            if (img.image_preview) img.image_preview.url = rawUrl;
                            if (img.image_thumb) img.image_thumb.url = rawUrl;
                        }
                    });
                });
            }
        } catch (e) {}

        try {
            if (jsonData && jsonData.data && jsonData.data.image_ori_raw && jsonData.data.image_ori_raw.url) {
                var rawUrl = jsonData.data.image_ori_raw.url;
                if (jsonData.data.image_ori) jsonData.data.image_ori.url = rawUrl;
                if (jsonData.data.image_preview) jsonData.data.image_preview.url = rawUrl;
                if (jsonData.data.image_thumb) jsonData.data.image_thumb.url = rawUrl;
            }
        } catch (e) {}

        return jsonData;
    };

    function gmFetchBlob(url) {
        return new Promise(function(resolve, reject) {
            GM_xmlhttpRequest({
                method: 'GET',
                url: url,
                responseType: 'blob',
                timeout: 30000,
                onload: function(res) {
                    if (res.status >= 200 && res.status < 400) {
                        resolve(res.response);
                    } else {
                        reject(new Error('HTTP ' + res.status));
                    }
                },
                onerror: function(err) {
                    reject(new Error('请求失败'));
                },
                ontimeout: function() {
                    reject(new Error('请求超时'));
                }
            });
        });
    }

    function downloadBlob(blob, filename) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.style.display = 'none';
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(function() { URL.revokeObjectURL(url); }, 1000);
    }

    function collectImageInfosFromDOM() {
        var imgs = document.querySelectorAll('img');
        imgs.forEach(function(img) {
            var info = getImageInfo(img);
            if (info) addImageInfo(info);
        });
    }

    function downloadRawImage(url, index, total) {
        return new Promise(function(resolve, reject) {
            gmFetchBlob(url).then(function(blob) {
                var filename = '豆包无水印_' + (index + 1) + '_' + new Date().toISOString().replace(/[:.]/g, '-') + '.png';
                downloadBlob(blob, filename);
                resolve();
            }).catch(function(err) {
                reject(err);
            });
        });
    }

    function downloadMergedImage(imageInfo, index, total) {
        return new Promise(function(resolve, reject) {
            var urlA = imageInfo.previewImage.url;
            var urlB = imageInfo.downloadImage.url;
            Promise.all([
                gmFetchBlob(urlA),
                gmFetchBlob(urlB)
            ]).then(function(refs) {
                return mergeImages(refs[0], refs[1]);
            }).then(function(merged) {
                var filename = '豆包无水印_' + (index + 1) + '_' + new Date().toISOString().replace(/[:.]/g, '-') + '.png';
                downloadBlob(merged, filename);
                resolve();
            }).catch(function(err) {
                reject(err);
            });
        });
    }

    function buildImageList() {
        collectImageInfosFromDOM();
        var items = [];
        var seen = {};

        collectedImageInfos.forEach(function(info) {
            var previewUrl = info.previewImage && info.previewImage.url;
            if (!previewUrl) return;
            if (seen[previewUrl]) return;
            seen[previewUrl] = true;
            items.push({
                previewUrl: previewUrl,
                downloadUrl: info.downloadImage ? info.downloadImage.url : previewUrl,
                rawUrl: info.rawUrl || ''
            });
        });

        var rawKeys = Object.keys(rawUrlSet);
        rawKeys.forEach(function(rawUrl) {
            var alreadyIn = items.some(function(item) { return item.rawUrl === rawUrl; });
            if (!alreadyIn) {
                items.push({
                    previewUrl: rawUrl,
                    downloadUrl: rawUrl,
                    rawUrl: rawUrl
                });
            }
        });

        return items;
    }

    function showImageSelectDialog() {
        var imageItems = buildImageList();

        if (imageItems.length === 0) {
            showToast('未检测到任何图片，请先生成图片后再试', 4000);
            return;
        }

        var overlay = document.createElement('div');
        overlay.className = 'doubao-select-overlay';

        var dialog = document.createElement('div');
        dialog.className = 'doubao-select-dialog';

        var header = document.createElement('div');
        header.className = 'doubao-select-header';
        header.innerHTML = '<span class="title">选择要下载的图片</span>' +
            '<button class="close-btn">&times;</button>';
        dialog.appendChild(header);

        var toolbar = document.createElement('div');
        toolbar.className = 'doubao-select-toolbar';
        toolbar.innerHTML = '<div class="toolbar-left">' +
            '<button class="tool-btn" data-action="select-all">全选</button>' +
            '<span class="tool-divider"></span>' +
            '<button class="tool-btn" data-action="invert">反选</button>' +
            '<span class="tool-divider"></span>' +
            '<button class="tool-btn danger" data-action="deselect-all">取消全选</button>' +
            '</div>' +
            '<span class="count-text">已选 0 / ' + imageItems.length + ' 张</span>';
        dialog.appendChild(toolbar);

        var grid = document.createElement('div');
        grid.className = 'doubao-select-grid';

        var selectedSet = {};
        imageItems.forEach(function(_, i) { selectedSet[i] = true; });

        function updateCount() {
            var count = Object.values(selectedSet).filter(Boolean).length;
            toolbar.querySelector('.count-text').textContent = '已选 ' + count + ' / ' + imageItems.length + ' 张';
            var confirmBtn = dialog.querySelector('.confirm-btn');
            confirmBtn.disabled = count === 0;
            confirmBtn.textContent = '下载选中 (' + count + ')';
        }

        imageItems.forEach(function(item, i) {
            var card = document.createElement('div');
            card.className = 'doubao-select-item checked';
            card.title = '第 ' + (i + 1) + ' 张';

            var img = document.createElement('img');
            img.src = item.previewUrl;
            img.loading = 'lazy';
            img.alt = '图片 ' + (i + 1);
            img.onerror = function() {
                img.style.display = 'none';
            };
            card.appendChild(img);

            var badge = document.createElement('div');
            badge.className = 'index-badge';
            badge.textContent = (i + 1);
            card.appendChild(badge);

            var cb = document.createElement('div');
            cb.className = 'checkbox';
            cb.textContent = '✓';
            card.appendChild(cb);

            card.addEventListener('click', function() {
                selectedSet[i] = !selectedSet[i];
                if (selectedSet[i]) {
                    card.classList.add('checked');
                } else {
                    card.classList.remove('checked');
                }
                updateCount();
            });

            grid.appendChild(card);
        });

        dialog.appendChild(grid);

        var footer = document.createElement('div');
        footer.className = 'doubao-select-footer';
        footer.innerHTML = '<button class="cancel-btn">取消</button>' +
            '<button class="confirm-btn">下载选中 (' + imageItems.length + ')</button>';
        dialog.appendChild(footer);

        updateCount();

        overlay.appendChild(dialog);
        document.body.appendChild(overlay);

        var confirmBtn = footer.querySelector('.confirm-btn');
        var cancelBtn = footer.querySelector('.cancel-btn');
        var closeBtn = header.querySelector('.close-btn');
        var toolbarLeft = toolbar.querySelector('.toolbar-left');

        function setAllChecked(checked) {
            imageItems.forEach(function(_, i) {
                selectedSet[i] = checked;
                var cards = grid.querySelectorAll('.doubao-select-item');
                if (cards[i]) {
                    if (checked) {
                        cards[i].classList.add('checked');
                    } else {
                        cards[i].classList.remove('checked');
                    }
                }
            });
            updateCount();
        }

        function close() {
            overlay.remove();
        }

        closeBtn.addEventListener('click', close);
        cancelBtn.addEventListener('click', close);

        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) close();
        });

        document.addEventListener('keydown', function escHandler(e) {
            if (e.key === 'Escape') {
                close();
                document.removeEventListener('keydown', escHandler);
            }
        });

        toolbarLeft.addEventListener('click', function(e) {
            var btn = e.target.closest('.tool-btn');
            if (!btn) return;
            var action = btn.getAttribute('data-action');

            if (action === 'select-all') {
                setAllChecked(true);
            } else if (action === 'deselect-all') {
                setAllChecked(false);
            } else if (action === 'invert') {
                imageItems.forEach(function(_, i) {
                    selectedSet[i] = !selectedSet[i];
                    var cards = grid.querySelectorAll('.doubao-select-item');
                    if (cards[i]) {
                        if (selectedSet[i]) {
                            cards[i].classList.add('checked');
                        } else {
                            cards[i].classList.remove('checked');
                        }
                    }
                });
                updateCount();
            }
        });

        confirmBtn.addEventListener('click', function() {
            var selectedIndices = [];
            imageItems.forEach(function(_, i) {
                if (selectedSet[i]) selectedIndices.push(i);
            });

            if (selectedIndices.length === 0) {
                showToast('请至少选择一张图片', 3000);
                return;
            }

            var selectedItems = selectedIndices.map(function(i) { return imageItems[i]; });
            overlay.style.display = 'none';
            downloadSelectedImages(selectedItems);
        });
    }

    async function downloadSelectedImages(selectedItems) {
        var total = selectedItems.length;
        var successCount = 0;
        var failCount = 0;
        var progressToast = showToast('正在下载第 1/' + total + ' 张图片…', 0);

        for (var i = 0; i < total; i++) {
            progressToast.textContent = '正在下载第 ' + (i + 1) + '/' + total + ' 张图片…';
            var item = selectedItems[i];
            try {
                if (item.rawUrl) {
                    await downloadRawImage(item.rawUrl, i, total);
                } else {
                    await downloadMergedImage(
                        { previewImage: { url: item.previewUrl }, downloadImage: { url: item.downloadUrl } },
                        i, total
                    );
                }
                successCount++;
            } catch (err) {
                failCount++;
                console.error('[豆包批量下载] 第' + (i + 1) + '张失败:', err);
            }
            if (i < total - 1) {
                await new Promise(function(r) { setTimeout(r, 500); });
            }
        }

        progressToast.remove();
        if (failCount === 0) {
            showToast('全部下载完成！共 ' + successCount + ' 张无水印图片', 4000);
        } else {
            showToast('下载完成：成功 ' + successCount + ' 张，失败 ' + failCount + ' 张', 5000);
        }
    }

    function mergeImages(blobA, blobB) {
        return new Promise(function(resolve, reject) {
            var imgA = new Image();
            var imgB = new Image();
            var loaded = 0;

            function onLoad() {
                loaded++;
                if (loaded < 2) return;
                try {
                    var canvas = document.createElement('canvas');
                    canvas.width = imgA.width;
                    canvas.height = imgA.height;
                    var ctx = canvas.getContext('2d');

                    ctx.drawImage(imgA, 0, 0);

                    var halfW = Math.ceil(imgA.width / 2);
                    var halfH = Math.ceil(imgA.height / 2);

                    if (imgA.width !== imgB.width || imgA.height !== imgB.height) {
                        var tmp = document.createElement('canvas');
                        tmp.width = imgA.width;
                        tmp.height = imgA.height;
                        tmp.getContext('2d').drawImage(imgB, 0, 0, imgA.width, imgA.height);
                        ctx.drawImage(tmp, 0, 0, halfW, halfH, 0, 0, halfW, halfH);
                    } else {
                        ctx.drawImage(imgB, 0, 0, halfW, halfH, 0, 0, halfW, halfH);
                    }

                    canvas.toBlob(function(blob) {
                        if (blob) {
                            resolve(blob);
                        } else {
                            reject(new Error('Canvas toBlob failed'));
                        }
                    }, 'image/png');
                } catch (err) {
                    reject(err);
                }
            }

            imgA.onload = onLoad;
            imgB.onload = onLoad;
            imgA.onerror = function() { reject(new Error('加载图片A失败')); };
            imgB.onerror = function() { reject(new Error('加载图片B失败')); };
            imgA.src = URL.createObjectURL(blobA);
            imgB.src = URL.createObjectURL(blobB);
        });
    }

    function getImageInfo(imgEl) {
        // 1) 尝试通过 React fiber 链查找 realImageInfo
        var fiberKey = Object.keys(imgEl).find(function(k) { return k.startsWith('__reactFiber'); });
        if (fiberKey) {
            var fiber = imgEl[fiberKey];
            var depth = 0;
            while (fiber && depth < 30) {
                var props = fiber.memoizedProps;
                if (props && props.realImageInfo && props.realImageInfo.previewImage && props.realImageInfo.previewImage.url &&
                    props.realImageInfo.downloadImage && props.realImageInfo.downloadImage.url) {
                    return props.realImageInfo;
                }
                fiber = fiber.return;
                depth++;
            }
        }

        // 2) fiber 查找失败，通过图片 src URL 反查已收集的图片信息
        var src = imgEl.src || imgEl.getAttribute('src') || '';
        if (src) {
            // 在 collectedImageInfos 中匹配
            for (var i = 0; i < collectedImageInfos.length; i++) {
                var info = collectedImageInfos[i];
                if (!info) continue;
                var previewUrl = (info.previewImage && info.previewImage.url) || '';
                var downloadUrl = (info.downloadImage && info.downloadImage.url) || '';
                var rawUrl = info.rawUrl || '';
                if (src === previewUrl || src === downloadUrl || src === rawUrl) {
                    return info;
                }
            }
            // 在 rawUrlSet 中匹配，构造简易 info
            if (rawUrlSet[src]) {
                return {
                    previewImage: { url: src },
                    downloadImage: { url: src },
                    rawUrl: src
                };
            }
        }

        return null;
    }

    var batchBtnInjected = false;

    function injectBatchButton() {
        if (batchBtnInjected) {
            var existingBtn = document.querySelector('.doubao-batch-dl-btn');
            if (existingBtn && existingBtn.offsetParent !== null) return;
            batchBtnInjected = false;
        }

        var allElements = document.querySelectorAll('button, [role="button"], span, div');
        for (var i = 0; i < allElements.length; i++) {
            var el = allElements[i];
            var text = (el.textContent || '').trim();
            if (text === '保存' && el.offsetParent !== null) {
                var parent = el.parentElement;
                if (!parent) continue;
                if (parent.querySelector('.doubao-batch-dl-btn')) continue;

                var batchBtn = document.createElement('div');
                batchBtn.className = 'doubao-batch-dl-btn';
                batchBtn.innerHTML = '<span role="img" style="display:inline-flex;vertical-align:middle;">' +
            '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">' +
            '<path d="M18 15v3H6v-3H4v3c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-3h-2zm-1-4l-1.41-1.41L13 12.17V4h-2v8.17L8.41 9.59 7 11l5 5 5-5z"/>' +
            '</svg></span>去水印下载';


                batchBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    e.preventDefault();
                    showImageSelectDialog();
                });

                parent.insertBefore(batchBtn, el);
                batchBtnInjected = true;
                return;
            }
        }
    }

    var batchBtnObserver = new MutationObserver(function() {
        injectBatchButton();
    });
    batchBtnObserver.observe(document.body, { childList: true, subtree: true });

    var capturedImageInfo = null;
    var capturedImageEl = null;

    document.addEventListener('contextmenu', function(e) {
        var img = e.target.closest && e.target.closest('img');
        if (!img) img = e.target.tagName === 'IMG' ? e.target : null;
        capturedImageEl = img;
        if (!img) {
            // 大图预览中可能没有 img 标签，尝试从点击位置附近的预览容器中找
            capturedImageInfo = null;
            return;
        }
        capturedImageInfo = getImageInfo(img);
    }, true);

    // 通过 src URL 模糊匹配已收集的图片信息（处理不同域名/路径的 URL）
    function fuzzyMatchImageInfoBySrc(src) {
        if (!src) return null;
        // 去除查询参数和末尾斜杠，统一比较
        var cleanSrc = src.replace(/[?#].*$/, '').replace(/\/$/, '');

        function matchCollected(infos) {
            for (var i = 0; i < infos.length; i++) {
                var info = infos[i];
                if (!info) continue;
                var urls = [
                    info.previewImage && info.previewImage.url,
                    info.downloadImage && info.downloadImage.url,
                    info.rawUrl
                ];
                for (var u = 0; u < urls.length; u++) {
                    var url = urls[u];
                    if (!url) continue;
                    var cleanUrl = url.replace(/[?#].*$/, '').replace(/\/$/, '');
                    // 去掉查询参数后精确匹配
                    if (cleanSrc === cleanUrl) return info;
                    // 尾部路径匹配（忽略域名差异，比对最后 40 个字符）
                    if (cleanSrc.length > 30 && cleanUrl.length > 30 && cleanSrc.slice(-40) === cleanUrl.slice(-40)) {
                        return info;
                    }
                }
            }
            return null;
        }

        var result = matchCollected(collectedImageInfos);
        if (result) return result;

        // 在 rawUrlSet 中模糊匹配
        for (var rawUrl in rawUrlSet) {
            if (!rawUrlSet.hasOwnProperty(rawUrl)) continue;
            var cleanRaw = rawUrl.replace(/[?#].*$/, '').replace(/\/$/, '');
            if (cleanSrc === cleanRaw || (cleanSrc.length > 30 && cleanRaw.length > 30 && cleanSrc.slice(-40) === cleanRaw.slice(-40))) {
                return {
                    previewImage: { url: rawUrl },
                    downloadImage: { url: rawUrl },
                    rawUrl: rawUrl
                };
            }
        }

        return null;
    }

    // 在菜单点击时主动查找图片信息（兜底方案）
    function findImageInfoAtClickTime() {
        // 1) 先用预先捕获的（精确匹配）
        if (capturedImageInfo) return capturedImageInfo;

        // 1.5) 用右键元素的 src 做模糊匹配（处理域名/路径不一致）
        if (capturedImageEl) {
            var src = capturedImageEl.src || capturedImageEl.getAttribute('src') || '';
            var fuzzyInfo = fuzzyMatchImageInfoBySrc(src);
            if (fuzzyInfo) return fuzzyInfo;
        }

        // 2) 尝试在大图预览弹窗中查找图片
        var previewSelectors = [
            '[class*="preview"] img',
            '[class*="Preview"] img',
            '[class*="lightbox"] img',
            '[class*="image-viewer"] img',
            '[class*="ImageViewer"] img',
            '[class*="modal"] img',
            '[class*="Modal"] img',
            '[class*="dialog"] img',
            '[class*="Dialog"] img',
            '[class*="overlay"] img',
            '[class*="Overlay"] img',
            '[class*="preview"] canvas',
            '[class*="Preview"] canvas'
        ];
        for (var s = 0; s < previewSelectors.length; s++) {
            try {
                var el = document.querySelector(previewSelectors[s]);
                if (el) {
                    var info = getImageInfo(el);
                    if (info) return info;
                }
            } catch (_) {}
        }

        // 3) 遍历页面上所有图片，用 URL 反查
        collectImageInfosFromDOM();
        var imgs = document.querySelectorAll('img');
        for (var i = 0; i < imgs.length; i++) {
            var info = getImageInfo(imgs[i]);
            if (info && info.previewImage && info.previewImage.url) return info;
        }

        return null;
    }

    function injectContextMenuItem() {
        // 匹配多种可能的右键菜单容器：Semi Design 的 dropdown-content，以及 CSS Module 的 context-menu
        var menu = document.querySelector('div.semi-dropdown-content, [class*="context-menu"]');
        if (!menu || menu.querySelector('.db-wm-menu-item')) return;
        if (menu.children.length === 0) return;

        var firstItem = menu.querySelector('div');
        if (!firstItem) return;

        var itemClass = firstItem.className || '';

        var btn = document.createElement('div');
        btn.className = itemClass + ' db-wm-menu-item';
        btn.innerHTML = '<span role="img" style="margin-left:4px;margin-right:6px;display:inline-flex;vertical-align:middle;">' +
            '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">' +
            '<path d="M18 15v3H6v-3H4v3c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-3h-2zm-1-4l-1.41-1.41L13 12.17V4h-2v8.17L8.41 9.59 7 11l5 5 5-5z"/>' +
            '</svg></span>下载无水印原图';

        btn.addEventListener('click', async function(e) {
            e.stopPropagation();
            e.preventDefault();

            // 主动查找图片信息（优先用预捕获的，失败则实时查找）
            var imageInfo = findImageInfoAtClickTime();

            if (!imageInfo || !imageInfo.previewImage || !imageInfo.previewImage.url) {
                showToast('请在生成图片的大图预览界面使用此项功能', 3000);
                return;
            }

            var urlA = imageInfo.previewImage.url;
            var urlB = (imageInfo.downloadImage && imageInfo.downloadImage.url) || urlA;
            var progressToast = showToast('正在获取图片，请稍候…', 0);

            try {
                var refs = await Promise.all([
                    gmFetchBlob(urlA),
                    gmFetchBlob(urlB)
                ]);
                progressToast.textContent = '正在合并图片…';
                var merged = await mergeImages(refs[0], refs[1]);
                progressToast.remove();
                var filename = '豆包无水印_' + new Date().toISOString().replace(/[:.]/g, '-') + '.png';
                downloadBlob(merged, filename);
                showToast('下载成功！', 3000);
            } catch (err) {
                progressToast.remove();
                console.error('[豆包无水印]', err);
                showToast('下载失败：' + err.message, 4000);
            }
        });

        menu.appendChild(btn);
    }

    var menuObserver = new MutationObserver(function() {
        injectContextMenuItem();
    });
    menuObserver.observe(document.body, { childList: true, subtree: true });

    var qnavTimer;
    var qnavObserver = new MutationObserver(function() {
        if (qnavTimer) clearTimeout(qnavTimer);
        qnavTimer = setTimeout(function() {
            const panel = document.getElementById('question-nav-panel');
            if (panel) refreshQuestionList(panel);
        }, 1000);
    });
    qnavObserver.observe(document.body, { childList: true, subtree: true });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            initQuestionNav();
            setTimeout(injectBatchButton, 1500);
        });
    } else {
        initQuestionNav();
        setTimeout(injectBatchButton, 1500);
    }

})();
