// ==UserScript==
// @name                      Zhihu 知乎浏览助手
// @name:zh-CN                Zhihu 知乎浏览助手
// @name:en                   Zhihu Enhancer Tools
// @description               增强功能：批量保存图片、一键文章截图、保存为 Markdown文件（右键点击时改为复制 Markdown）、图片自动去水印、知乎视频一键下载。
// @description:zh-CN         增强功能：批量保存图片、一键文章截图、保存为 Markdown文件（右键点击时改为复制 Markdown）、图片自动去水印、知乎视频一键下载。
// @description:en            Enhanced Features: Batch save images, one-click article screenshot, export as Markdown file (switch to copy Markdown on right-click), automatic image watermark removal, one-click download for Zhihu videos.
// @namespace                 https://www.runningcheese.com/userscripts
// @author                    RunningCheese
// @version                   1.3
// @match                     https://www.zhihu.com/question/*
// @match                     https://www.zhihu.com/zvideo/*
// @match                     https://zhuanlan.zhihu.com/*
// @icon                      https://static.zhihu.com/heifetz/favicon.ico
// @require                   https://cdnjs.cloudflare.com/ajax/libs/jszip/3.9.1/jszip.min.js
// @require                   https://cdn.jsdelivr.net/npm/html-to-image@1.11.11/dist/html-to-image.js
// @license                   MIT
// @downloadURL https://update.greasyfork.org/scripts/582976/Zhihu%20%E7%9F%A5%E4%B9%8E%E6%B5%8F%E8%A7%88%E5%8A%A9%E6%89%8B.user.js
// @updateURL https://update.greasyfork.org/scripts/582976/Zhihu%20%E7%9F%A5%E4%B9%8E%E6%B5%8F%E8%A7%88%E5%8A%A9%E6%89%8B.meta.js
// ==/UserScript==



(function() {
    'use strict';

    // ==================== 图片去水印 ====================
    function removeWatermark() {
        const images = document.querySelectorAll('img[data-original-token]');
        images.forEach(img => {
            const newToken = img.dataset.originalToken;
            const newSrc = img.src.replace(/v2-[a-f0-9]+(?=_)/, newToken);
            if (newSrc !== img.src) {
                img.src = newSrc;
            }
            img.removeAttribute('data-original');
        });
    }
    removeWatermark();
    const watermarkObserver = new MutationObserver(removeWatermark);
    watermarkObserver.observe(document.body, { childList: true, subtree: true });

    // ==================== 文件保存 ====================
    function saveAs(blob, filename) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = filename; a.click();
        setTimeout(() => URL.revokeObjectURL(url), 40000);
    }

    // ==================== Toast 提示 ====================
    const toasts = [], TH = 60;
    const initToastStyle = () => {
        if (document.getElementById('toast-s')) return;
        const s = document.createElement('style');
        s.id = 'toast-s';
        s.textContent = '.zh-toast{position:fixed;top:30px;left:50%;background:#1F75EE;color:#fff;padding:14px 24px;border-radius:10px;font-size:14px;box-shadow:0 2px 12px rgba(0,0,0,.15);z-index:9999;pointer-events:none;opacity:0;transition:transform .3s}';
        document.head.appendChild(s);
    };

    function showToast(msg, dur = 1500) {
        initToastStyle();
        const t = document.createElement('div');
        t.className = 'zh-toast';
        t.textContent = msg;
        t.style.transform = `translate(-50%,${toasts.length*TH}px)`;
        document.body.appendChild(t);
        toasts.push(t);
        requestAnimationFrame(() => { t.style.opacity = '1'; });
        setTimeout(() => {
            t.style.opacity = '0';
            setTimeout(() => {
                t.remove();
                const i = toasts.indexOf(t);
                if (i > -1) {
                    toasts.splice(i, 1);
                    toasts.forEach((tt, j) => tt.style.transform = `translate(-50%,${j*TH}px)`);
                }
            }, 500);
        }, dur);
    }

    // ==================== 知乎内容提取 ====================
    const T = {
        H2: 1, H3: 2, HR: 3, Text: 4, Blockquote: 5,
        Figure: 6, Code: 7, UList: 8, Olist: 9, Table: 10,
        PlainText: 11, Bold: 12, Italic: 13, BR: 14, InlineLink: 15, InlineCode: 16, Math: 17
    };

    function zhihuLink(link) {
        try {
            const u = new URL(link);
            if (u.hostname === 'link.zhihu.com') return decodeURIComponent(u.searchParams.get('target'));
            if (link.includes('#')) return '#' + link.split('#')[1];
            return link;
        } catch (e) { return link; }
    }

    function tokenizeInline(node) {
        if (typeof node === 'string') return [{ type: T.PlainText, text: node.replace(/\t/g,'').replace(/^\s{2,}/,'') }];
        let children = Array.from(node.childNodes || []);
        try { if (children.length === 1 && children[0].tagName?.toLowerCase() === 'p') children = Array.from(children[0].childNodes); } catch (e) {}
        const res = [];
        for (const c of children) {
            if (c.nodeType === Node.TEXT_NODE) {
                res.push({ type: T.PlainText, text: c.textContent.replace(/\u200B/g,'').replace(/\t/g,'').replace(/^\s{2,}/,'') });
            } else {
                const el = c;
                switch (el.tagName.toLowerCase()) {
                    case 'b': res.push({ type: T.Bold, content: tokenizeInline(el) }); break;
                    case 'i': res.push({ type: T.Italic, content: tokenizeInline(el) }); break;
                    case 'br': res.push({ type: T.BR }); break;
                    case 'code': res.push({ type: T.InlineCode, content: el.innerText }); break;
                    case 'span':
                        try {
                            if (el.classList.contains('ztext-math')) {
                                const ct = el.getAttribute('data-tex')?.trim() || '';
                                res.push({ type: T.Math, content: ct, display: ct.includes('\\tag') });
                            } else { res.push({ type: T.PlainText, text: el.innerText }); }
                        } catch (e) { res.push({ type: T.PlainText, text: el.innerText }); }
                        break;
                    case 'a':
                        if (el.href?.startsWith('https://zhida.zhihu.com/search')) res.push({ type: T.PlainText, text: el.innerText });
                        else res.push({ type: T.InlineLink, text: el.textContent, href: zhihuLink(el.href) });
                        break;
                    default: res.push({ type: T.PlainText, text: c.textContent.replace(/\u200B/g,'').replace(/\t/g,'').replace(/^\s{2,}/,'') });
                }
            }
        }
        return res;
    }

    function lexer(input) {
        const tokens = [];
        for (const node of input) {
            const tag = node.nodeName.toLowerCase();
            switch (tag) {
                case 'h2': tokens.push({ type: T.H2, text: node.textContent }); break;
                case 'h3': tokens.push({ type: T.H3, text: node.textContent }); break;
                case 'div':
                    if (node.classList.contains('highlight')) tokens.push({ type: T.Code, content: node.textContent, language: node.querySelector('pre > code').classList.value.slice(9) });
                    else if (node.classList.contains('RichText-LinkCardContainer')) tokens.push({ type: T.Text, content: tokenizeInline(node) });
                    break;
                case 'blockquote': tokens.push({ type: T.Blockquote, content: tokenizeInline(node) }); break;
                case 'figure': {
                    const img = node.querySelector('img');
                    if (img) {
                        const src = img.getAttribute('data-actualsrc') || img.getAttribute('data-original') || img.src;
                        if (src) tokens.push({ type: T.Figure, src });
                    }
                    const cap = node.querySelector('figcaption');
                    if (cap) tokens.push({ type: T.Text, content: [{ type: T.Italic, content: tokenizeInline(cap) }] });
                    break;
                }
                case 'ul': tokens.push({ type: T.UList, content: Array.from(node.querySelectorAll('li')).map(li => tokenizeInline(li)) }); break;
                case 'ol': tokens.push({ type: T.Olist, content: Array.from(node.querySelectorAll('li')).map(li => tokenizeInline(li)) }); break;
                case 'p':
                    if (!node.classList.contains('ztext-empty-paragraph') && node.textContent.length)
                        tokens.push({ type: T.Text, content: tokenizeInline(node) });
                    break;
                case 'hr': tokens.push({ type: T.HR }); break;
                case 'table': {
                    const rows = Array.from(node.rows).map(r => Array.from(r.cells).map(c => c.textContent.trim()));
                    tokens.push({ type: T.Table, content: rows });
                    break;
                }
            }
        }
        return tokens;
    }

    function renderRich(input, joint = '') {
        let res = '';
        for (const el of input) {
            switch (el.type) {
                case T.Bold: res += `**${renderRich(el.content)}** `; break;
                case T.Italic: res += `*${renderRich(el.content)}*`; break;
                case T.InlineLink: res += `[${el.text}](${el.href})`; break;
                case T.PlainText: res += el.text; break;
                case T.BR: res += '\n' + joint; break;
                case T.InlineCode: res += `\`${el.content}\``; break;
                case T.Math: res += el.display ? `\n\n$$\n${el.content}\n$$\n\n` : `$${el.content}$`; break;
            }
        }
        return joint + res;
    }

    function parser(input) {
        const out = [];
        for (const token of input) {
            switch (token.type) {
                case T.H2: out.push(`## ${token.text}`); break;
                case T.H3: out.push(`### ${token.text}`); break;
                case T.HR: out.push('\n---\n'); break;
                case T.Text: out.push(renderRich(token.content)); break;
                case T.Blockquote:
                    const ql = renderRich(token.content, '> ').replace(/\n/g, '\n> \n');
                    out.push(ql.startsWith('> ') ? ql : '> ' + ql);
                    break;
                case T.Figure: out.push(`![图片](${token.src})`); break;
                case T.UList: out.push(token.content.map(item => `- ${renderRich(item, '  ').trim()}`).join('\n')); break;
                case T.Olist: out.push(token.content.map((item, i) => `${i + 1}. ${renderRich(item, '   ').trim()}`).join('\n')); break;
                case T.Code: out.push(`\`\`\`${token.language || ''}\n${token.content}${token.content.endsWith('\n') ? '' : '\n'}\`\`\``); break;
                case T.Table: {
                    const rs = token.content, cols = rs[0].length;
                    const ws = Array(cols).fill(0);
                    rs.forEach(r => r.forEach((c, i) => { if (c.length > ws[i]) ws[i] = c.length; }));
                    const rr = r => '| ' + r.map((c, i) => c.padEnd(ws[i])).join(' | ') + ' |';
                    out.push(rr(rs[0]), '| ' + ws.map(w => '-'.repeat(w)).join(' | ') + ' |');
                    for (let i = 1; i < rs.length; i++) out.push(rr(rs[i]));
                    break;
                }
            }
        }
        return out;
    }

    function getPageTitle() {
        // 先尝试 document.title，去掉 - 知乎 后缀
        let title = document.title.replace(/ - 知乎$/, '').trim();
        // 去掉末尾的时间
        title = title.replace(/[\/\-\s|]+\d{4}[\/\-年]?\s*\d{1,2}[\/\-月]?\s*\d{1,2}日?\s*$/, '').trim();
        if (title && title !== '无标题') return title;

        // 回退：尝试从 meta 或 h1 获取
        const meta = document.querySelector('meta[itemprop="name"]')?.content;
        if (meta) return meta;

        const p = location.pathname;
        if (location.hostname === 'zhuanlan.zhihu.com') {
            return document.querySelector('h1.Post-Title')?.textContent || '无标题';
        }
        if (p.includes('/answer') || p.includes('/question')) {
            const qMeta = document.querySelector('.QuestionPage meta[itemprop="name"]')?.content
                || document.querySelector('.QuestionHeader-title')?.textContent;
            if (qMeta) return qMeta;
        }
        return title || '无标题';
    }

    function getZhihuTitle(dom) {
        const p = location.pathname;
        if (location.hostname === 'zhuanlan.zhihu.com') {
            return dom.closest('.Post-Main')?.querySelector('h1.Post-Title')?.textContent || '无标题';
        }
        if (p.includes('/answer')) {
            return dom.closest('.QuestionPage')?.querySelector('meta[itemprop=name]')?.content || '无标题';
        }
        const contentItem = dom.closest('.ContentItem');
        if (contentItem) {
            const titleEl = contentItem.querySelector('h2.ContentItem-title a');
            return titleEl?.textContent || '无标题';
        }
        return '无标题';
    }

    function getZhihuAuthor(dom) {
        const contentItem = dom.closest('.ContentItem') || dom.closest('.Post-Main');
        if (!contentItem) return '';
        const authorEl = contentItem.querySelector('.AuthorInfo-name .UserLink-link')
            || contentItem.querySelector('.UserLink-link')
            || contentItem.querySelector('.Post-Author .UserLink-link');
        return authorEl?.textContent || '';
    }

    function buildMarkdown(dom) {
        const title = getPageTitle();
        const author = getZhihuAuthor(dom);
        const tokens = lexer(dom.childNodes);
        const md = parser(tokens);

        let text = '';
        text += '---\n';
        if (title) text += '标题：' + title + '\n';
        if (author) text += '作者：' + author + '\n';
        text += '链接：' + location.href + '\n---\n\n\n';
        text += md.join('\n\n');
        return text;
    }

    function getFilename(dom) {
        const title = getPageTitle();
        const author = getZhihuAuthor(dom);
        const name = (title + '_' + author).replace(/[?\/\\<>"*\|\:]/g, '-');
        return name.slice(0, 128);
    }

    // ==================== 图片保存 ====================
    function extractImages(dom) {
        const imgs = dom.querySelectorAll('figure img');
        const urls = [];
        for (const img of imgs) {
            const src = img.getAttribute('data-actualsrc') || img.getAttribute('data-original') || img.src;
            if (src && !urls.includes(src)) urls.push(src);
        }
        return urls;
    }

    async function downloadImage(url) {
        try {
            const resp = await fetch(url);
            if (!resp.ok) return null;
            return await resp.blob();
        } catch (e) {
            return null;
        }
    }

    function triggerDownload(name, blob) {
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl; a.download = name; a.click();
        setTimeout(() => URL.revokeObjectURL(blobUrl), 40000);
    }

    async function saveImages(dom) {
        const urls = extractImages(dom);
        if (urls.length === 0) {
            showToast('ⓘ 未找到图片');
            return;
        }
        showToast(`正在下载 ${urls.length} 张图片...`);
        const results = [];
        for (let i = 0; i < urls.length; i++) {
            const blob = await downloadImage(urls[i]);
            if (blob) {
                const ext = urls[i].match(/\.(\w+)(?:\?|$)/)?.[1] || 'jpg';
                results.push({ name: `${i + 1}.${ext}`, blob });
            }
        }
        if (results.length === 0) {
            showToast('图片下载失败');
            return;
        }
        try {
            if (typeof JSZip === 'undefined') {
                showToast('JSZip 未加载，无法打包');
                return;
            }
            const zip = new JSZip();
            for (const r of results) {
                zip.file(r.name, r.blob);
            }
            const content = await zip.generateAsync({ type: 'blob', compression: 'STORE' });
            const filename = getFilename(dom).replace(/\.md$/, '') + '_images.zip';
            triggerDownload(filename, content);
        } catch (e) {
            console.error(e);
            showToast('打包图片失败');
        }
    }

    // ==================== 视频下载 ====================
    function isZvideoPage() {
        return /^https:\/\/www\.zhihu\.com\/zvideo\/\d+/.test(location.href);
    }

    function getVideoUrl() {
        // 优先从 video 标签获取
        const video = document.querySelector('video');
        if (video && video.src) return video.src;

        // 回退：从 __INITIAL_STATE__ 获取
        try {
            const state = window.__INITIAL_STATE__;
            if (state?.zvideo?.videoInfo) {
                const vd = state.zvideo.videoInfo;
                // 取最高清晰度
                const playlist = vd.playlist;
                if (playlist) {
                    const hd = playlist['HD'] || playlist['SD'] || playlist['LD'];
                    if (hd?.playUrl) return hd.playUrl;
                }
            }
        } catch (e) {}

        // 再回退：video source 标签
        const source = document.querySelector('video source');
        if (source && source.src) return source.src;

        return null;
    }

    async function downloadVideo() {
        const videoUrl = getVideoUrl();
        if (!videoUrl) {
            showToast('ⓘ 未找到视频');
            return;
        }
        showToast('正在下载视频...');
        try {
            const resp = await fetch(videoUrl);
            if (!resp.ok) {
                showToast('视频下载失败');
                return;
            }
            const blob = await resp.blob();
            const title = getPageTitle().replace(/[?\/\\<>"*\|\:]/g, '-').slice(0, 64) || 'video';
            triggerDownload(title + '.mp4', blob);
        } catch (e) {
            console.error(e);
            showToast('视频下载失败');
        }
    }

    function injectZvideoButton() {
        if (!isZvideoPage()) return;
        if (document.querySelector('.zh-video-btn')) return;

        const VideoSVG = '<svg width="14" height="14" viewBox="0 0 14 14"><path fill="currentColor" fill-rule="evenodd" d="M7 14A7 7 0 1 0 7 0a7 7 0 0 0 0 14m3.146-5.69l-2.793 2.793a.5.5 0 0 1-.707 0L3.854 8.31a.5.5 0 0 1 .353-.853H6V3.75a1 1 0 0 1 2 0v3.707h1.793a.5.5 0 0 1 .353.853" clip-rule="evenodd"/></svg>';

        const btn = document.createElement('button');
        btn.className = 'zh-icon-btn zh-video-btn';
        btn.title = '下载视频';
        btn.style.cssText = 'position:fixed;top:100px;left:20%;z-index:9999;width:32px;height:32px;';
        btn.innerHTML = VideoSVG;

        btn.addEventListener('click', throttle(async () => {
            try {
                await downloadVideo();
                btn.innerHTML = 'OK';
                setTimeout(() => { btn.innerHTML = VideoSVG; }, 1500);
            } catch (e) {
                btn.innerHTML = '!';
                setTimeout(() => { btn.innerHTML = VideoSVG; }, 1500);
            }
        }));

        document.body.appendChild(btn);
    }

    // ==================== 按钮注入 ====================
    function throttle(fn, delay = 2000) {
        let flag = true;
        return function(...args) {
            if (flag) {
                flag = false;
                setTimeout(() => { flag = true; }, delay);
                return fn.apply(this, args);
            }
        };
    }

    // ==================== 文章截图 ====================
    const PAGE = { FEED:'feed', QUESTION:'question', ARTICLE:'article' };
    const BTN_FOLLOW = 'button.Button.FollowButton, button.FollowButton';
    const ATTR_SHOT = 'zh-shot';

    const loadImg = url => new Promise((ok, no) => {
        const I = new Image(); I.onload = () => ok(I); I.onerror = no; I.src = url;
    });

    function trimEdge(I) {
        const W = I.width, H = I.height;
        const C = document.createElement('canvas');
        C.width = W; C.height = H;
        const G = C.getContext('2d');
        G.drawImage(I, 0, 0);
        const P = G.getImageData(0, 0, W, H).data;
        const blank = (x, y) => { const i = (y * W + x) << 2; return P[i + 3] < 8 || (P[i] > 245 && P[i + 1] > 245 && P[i + 2] > 245); };
        let T = 0, B = H - 1, L = 0, R = W - 1, ok = false;
        top: for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (!blank(x, y)) { T = y; ok = true; break top; }
        if (!ok) return { left:0, top:0, width:W, height:H };
        bot: for (let y = H - 1; y >= 0; y--) for (let x = 0; x < W; x++) if (!blank(x, y)) { B = y; break bot; }
        lef: for (let x = 0; x < W; x++) for (let y = T; y <= B; y++) if (!blank(x, y)) { L = x; break lef; }
        rig: for (let x = W - 1; x >= 0; x--) for (let y = T; y <= B; y++) if (!blank(x, y)) { R = x; break rig; }
        return { left:L, top:T, width: R - L + 1, height: B - T + 1 };
    }

    const getPage = () => {
        const H = location.hostname, P = location.pathname;
        if (H === 'zhuanlan.zhihu.com' && /^\/p\/\d+/.test(P)) return PAGE.ARTICLE;
        if (/^\/question\/\d+/.test(P)) return PAGE.QUESTION;
        return PAGE.FEED;
    };

    function findCard(rt) {
        return rt.closest('.ContentItem') || rt.closest('.List-item') || rt.closest('.Post-Main') || rt;
    }

    function findRemov(card) {
        const set = new Set(card.querySelectorAll(BTN_FOLLOW));
        const page = getPage();
        if (page === PAGE.FEED) card.querySelectorAll('.FeedSource-firstline').forEach(n => set.add(n));
        if (page === PAGE.ARTICLE) {
            for (const n of card.children) {
                if (n.tagName === 'DIV' && /\bcss-\S+/.test(n.className)) set.add(n);
            }
        }
        return [...set].filter(n => n.parentNode);
    }

    function hideNodes(nodes) {
        const undo = [];
        for (const n of nodes) {
            const m = document.createComment('zh-cap');
            n.replaceWith(m);
            undo.push(() => m.replaceWith(n));
        }
        return () => undo.forEach(fn => fn());
    }

    const dataUri = url => fetch(url, { mode:'cors' })
        .then(r => r.blob())
        .then(b => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(b); }));

    async function safeImgs(el) {
        const undo = [], jobs = [];
        for (const n of [el, ...el.querySelectorAll('*')]) {
            if (/^(IMG|SOURCE|VIDEO|image)$/i.test(n.tagName) && n.src && !n.src.startsWith('data:')) {
                const orig = n.src;
                undo.push(() => n.src = orig);
                jobs.push(dataUri(orig).then(u => n.src = u).catch(() => {}));
            }
            const bg = getComputedStyle(n).backgroundImage;
            if (bg && bg !== 'none') {
                const re = /url\(\s*["']?\s*(https?:\/\/[^"'\s)]+)\s*["']?\s*\)/gi;
                const urls = [...bg.matchAll(re)].map(m => m[1]);
                if (urls.length) {
                    const orig = n.style.backgroundImage;
                    undo.push(() => n.style.backgroundImage = orig);
                    jobs.push(
                        Promise.all(urls.map(u => dataUri(u).then(d => [u, d]).catch(() => [u, u])))
                            .then(pairs => { let v = bg; for (const [f, t] of pairs) v = v.replace(f, t); n.style.backgroundImage = v; })
                    );
                }
            }
        }
        await Promise.all(jobs);
        return () => undo.forEach(fn => fn());
    }

    // 截图前临时归一化定位，避免 sticky/fixed 元素在克隆渲染时吸附错位（如点赞栏）
    function neutralizeLayout(el) {
        const undo = [];
        for (const n of [el, ...el.querySelectorAll('*')]) {
            if (!(n instanceof HTMLElement)) continue;
            const pos = getComputedStyle(n).position;
            if (pos === 'sticky' || pos === 'fixed') {
                const inline = n.style.cssText;
                n.style.position = 'relative';
                if (pos === 'fixed') n.style.top = n.style.right = n.style.bottom = n.style.left = 'auto';
                undo.push(() => n.style.cssText = inline);
            }
        }
        return () => undo.forEach(fn => fn());
    }

    // 截图期间冻结动画/过渡，避免捕捉到中间帧导致元素错位
    function freezeAnimations(el) {
        const mark = 'zh-anim-freeze';
        el.classList.add(mark);
        const s = document.createElement('style');
        s.textContent = `.${mark},.${mark} *{animation:none!important;transition:none!important;}`;
        document.head.appendChild(s);
        return () => { s.remove(); el.classList.remove(mark); };
    }

    async function capture(el, shouldTrim) {
        const restoreImgs = await safeImgs(el);
        const restoreLayout = neutralizeLayout(el);
        const restoreAnim = freezeAnimations(el);
        try {
            const opts = {
                pixelRatio: 3, backgroundColor:'#ffffff', skipFonts:true,
                filter: node => {
                    if (!node) return true;
                    if (node.nodeType !== 1) return true;
                    if (node.hasAttribute?.(ATTR_SHOT)) return false;
                    if (node.closest?.(`[${ATTR_SHOT}]`)) return false;
                    return node.tagName?.toLowerCase() !== 'noscript';
                },
            };
            let uri;
            try { uri = await htmlToImage.toPng(el, opts); } catch (_) { uri = await htmlToImage.toSvg(el, opts); }
            const I = await loadImg(uri);
            let box = { left:0, top:0, width:I.width, height:I.height };
            if (shouldTrim !== false) {
                const T = document.createElement('canvas');
                T.width = I.width; T.height = I.height;
                T.getContext('2d').drawImage(I, 0, 0);
                try { T.getContext('2d').getImageData(0, 0, 1, 1); box = trimEdge(I); } catch (_) {}
            }
            const C = document.createElement('canvas');
            C.width = box.width; C.height = box.height;
            C.getContext('2d').drawImage(I, box.left, box.top, box.width, box.height, 0, 0, box.width, box.height);
            return { source:C, width:box.width, height:box.height };
        } finally { restoreAnim(); restoreLayout(); restoreImgs(); }
    }

    async function collect(card) {
        const assets = [];
        if (getPage() === PAGE.QUESTION) {
            const titleEl = document.querySelector('h1.QuestionHeader-title');
            if (titleEl) {
                const stub = document.createElement('div');
                stub.style.cssText = [
                    `width:${card.getBoundingClientRect().width}px`,
                    'padding:12px 0 8px 0;font-size:22px;font-weight:600;color:#121212;line-height:1.5',
                    'white-space:normal;word-wrap:break-word;background:#fff',
                    'font-family:-apple-system,BlinkMacSystemFont,Helvetica Neue,PingFang SC,Microsoft YaHei,Source Han Sans SC,Noto Sans CJK SC,WenQuanYi Micro Hei,sans-serif',
                ].join(';');
                stub.innerText = titleEl.innerText || titleEl.textContent;
                const wrap = document.createElement('div');
                wrap.style.cssText = 'position:fixed;left:-9999px;top:-9999px;z-index:-1';
                wrap.appendChild(stub);
                document.body.appendChild(wrap);
                try { assets.push(await capture(stub, false)); } finally { document.body.removeChild(wrap); }
            }
        }
        assets.push(await capture(card, true));
        return assets;
    }

    async function mergeImgs(assets) {
        const maxW = assets.reduce((m, a) => Math.max(m, a.width), 0);
        const GAP = 84, PAD = 48;
        const bodyH = assets.reduce((s, a, i) => s + a.height + (i ? GAP : 0), 0);
        const W = maxW + PAD * 2, H = PAD + bodyH + PAD;
        const C = document.createElement('canvas');
        C.width = W; C.height = H;
        const G = C.getContext('2d');
        G.fillStyle = '#ffffff';
        G.fillRect(0, 0, W, H);
        let y = PAD;
        for (const a of assets) { G.drawImage(a.source, PAD, y, a.width, a.height); y += a.height + GAP; }
        return C.toDataURL('image/png');
    }

    const toBlob = uri => fetch(uri).then(r => r.blob());

    function savePNG(uri) {
        const a = document.createElement('a');
        a.download = `${document.title || 'zhihu-snap'}-${Date.now()}.png`;
        a.href = uri; a.click();
    }

    function toClip(uri) {
        if (!navigator.clipboard || typeof ClipboardItem === 'undefined') return;
        return navigator.clipboard.write([new ClipboardItem({ 'image/png': toBlob(uri) })]);
    }

    async function screenshotCard(card) {
        let undo = () => {};
        try {
            undo = hideNodes(findRemov(card));
            const assets = await collect(card);
            undo(); undo = () => {};
            const uri = await mergeImgs(assets);
            savePNG(uri);
            toClip(uri)?.catch(e => console.warn('[截图] 剪贴板写入失败', e));
            return true;
        } catch (err) {
            console.error('[截图] 异常:', err);
            showToast(`截图失败: ${err?.message ?? err}`);
            return false;
        } finally { undo(); }
    }

    const ImageSVG = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M6.002 5.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/><path d="M2.002 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2h-12zm12 1a1 1 0 0 1 1 1v6.5l-3.777-1.947a.5.5 0 0 0-.577.093l-3.71 3.71-2.66-1.772a.5.5 0 0 0-.63.062L1.002 12V3a1 1 0 0 1 1-1h12z"/></svg>';
    const ShotSVG = '<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" fill="currentColor" viewBox="0 0 14 14"><path d="M0 0h14v14H0z" fill="none"/><path fill="currentColor" fill-rule="evenodd" d="M3.913.197a.75.75 0 1 1 .16 1.492q-.514.056-1.026.116l-.07.008a1.34 1.34 0 0 0-1.174 1.175q-.06.543-.118 1.088a.75.75 0 0 1-1.492-.154q.059-.558.12-1.102A2.84 2.84 0 0 1 2.805.323l.07-.008q.512-.06 1.038-.118M9.26.863a.75.75 0 0 1 .826-.666q.526.057 1.037.118l.071.008a2.84 2.84 0 0 1 2.492 2.497q.061.543.12 1.102a.75.75 0 1 1-1.492.154q-.057-.545-.118-1.088a1.34 1.34 0 0 0-1.174-1.175l-.07-.008q-.512-.061-1.026-.116A.75.75 0 0 1 9.26.863m0 12.275a.75.75 0 0 0 .826.665q.526-.058 1.037-.117l.071-.009a2.84 2.84 0 0 0 2.492-2.497q.061-.543.12-1.102a.75.75 0 1 0-1.492-.154q-.057.546-.118 1.088a1.34 1.34 0 0 1-1.174 1.175l-.07.008q-.512.061-1.026.116a.75.75 0 0 0-.666.827m-4.522 0a.75.75 0 0 1-.826.665q-.526-.058-1.037-.117l-.071-.009A2.84 2.84 0 0 1 .313 11.18q-.061-.543-.12-1.102a.75.75 0 0 1 1.492-.154q.057.546.118 1.088c.069.612.56 1.104 1.174 1.175l.07.008q.512.061 1.027.116a.75.75 0 0 1 .665.827m.913-9.916a.5.5 0 0 0-.438.259l-.54.978l-.083.007l-.046.004A1.724 1.724 0 0 0 2.99 5.93c-.074.507-.146 1.056-.146 1.624s.072 1.118.146 1.624a1.724 1.724 0 0 0 1.554 1.46l.046.004h.01c.758.066 1.567.136 2.4.136c.831 0 1.64-.07 2.399-.135l.056-.005a1.724 1.724 0 0 0 1.553-1.46c.075-.506.147-1.056.147-1.624s-.072-1.117-.147-1.624a1.724 1.724 0 0 0-1.553-1.46l-.047-.004l-.082-.007l-.54-.978a.5.5 0 0 0-.438-.259zM7 8.94c.96 0 1.5-.54 1.5-1.5s-.54-1.5-1.5-1.5s-1.5.54-1.5 1.5s.54 1.5 1.5 1.5" clip-rule="evenodd"/></svg>';
    const SaveSVG = '<svg width="15" height="15" viewBox="0 0 14 14"><path fill="currentColor" fill-rule="evenodd" d="M7 14A7 7 0 1 0 7 0a7 7 0 0 0 0 14m3.146-5.69l-2.793 2.793a.5.5 0 0 1-.707 0L3.854 8.31a.5.5 0 0 1 .353-.853H6V3.75a1 1 0 0 1 2 0v3.707h1.793a.5.5 0 0 1 .353.853" clip-rule="evenodd"/></svg>';
    const BtnHTML = `<button class="zh-img-btn zh-icon-btn" title="保存图片">${ImageSVG}</button><button class="zh-shot-btn zh-icon-btn" title="文章截图">${ShotSVG}</button><button class="zh-save-btn zh-icon-btn" title="保存为Markdown">${SaveSVG}</button>`;

    function injectButtons() {
        for (const rt of document.querySelectorAll('.RichText')) {
            try {
                // 跳过编辑器中的 RichText
                if (rt.parentElement.classList.contains('Editable')) continue;

                // 专栏文章页只注入一次
                if (location.hostname.includes('zhuanlan')) {
                    if (rt.closest('.Post-Main')?.querySelector('.zh-wrap')) continue;
                } else {
                    // 跳过转发的想法
                    if (rt.closest('.PinItem')) {
                        if (!rt.closest('.RichContent-inner')) continue;
                        if (rt.closest('.PinItem-content-originpin')) continue;
                    }
                    // 已注入过
                    if (rt.closest('.RichContent')?.querySelector('.zh-wrap')) continue;
                    // 有展开更多的内容
                    const ri = rt.closest('.RichContent-inner');
                    if (ri && ri.querySelector('.ContentItem-more')) continue;
                    if (rt.closest('.RichContent')?.querySelector('.ContentItem-expandButton')) continue;
                }

                const wrap = document.createElement('div');
                wrap.className = 'zh-wrap';
                wrap.setAttribute(ATTR_SHOT, ''); // 截图时排除悬浮按钮
                wrap.innerHTML = `<div class="zh-container">${BtnHTML}</div>`;

                let parent = rt.closest('.List-item') || rt.closest('.Post-content') || rt.closest('.PinItem') || rt.closest('.CollectionDetailPageItem') || rt.closest('.Card');
                if (parent?.querySelector('.Catalog')) {
                    wrap.firstElementChild.style.cssText = 'position:fixed;top:unset;bottom:60px;';
                }

                const container = rt.closest('.RichContent') || rt.closest('.Post-RichTextContainer');
                if (!container) continue;
                container.prepend(wrap);

                // 保存图片按钮
                const btnImg = wrap.querySelector('.zh-img-btn');
                btnImg.addEventListener('click', throttle(async (e) => {
                    try {
                        await saveImages(rt);
                        btnImg.innerHTML = 'OK';
                        setTimeout(() => { btnImg.innerHTML = ImageSVG; }, 1500);
                    } catch (err) {
                        console.log(err);
                        btnImg.innerHTML = '!';
                        setTimeout(() => { btnImg.innerHTML = ImageSVG; }, 1500);
                    }
                }));

                // 文章截图按钮
                const btnShot = wrap.querySelector('.zh-shot-btn');
                btnShot.addEventListener('click', throttle(async (e) => {
                    try {
                        const card = findCard(rt);
                        const ok = await screenshotCard(card);
                        btnShot.innerHTML = ok ? 'OK' : '!';
                        setTimeout(() => { btnShot.innerHTML = ShotSVG; }, 1500);
                    } catch (err) {
                        console.log(err);
                        btnShot.innerHTML = '!';
                        setTimeout(() => { btnShot.innerHTML = ShotSVG; }, 1500);
                    }
                }));

                // 保存为Markdown按钮 (右键复制)
                const btnSave = wrap.querySelector('.zh-save-btn');
                btnSave.addEventListener('click', throttle(async (e) => {
                    try {
                        const md = buildMarkdown(rt);
                        if (!md) {
                            showToast('ⓘ 未找到内容');
                            return;
                        }
                        const blob = new Blob([md], { type: 'text/plain' });
                        saveAs(blob, getFilename(rt) + '.md');
                        btnSave.innerHTML = 'OK';
                        setTimeout(() => { btnSave.innerHTML = SaveSVG; }, 1500);
                    } catch (err) {
                        console.log(err);
                        btnSave.innerHTML = '!';
                        setTimeout(() => { btnSave.innerHTML = SaveSVG; }, 1500);
                    }
                }));

                // 保存为Markdown按钮 右键 → 复制
                btnSave.addEventListener('contextmenu', async (e) => {
                    e.preventDefault();
                    try {
                        const md = buildMarkdown(rt);
                        if (!md) { showToast('ⓘ 未找到内容'); return; }
                        await navigator.clipboard.writeText(md);
                        btnSave.innerHTML = 'OK';
                        setTimeout(() => { btnSave.innerHTML = SaveSVG; }, 1500);
                    } catch (err) {
                        console.log(err);
                        btnSave.innerHTML = '!';
                        setTimeout(() => { btnSave.innerHTML = SaveSVG; }, 1500);
                    }
                });
            } catch (e) { /* skip broken content */ }
        }
    }

    // ==================== 页面初始化 ====================
    setTimeout(() => {
        const style = document.createElement('style');
        style.textContent = `
            .RichContent{position:relative;}
            .zh-wrap{position:absolute;left:-4.5em;top:0;user-select:none;z-index:2;}
            .zh-container{position:sticky;top:120px;display:flex;flex-direction:column;gap:8px;}
            .zh-icon-btn{display:flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:50%;border:none;cursor:pointer;background:#1772F6;color:#fff;padding:0;font-size:12px;line-height:1;transition:background .2s,transform .2s;}
            .zh-icon-btn:hover{background:#1565d0;transform:scale(1.1);}
            .RichContent:has(.ContentItem-more) .zh-wrap,.Post-RichTextContainer:has(.ContentItem-more) .zh-wrap{display:none;}
            .Card:has(.zh-wrap){overflow:visible!important;}
        `;
        document.head.appendChild(style);

        if (window.innerWidth < 1275) {
            const s2 = document.createElement('style');
            s2.textContent = `.zh-wrap{left:unset;right:0;}.zh-container{float:right;}.RichContent{z-index:2;}`;
            document.head.appendChild(s2);
        }
    }, 30);

    setTimeout(injectButtons, 300);
    setTimeout(injectZvideoButton, 500);

    let scrollTimer = null;
    window.addEventListener('scroll', () => {
        if (scrollTimer) clearTimeout(scrollTimer);
        scrollTimer = setTimeout(() => {
            injectButtons();
            injectZvideoButton();
        }, 1000);
    });

    console.log('知乎阅读助手初始化成功');
})();