// ==UserScript==
// @name               WeChat 公众号阅读助手
// @name:zh-CN         WeChat 公众号阅读助手
// @name:en            Wechat Enhancer Tools
// @description        增强功能：下载图片、下载博文、阅读助手（包括：查看封面、查看摘要、AI 总结全文，查看文章原始链接，查看历史消息链接），还有去除图片延迟加载，文本链接转超链接等功能。
// @description:zh-CN  增强功能：下载图片、下载博文、阅读助手（包括：查看封面、查看摘要、AI 总结全文，查看文章原始链接，查看历史消息链接），还有去除图片延迟加载，文本链接转超链接等功能。
// @description:en     Enhanced Features: Image Download, Article Download, Reading Assistant (including: view cover, view abstract, AI full-text summary, view original article link, view historical message links), and Remove lazy loading of images, convert text links to hyperlinks.
// @namespace          https://www.runningcheese.com
// @version            2.0
// @author             RunningCheese
// @match              https://mp.weixin.qq.com/s/*
// @match              https://mp.weixin.qq.com/s?*
// @run-at             document-start
// @icon               https://t1.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://mp.weixin.qq.com
// @require            https://cdnjs.cloudflare.com/ajax/libs/jszip/3.9.1/jszip.min.js
// @license            MIT
// @downloadURL https://update.greasyfork.org/scripts/461342/WeChat%20%E5%85%AC%E4%BC%97%E5%8F%B7%E9%98%85%E8%AF%BB%E5%8A%A9%E6%89%8B.user.js
// @updateURL https://update.greasyfork.org/scripts/461342/WeChat%20%E5%85%AC%E4%BC%97%E5%8F%B7%E9%98%85%E8%AF%BB%E5%8A%A9%E6%89%8B.meta.js
// ==/UserScript==


(function() {
    'use strict';

    // 创建浮动窗口
    const panel = document.createElement('div');
    panel.id = 'wx-reader-panel';
    panel.style.cssText = 'position:fixed;top:12%;left:20%;background:#fff;border:none;border-radius:8px;padding:4px;width:200px;box-shadow:0 4px 12px rgba(0,0,0,0.25);z-index:999999;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;display:none;';

    // 增强样式隔离性
    const styleElement = document.createElement('style');
    styleElement.textContent = `
        .wx-reader-icon {
            cursor: pointer;
            margin-left: 5px;
            vertical-align: middle;
            display: inline-flex;
            align-items: center;
            transition: opacity 0.2s;
        }
        .wx-reader-icon:hover {
            transform: scale(1.1);
        }
        .wx-reader-icon svg rect {
            fill: #1979E7;
        }
    `;
    document.head.appendChild(styleElement);

    // ==================== 图片延迟加载去除 ====================
    function isExcluded(url) {
        const excludedKeywords = [
            'avatar', 'icon', 'emoji', 'logo', 'qr', 'qrcode',
            'wx_fmt=svg', 'icon_', 'loading'
        ];
        return excludedKeywords.some(keyword => url.includes(keyword));
    }

    function updateImageSource(imgElement) {
        const srcAttr = imgElement.getAttribute('data-src') || imgElement.getAttribute('data-original');
        if (srcAttr && !isExcluded(srcAttr)) {
            imgElement.src = new URL(srcAttr, window.location.href).href;
        }

        const srcsetAttr = imgElement.getAttribute('data-srcset');
        if (srcsetAttr) {
            imgElement.srcset = srcsetAttr;
            imgElement.removeAttribute('data-srcset');
        }

        imgElement.removeAttribute('data-src');
        imgElement.removeAttribute('data-original');
        imgElement.removeAttribute('loading');
        imgElement.classList.remove('lazyload', 'lazy', 'lazyloading');
    }

    function processAddedNodes(addedNodes) {
        addedNodes.forEach(node => {
            if (node.tagName === 'IMG') {
                updateImageSource(node);
            } else if (node.querySelectorAll) {
                node.querySelectorAll('img').forEach(updateImageSource);
            }
        });
    }

    function removeLazyLoading() {
        document.querySelectorAll('img').forEach(updateImageSource);
    }

    // 监听动态添加的图片
    const lazyObserver = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            if (mutation.type === 'childList' && mutation.addedNodes.length) {
                processAddedNodes(mutation.addedNodes);
            } else if (mutation.type === 'attributes' &&
                (mutation.attributeName === 'data-src' || mutation.attributeName === 'data-original')) {
                updateImageSource(mutation.target);
            }
        });
    });

    lazyObserver.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['data-src', 'data-original']
    });

    // DOM 就绪后自动处理已有图片
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', removeLazyLoading);
    } else {
        removeLazyLoading();
    }

    // ==================== 图片选择与批量下载 ====================
    function showImagePicker() {
        // 收集所有有效图片，优先使用 data-src/data-original
        const imgSources = [];
        const seen = new Set();
        document.querySelectorAll('img').forEach(img => {
            let src = img.getAttribute('data-src') || img.getAttribute('data-original') || img.src;
            if (!src || src.startsWith('data:image/svg') || seen.has(src)) return;
            // 替换为高清原图
            src = src.replace('640?', '0?');
            if (seen.has(src)) return;
            seen.add(src);
            imgSources.push({ src, el: img });
        });

        if (imgSources.length === 0) {
            alert('未找到图片');
            return;
        }

        // 避免重复创建
        const existing = document.getElementById('wx-img-picker-overlay');
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.id = 'wx-img-picker-overlay';
        overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);z-index:9999999;display:flex;align-items:center;justify-content:center;';

        // 内层对话框
        const dialog = document.createElement('div');
        dialog.style.cssText = 'display:flex;flex-direction:column;width:92vw;max-width:1200px;height:90vh;background:#1a1a1a;border-radius:12px;overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,0.6);';
        overlay.appendChild(dialog);

        // 顶部工具栏
        const toolbar = document.createElement('div');
        toolbar.style.cssText = 'display:flex;align-items:center;padding:12px 16px;background:#222;color:#fff;gap:12px;flex-shrink:0;';
        toolbar.innerHTML = `
            <span style="font-size:15px;font-weight:bold;">图片选择器 (${imgSources.length}张)</span>
            <button id="wx-img-select-all" style="padding:6px 14px;border:1px solid #555;border-radius:4px;background:#333;color:#fff;cursor:pointer;font-size:13px;">全选</button>
            <button id="wx-img-deselect-all" style="padding:6px 14px;border:1px solid #555;border-radius:4px;background:#333;color:#fff;cursor:pointer;font-size:13px;">反选</button>
            <button id="wx-img-cancel-all" style="padding:6px 14px;border:1px solid #555;border-radius:4px;background:#333;color:#fff;cursor:pointer;font-size:13px;">取消</button>
            <span id="wx-img-count" style="margin-left:auto;font-size:13px;color:#aaa;">已选 0 张</span>
            <button id="wx-img-download" style="padding:6px 14px;border:none;border-radius:4px;background:#1E88E5;color:#fff;cursor:pointer;font-size:13px;font-weight:bold;">下载选中</button>
            <button id="wx-img-close" style="padding:6px 14px;border:1px solid #555;border-radius:4px;background:#333;color:#fff;cursor:pointer;font-size:13px;">关闭</button>
        `;
        dialog.appendChild(toolbar);

        // 图片网格
        const grid = document.createElement('div');
        grid.style.cssText = 'flex:1 1 0;min-height:0;overflow-y:scroll;display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));grid-auto-rows:max-content;gap:10px;padding:16px;align-content:start;';
        dialog.appendChild(grid);

        const checkboxes = [];

        imgSources.forEach((item, i) => {
            const card = document.createElement('div');
            card.style.cssText = 'position:relative;background:#1a1a1a;border-radius:6px;overflow:hidden;cursor:pointer;border:3px solid transparent;transition:border-color 0.15s;';

            const img = document.createElement('img');
            img.src = item.src;
            img.style.cssText = 'width:100%;height:180px;object-fit:contain;display:block;background:#000;';
            img.loading = 'lazy';

            const cb = document.createElement('input');
            cb.type = 'checkbox';
            cb.checked = true;
            cb.style.cssText = 'position:absolute;top:6px;left:6px;width:18px;height:18px;cursor:pointer;accent-color:#1E88E5;z-index:2;';

            const label = document.createElement('div');
            label.style.cssText = 'padding:6px 8px;font-size:11px;color:#aaa;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
            label.textContent = (i + 1) + '. ' + decodeURIComponent(item.src.split('/').pop().split('?')[0] || item.src);

            card.appendChild(img);
            card.appendChild(cb);
            card.appendChild(label);
            grid.appendChild(card);
            checkboxes.push(cb);

            const updateBorder = () => {
                card.style.borderColor = cb.checked ? '#1E88E5' : 'transparent';
            };
            updateBorder();

            cb.addEventListener('change', () => {
                updateBorder();
                const count = checkboxes.filter(c => c.checked).length;
                document.getElementById('wx-img-count').textContent = '已选 ' + count + ' 张';
            });

            card.addEventListener('click', e => {
                if (e.target !== cb) {
                    cb.checked = !cb.checked;
                    cb.dispatchEvent(new Event('change'));
                }
            });
        });

        document.body.appendChild(overlay);

        // 工具栏事件
        document.getElementById('wx-img-select-all').onclick = () => {
            checkboxes.forEach(cb => { cb.checked = true; cb.dispatchEvent(new Event('change')); });
        };
        document.getElementById('wx-img-deselect-all').onclick = () => {
            checkboxes.forEach(cb => { cb.checked = !cb.checked; cb.dispatchEvent(new Event('change')); });
        };
        document.getElementById('wx-img-cancel-all').onclick = () => {
            checkboxes.forEach(cb => { cb.checked = false; cb.dispatchEvent(new Event('change')); });
        };
        document.getElementById('wx-img-close').onclick = () => overlay.remove();

        // ESC 关闭
        const escHandler = e => { if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', escHandler); } };
        document.addEventListener('keydown', escHandler);

        // 批量下载为压缩包
        document.getElementById('wx-img-download').onclick = async () => {
            const selected = checkboxes
                .map((cb, i) => cb.checked ? imgSources[i] : null)
                .filter(Boolean);

            if (selected.length === 0) {
                alert('请至少选择一张图片');
                return;
            }

            const btn = document.getElementById('wx-img-download');
            btn.disabled = true;
            btn.textContent = '下载中...';

            try {
                const folderName = (document.title || 'images').replace(/[\\/:*?"<>|]/g, '_');
                const zip = new JSZip();
                const folder = zip.folder(folderName);
                const promises = selected.map((item, i) => {
                    return fetch(item.src)
                        .then(res => res.blob())
                        .then(blob => {
                            const name = (i + 1) + '_' + (item.src.split('/').pop().split('?')[0] || 'image');
                            folder.file(name + '.jpg', blob);
                        });
                });
                await Promise.all(promises);

                const content = await zip.generateAsync({ type: 'blob' });
                const url = URL.createObjectURL(content);
                const a = document.createElement('a');
                a.href = url;
                a.download = folderName + '.zip';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            } catch (err) {
                alert('下载失败，请重试');
                console.error(err);
            }

            btn.disabled = false;
            btn.textContent = '下载选中';
        };
    }

    // ==================== 创建工具图标 ====================
    const WX_ICONS = '#5095E6';

    function buildSvg(pathD, size, viewBox) {
        const w = size || 20;
        const h = size || 20;
        const vb = viewBox || '0 0 24 24';
        return `<svg width="${w}" height="${h}" viewBox="${vb}" xmlns="http://www.w3.org/2000/svg">
            <rect x="2" y="2" width="20" height="20" rx="4" ry="4" fill="${WX_ICONS}"/>
            ${pathD}
        </svg>`;
    }

    function createIcon(title, svgHtml, onClick) {
        const icon = document.createElement('span');
        icon.className = 'wx-reader-icon';
        icon.innerHTML = svgHtml;
        icon.title = title;
        icon.addEventListener('click', function(e) {
            e.stopPropagation();
            onClick(icon);
        });
        return icon;
    }

    const icons = [
        {
            title: '微信阅读助手',
            svg: buildSvg('<path d="M6 7.45h12v1.5H6zM6 11.25h12v1.5H6zM6 15.05h12v1.5H6z" fill="white"/>', 20),
            onClick: function(icon) {
                panel.style.display = 'block';
                const rect = icon.getBoundingClientRect();
                panel.style.top = (rect.bottom + window.scrollY + 10) + 'px';
                panel.style.left = (rect.left + window.scrollX - 100) + 'px';
            }
        },
        {
            title: '查看所有图片',
            svg: buildSvg('<g transform="translate(4,4)"><path d="M6.002 5.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" fill="white"/><path d="M2.002 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2h-12zm12 1a1 1 0 0 1 1 1v6.5l-3.777-1.947a.5.5 0 0 0-.577.093l-3.71 3.71-2.66-1.772a.5.5 0 0 0-.63.062L1.002 12V3a1 1 0 0 1 1-1h12z" fill="white"/></g>', 20),
            onClick: function() { showImagePicker(); }
        },
        {
            title: '保存当前文章',
            svg: buildSvg('<g transform="translate(5,5)"><path fill-rule="evenodd" d="M7 14A7 7 0 1 0 7 0a7 7 0 0 0 0 14m3.146-5.69l-2.793 2.793a.5.5 0 0 1-.707 0L3.854 8.31a.5.5 0 0 1 .353-.853H6V3.75a1 1 0 0 1 2 0v3.707h1.793a.5.5 0 0 1 .353.853" clip-rule="evenodd" fill="white"/></g>', 20),
            onClick: function() { saveArticleAsMarkdown(); }
        }
    ];

    // 添加图标到页面
    function addToolIcon() {
        const selectors = ['#js_ip_wording', '#publish_time', '#js_author_name', '.rich_media_meta_list'];
        let targetElement = null;

        for (const selector of selectors) {
            const element = document.querySelector(selector);
            if (element) {
                targetElement = element;
                break;
            }
        }

        if (targetElement && !targetElement.querySelector('.wx-reader-icon')) {
            icons.forEach(item => {
                targetElement.appendChild(createIcon(item.title, item.svg, item.onClick));
            });
        }
    }

    // 创建标题栏
    const titleBar = document.createElement('div');
    titleBar.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:4px 10px;font-size:14px;color:#333;border-bottom:1px solid #eee;margin-bottom:4px;cursor:move;border-radius:8px 8px 0 0;';

    // 创建标题文本
    const titleText = document.createElement('span');
    titleText.textContent = '▼ 微信阅读助手';
    titleText.style.cssText = 'flex:1;';
    titleBar.appendChild(titleText);

    // 创建关闭按钮
    const closeBtn = document.createElement('span');
    closeBtn.textContent = '✕';
    closeBtn.style.cssText = 'cursor:pointer;color:#999;width:20px;height:20px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:all 0.2s ease;margin-left:10px;';

    closeBtn.addEventListener('mouseover', () => closeBtn.style.backgroundColor = '#dadada');
    closeBtn.addEventListener('mouseout', () => closeBtn.style.backgroundColor = '');
    closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        panel.style.display = 'none';
    });

    titleBar.appendChild(closeBtn);

    // 拖动相关变量和事件
    let startX = 0, startY = 0, startLeft = 0, startTop = 0, isDragging = false;

    titleBar.addEventListener('mousedown', function(e) {
        if (e.target === closeBtn) return;
        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;
        startLeft = parseInt(window.getComputedStyle(panel).left);
        startTop = parseInt(window.getComputedStyle(panel).top);
        e.preventDefault();
    });

    function mouseMoveHandler(e) {
        if (!isDragging) return;
        const deltaX = e.clientX - startX;
        const deltaY = e.clientY - startY;
        panel.style.left = (startLeft + deltaX) + 'px';
        panel.style.top = (startTop + deltaY) + 'px';
    }

    function mouseUpHandler() {
        isDragging = false;
    }

    document.addEventListener('mousemove', mouseMoveHandler);
    document.addEventListener('mouseup', mouseUpHandler);

    // 双击Esc关闭窗口
    let lastEscTime = 0;
    document.addEventListener('keydown', function(evt) {
        if (evt.key === 'Escape') {
            const now = Date.now();
            if (now - lastEscTime <= 300) {
                panel.style.display = 'none';
            }
            lastEscTime = now;
        }
    });

    // ==================== 保存文章为 Markdown ====================
    function htmlToMarkdown(element) {
        function processNode(node) {
            if (node.nodeType === 3) {
                return node.textContent.replace(/[^\S\n]+/g, ' ');
            }
            if (node.nodeType !== 1) return '';

            const tag = node.nodeName.toLowerCase();

            if (/^h[1-6]$/.test(tag)) {
                const level = parseInt(tag.charAt(1));
                return '#'.repeat(level) + ' ' + getTextContent(node) + '\n\n';
            }
            if (tag === 'p') return processChildren(node) + '\n\n';
            if (tag === 'br') return '\n';
            if (tag === 'hr') return '---\n\n';
            if (tag === 'ul') {
                let md = '';
                Array.from(node.children).forEach(li => {
                    if (li.nodeName.toLowerCase() === 'li') md += '- ' + processChildren(li) + '\n';
                });
                return md + '\n';
            }
            if (tag === 'ol') {
                let md = '';
                Array.from(node.children).forEach((li, idx) => {
                    if (li.nodeName.toLowerCase() === 'li') md += (idx + 1) + '. ' + processChildren(li) + '\n';
                });
                return md + '\n';
            }
            if (tag === 'blockquote') {
                const text = processChildren(node);
                return '> ' + text.replace(/\n/g, '\n> ') + '\n\n';
            }
            if (tag === 'pre') return '```\n' + node.textContent + '\n```\n\n';
            if (tag === 'code') {
                if (node.parentNode && node.parentNode.nodeName.toLowerCase() === 'pre') return node.textContent;
                return '`' + node.textContent + '`';
            }
            if (tag === 'strong' || tag === 'b') return '**' + processChildren(node) + '**';
            if (tag === 'em' || tag === 'i') return '*' + processChildren(node) + '*';
            if (tag === 'a') {
                const href = node.getAttribute('href') || '';
                return '[' + processChildren(node) + '](' + href + ')';
            }
            if (tag === 'img') {
                const src = node.getAttribute('data-src') || node.getAttribute('data-original') || node.getAttribute('src') || '';
                const alt = node.getAttribute('alt') || '';
                return '![' + alt + '](' + src + ')\n\n';
            }
            if (tag === 'table') {
                const rows = node.querySelectorAll('tr');
                if (rows.length === 0) return '';
                let md = '';
                const hCells = rows[0].querySelectorAll('th, td');
                md += '| ' + Array.from(hCells).map(c => getTextContent(c)).join(' | ') + ' |\n';
                md += '| ' + Array.from(hCells).map(() => '---').join(' | ') + ' |\n';
                for (let i = 1; i < rows.length; i++) {
                    const cells = rows[i].querySelectorAll('td');
                    md += '| ' + Array.from(cells).map(c => getTextContent(c)).join(' | ') + ' |\n';
                }
                return md + '\n';
            }
            return processChildren(node);
        }

        function processChildren(node) {
            let text = '';
            Array.from(node.childNodes).forEach(child => { text += processNode(child); });
            return text;
        }

        function getTextContent(node) {
            let text = '';
            Array.from(node.childNodes).forEach(child => {
                if (child.nodeType === 3) {
                    text += child.textContent.replace(/[^\S\n]+/g, ' ');
                } else if (child.nodeType === 1) {
                    const cTag = child.nodeName.toLowerCase();
                    if (cTag !== 'script' && cTag !== 'style') text += getTextContent(child);
                }
            });
            return text.trim();
        }

        return processNode(element);
    }

    function downloadMarkdown(markdown) {
        const now = new Date();
        const pad = n => String(n).padStart(2, '0');
        const dateStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}`;
        const metadata = '```\n' + document.title + '\n' + window.location.href + '\n' + dateStr + '\n```\n\n&nbsp;\n\n';
        const blob = new Blob([metadata + markdown], { type: 'text/markdown' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = (document.title.replace(/[\\/:*?"<>|]/g, '_') || 'article') + '.md';
        a.click();
        URL.revokeObjectURL(url);
    }

    function saveArticleAsMarkdown() {
        const contentEl = document.querySelector('#js_content') || document.querySelector('.rich_media_content') || document.body;
        if (!contentEl) {
            alert('未找到文章正文');
            return;
        }
        const markdown = htmlToMarkdown(contentEl);
        downloadMarkdown(markdown);
    }

    // Toast 提示
    function showToast(msg) {
        let el = document.getElementById('wx-toast');
        if (!el) {
            el = document.createElement('div');
            el.id = 'wx-toast';
            el.style.cssText = 'position:fixed;top:5%;left:50%;transform:translateX(-50%);background:#3F7FEA;color:#fff;padding:16px 18px;min-height:20px;min-width:180px;line-height:1.2;border-radius:13px;font-size:14px;font-family:sans-serif;z-index:2147483647;pointer-events:none;opacity:0;transition:opacity 0.25s ease;box-shadow:0 2px 8px rgba(0,122,255,0.25),0 0 0 0.5px rgba(0,122,255,0.1);box-sizing:border-box;display:flex;align-items:center;justify-content:center;';
            document.body.appendChild(el);
        }
        el.textContent = msg;
        el.style.opacity = '1';
        setTimeout(function() { el.style.opacity = '0'; }, 1500);
    }

    // 复制纯文本并跳转豆包
    function copyTextAndOpenDoubao() {
        const promptText = '请根据以下微信公众号文章内容，提取出核心观点，并用结构化的 Markdown 格式（如标题、列表、加粗重点，必要时可以使用表格）进行详细总结：';
        const contentEl = document.querySelector('#js_content') || document.querySelector('.rich_media_content') || document.body;
        const plainText = contentEl ? contentEl.innerText.trim().replace(/\n{3,}/g, '\n\n') : '';
        const fullText = promptText + '\n\n' + plainText;

        navigator.clipboard.writeText(fullText).then(function() {
            showToast('ⓘ 已复制全文到剪贴板，即将跳转豆包');
            setTimeout(function() {
                window.open('https://www.doubao.com/chat', '_blank');
            }, 800);
        }).catch(function() {
            showToast('复制失败');
        });
    }

    // 功能菜单项
    const menuItems = [


        {title: '1、文章封面', code: 'const cover = document.querySelector(\'meta[property="twitter:image"]\').content; window.open(cover, "_blank");'},
        {title: '2、文章摘要', code: 'summary = document.querySelector(\'meta[name="description"]\').content; prompt(\'文章摘要：\',summary)'},
        {title: '3、AI 总结全文', fn: copyTextAndOpenDoubao},
        {title: '4、文章原始链接', code: 'prompt(\'原始链接：\', \'https://mp.weixin.qq.com/s?__biz=\'+biz+\'&idx=1&mid=\'+mid+\'&sn=\'+sn)'},
        {title: '5、历史消息链接', code: 'prompt(\'历史消息链接：\',\'https://mp.weixin.qq.com/mp/profile_ext?action=home&__biz=\'+biz+\'#wechat_redirect\')'}

    ];

    // 创建菜单项
    menuItems.forEach((item) => {
        const menuItem = document.createElement('div');
        menuItem.style.cssText = 'cursor: pointer; padding: 0px 10px; height: 32px; transition: 0.2s; border-radius: 6px; font-size: 14px; color: rgb(51, 51, 51); display: flex; align-items: center;';
        menuItem.textContent = item.title;

        menuItem.onmouseover = () => menuItem.style.backgroundColor = '#dadada';
        menuItem.onmouseout = () => menuItem.style.backgroundColor = '';

        if (item.code || item.fn) {
            menuItem.onclick = (e) => {
                e.preventDefault();
                try {
                    if (item.fn) {
                        item.fn();
                    } else {
                        const func = new Function(`return (function(){${item.code}})();`);
                        func();
                    }
                } catch (err) {
                    console.error('执行代码时出错:', err);
                }
            };
        }

        panel.appendChild(menuItem);
    });

    // 添加到页面 - 将标题栏放在最上面
    panel.insertBefore(titleBar, panel.firstChild);
    document.body.appendChild(panel);

    // 添加点击页面其他区域关闭面板
    document.addEventListener('click', function(e) {
        if (!panel.contains(e.target) && !e.target.classList.contains('wx-reader-icon')) {
            panel.style.display = 'none';
        }
    });

    // 添加工具图标 - DOM 就绪后立即执行
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', addToolIcon);
    } else {
        addToolIcon();
    }

    // 监听DOM变化，确保在动态加载的页面上也能添加图标
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length > 0) {
                setTimeout(addToolIcon, 500);
            }
        });
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // 文本链接转超链接 - 默认自动运行
    const formatLimit = 5;
    const formatList = new WeakMap();
    const hrefReg = /\b((?:https?:\/\/)?(?![\d-]+\.[\d-]+)([\w-]+(\.[\w-]+)+[\S^\"\'\[\]\{\}\>\<]*))/gi;
    const ignoreTags = ['SCRIPT', 'STYLE', 'A', 'TEXTAREA', 'NOSCRIPT', 'CODE', 'TITLE'];

    function queryElement(element) {
        [...(element.querySelectorAll?.('*') ?? [])].forEach(i => formatHref(i, i.childNodes));
    }

    function formatHref(target, childNodes) {
        if (ignoreTags.includes(target.nodeName) || target.translate === false) return;
        let formatTimes = formatList.get(target) || 0;
        if (formatTimes > formatLimit) return;
        let changed = false;
        [...childNodes].forEach(c => {
            if (c.nodeType === Node.TEXT_NODE && hrefReg.test(c.textContent)) {
                const frag = document.createDocumentFragment();
                let lastIdx = 0;
                const text = c.textContent;
                hrefReg.lastIndex = 0;
                let match;
                while ((match = hrefReg.exec(text)) !== null) {
                    const before = text.slice(lastIdx, match.index);
                    if (before) frag.appendChild(document.createTextNode(before));
                    const url = match[0];
                    const a = document.createElement('a');
                    a.href = /^https?:\/\//i.test(url) ? url : 'https://' + url;
                    a.target = '_blank';
                    a.textContent = url;
                    frag.appendChild(a);
                    lastIdx = hrefReg.lastIndex;
                }
                if (lastIdx < text.length) {
                    frag.appendChild(document.createTextNode(text.slice(lastIdx)));
                }
                c.replaceWith(frag);
                changed = true;
            }
        });
        if (changed) {
            formatList.set(target, formatTimes + 1);
        }
    }

    setTimeout(() => {
        queryElement(document);
    }, 1500);

    const hrefObserver = new MutationObserver(m => {
        m.forEach(mm => {
            formatHref(mm.target, mm.addedNodes);
            mm.addedNodes.forEach(i => queryElement(i));
        });
    });
    hrefObserver.observe(document, { subtree: true, childList: true });

})();