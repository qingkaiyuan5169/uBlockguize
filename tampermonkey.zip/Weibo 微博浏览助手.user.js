// ==UserScript==
// @name               Weibo 微博浏览助手
// @name:zh-CN         Weibo 微博浏览助手
// @name:en            Weibo Enhancer Tools
// @description        增强功能：一键生成微博截图、批量下载图片、博文、视频、支持 LivePhoto 下载、微博长文不关注看全文。
// @description:zh-CN  增强功能：一键生成微博截图、批量下载图片、博文、视频、支持 LivePhoto 下载、微博长文不关注看全文。
// @description:en     Enhanced Features: Onekey Weibo Screenshot, Batch Pictures Download, Download Caption, Video Download, LivePhoto Download Support, View full article without following.
// @namespace          https://www.runningcheese.com/userscripts
// @author             RunningCheese
// @version            1.6
// @match              http*://www.weibo.com/*
// @match              http*://weibo.com/*
// @noframes
// @connect            weibo.com
// @connect            *.weibo.com
// @connect            sinaimg.cn
// @connect            *.sinaimg.cn
// @connect            weibocdn.com
// @connect            *.weibocdn.com
// @connect            miaopai.com
// @connect            *.miaopai.com
// @connect            weibous.com
// @connect            *.weibous.com
// @grant              GM_registerMenuCommand
// @grant              unsafeWindow
// @grant              GM_xmlhttpRequest
// @icon               https://weibo.com/favicon.ico
// @require            https://cdnjs.cloudflare.com/ajax/libs/jszip/3.9.1/jszip.min.js
// @license            MIT
// @downloadURL https://update.greasyfork.org/scripts/577420/Weibo%20%E5%BE%AE%E5%8D%9A%E6%B5%8F%E8%A7%88%E5%8A%A9%E6%89%8B.user.js
// @updateURL https://update.greasyfork.org/scripts/577420/Weibo%20%E5%BE%AE%E5%8D%9A%E6%B5%8F%E8%A7%88%E5%8A%A9%E6%89%8B.meta.js
// ==/UserScript==

(function() {
    'use strict';

    // ======================================================

    let downloadQueueCard = document.createElement('div');
    downloadQueueCard.style.display = 'none';
    downloadQueueCard.style.position = 'fixed';
    downloadQueueCard.style.bottom = '0.5rem';
    downloadQueueCard.style.left = '0.5rem';
    downloadQueueCard.style.maxHeight = '50vh';
    downloadQueueCard.style.overflowY = 'auto';
    downloadQueueCard.style.overflowX = 'hidden';
    downloadQueueCard.style.zIndex = '2147483647';
    let downloadQueueTitle = document.createElement('div');
    downloadQueueTitle.textContent = '下载队列';
    downloadQueueTitle.style.fontSize = '0.8rem';
    downloadQueueTitle.style.color = 'gray';
    downloadQueueTitle.style.display = 'none';
    downloadQueueCard.appendChild(downloadQueueTitle);
    document.body.appendChild(downloadQueueCard);
    let progressBar = document.createElement('div');
    progressBar.style.height = '1.4rem';
    progressBar.style.width = '23rem';
    progressBar.style.borderStyle = 'solid';
    progressBar.style.borderWidth = '0.1rem';
    progressBar.style.borderColor = 'grey';
    progressBar.style.borderRadius = '0.5rem';
    progressBar.style.boxSizing = 'content-box';
    progressBar.style.marginTop = '0.5rem';
    progressBar.style.marginRight = '1rem';
    progressBar.style.position = 'relative';
    let progressText = document.createElement('div');
    progressText.style.mixBlendMode = 'screen';
    progressText.style.width = '100%';
    progressText.style.textAlign = 'center';
    progressText.style.color = 'orange';
    progressText.style.fontSize = '0.7rem';
    progressText.style.lineHeight = '1.4rem';
    progressText.style.overflow = 'hidden';
    progressBar.appendChild(progressText);
    let progressCloseBtn = document.createElement('button');
    progressCloseBtn.style.border = 'unset';
    progressCloseBtn.style.background = 'unset';
    progressCloseBtn.style.color = 'orange';
    progressCloseBtn.style.position = 'absolute';
    progressCloseBtn.style.right = '0';
    progressCloseBtn.style.top = '0.1rem';
    progressCloseBtn.style.fontSize = '1rem';
    progressCloseBtn.style.lineHeight = '1rem';
    progressCloseBtn.style.cursor = 'pointer';
    progressCloseBtn.textContent = '×';
    progressCloseBtn.title = '取消';
    progressCloseBtn.onmouseover = function(e){
        this.style.color = 'red';
    }
    progressCloseBtn.onmouseout = function(e){
        this.style.color = 'orange';
    }
    progressBar.appendChild(progressCloseBtn);

    function promptSave(blob, name) {
        const link = document.createElement("a");
        link.style.display = "none";
        link.href = URL.createObjectURL(blob);
        link.download = name;
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        const timeout = setTimeout(() => {
            URL.revokeObjectURL(link.href);
            link.parentNode.removeChild(link);
        }, 1000);
    }

    function xhrCall(url, method = 'GET', data = null) {
        return new Promise(function(resolve, reject) {
            let oReq = new XMLHttpRequest();
            oReq.open(method, url);
            oReq.responseType = 'json';
            oReq.onload = (e) => { resolve(oReq.response); };
            oReq.onerror = (e) => { resolve(null); };
            oReq.onabort = (e) => { resolve(null); };
            oReq.ontimeout = (e) => { resolve(null); };
            oReq.setRequestHeader('X-XSRF-TOKEN', readCookie('XSRF-TOKEN'));
            if(typeof(data) === 'string') {
                oReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                oReq.send(data);
            } else if(typeof(data) === 'object') {
                oReq.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
                oReq.send(JSON.stringify(data));
            } else {
                oReq.send();
            }
        });
    }

    function bridgeCall(url, method = 'GET', data = null, ua = null) {
        return new Promise(function(resolve, reject) {
            let headers = {
                'Referer': 'https://' + location.host,
                'Origin': 'https://' + location.host,
                'X-XSRF-TOKEN': readCookie('XSRF-TOKEN'),
            };
            if(typeof(data) === 'string') {
                headers['Content-Type'] = 'application/x-www-form-urlencoded';
            } else if(typeof(data) === 'object') {
                headers['Content-Type'] = 'application/json;charset=UTF-8';
            }
            if(ua) {
                headers['User-Agent'] = ua;
            }
            GM_xmlhttpRequest({
                method,
                url,
                data,
                responseType: 'json',
                headers,
                onload: ({ status, response }) => {
                    resolve(response)
                },
                onabort: function(e) { resolve(null); },
                onerror: function(e) { resolve(null); },
                ontimeout: function(e) { resolve(null); },
            });
        });
    }

    function onFail(e, url, name, headerFlag, progress, zipMode = false) {
        progress.style.background = 'red';
        progress.firstChild.textContent = name + ' [' + (e.error || 'Unknown') + ']';
        progress.firstChild.style.color = 'yellow';
        progress.firstChild.style.mixBlendMode = 'unset';
        if (!zipMode) {
            let progressRetryBtn = document.createElement('button');
            progressRetryBtn.style.border = 'unset';
            progressRetryBtn.style.background = 'unset';
            progressRetryBtn.style.color = 'yellow';
            progressRetryBtn.style.position = 'absolute';
            progressRetryBtn.style.right = '1.2rem';
            progressRetryBtn.style.top = '0.05rem';
            progressRetryBtn.style.fontSize = '1rem';
            progressRetryBtn.style.lineHeight = '1rem';
            progressRetryBtn.style.cursor = 'pointer';
            progressRetryBtn.style.letterSpacing = '-0.2rem';
            progressRetryBtn.textContent = '⤤⤦';
            progressRetryBtn.title = '重试';
            progressRetryBtn.onmouseover = function(e){
                this.style.color = 'white';
            }
            progressRetryBtn.onmouseout = function(e){
                this.style.color = 'yellow';
            }
            progressRetryBtn.onclick = function(e) {
                this.parentNode.remove();
                startFetch(url, name, headerFlag);
            }
            progress.insertBefore(progressRetryBtn, progress.lastChild);
        }
        progress.lastChild.title = '关闭';
        progress.lastChild.style.color = 'yellow';
        progress.lastChild.onmouseover = function(e){
            this.style.color = 'white';
        };
        progress.lastChild.onmouseout = function(e){
            this.style.color = 'yellow';
        };
        progress.lastChild.onclick = function(e) {
            this.parentNode.remove();
            if(progress.parent.childElementCount == 1) progress.parent.firstChild.style.display = 'none';
        };
    }

    function readCookie(key = null) {
        let cookiesArr = document.cookie.split('; ');
        let cookiesObj = {};
        for (const cookie of cookiesArr) {
            let [ name, value ] = cookie.split('=');
            cookiesObj[name] = value;
        }
        if (key) {
            return cookiesObj[key];
        } else {
            return cookiesObj;
        }
    }

    function startFetch(url, name, headerFlag = false, zipMode = false) {
        downloadQueueTitle.style.display = 'block';
        let progress = downloadQueueCard.appendChild(progressBar.cloneNode(true));
        progress.firstChild.textContent = name + ' [0%]';
        if (zipMode) {
            return new Promise(function(resolve, reject) {
                const download = GM_xmlhttpRequest({
                    method: 'GET',
                    url,
                    responseType: 'blob',
                    headers: headerFlag ? {
                        'Referer': 'https://' + location.host.replace(/^s\./, ''),
                        'Origin': 'https://' + location.host.replace(/^s\./, '')
                    } : null,
                    onprogress: (e) => {
                        const percent = e.done / e.total * 100;
                        progress.style.background = 'linear-gradient(to right, green ' + percent + '%, transparent ' + percent + '%)';
                        progress.firstChild.textContent = name + ' [' + percent.toFixed(0) + '%]';
                    },
                    onload: ({ status, response }) => {
                        const timeout = setTimeout(() => {
                            progress.remove();
                            if(downloadQueueCard.childElementCount == 1) downloadQueueTitle.style.display = 'none';
                        }, 1000);
                        progress.lastChild.onclick = function(e) {
                            clearTimeout(timeout);
                            this.parentNode.remove();
                            if(downloadQueueCard.childElementCount == 1) downloadQueueTitle.style.display = 'none';
                        };
                        resolve(response);
                    },
                    onabort: function(e) { resolve(null); },
                    onerror: function(e) { onFail(e, url, name, headerFlag, progress); resolve(null); },
                    ontimeout: function(e) { onFail(e, url, name, headerFlag, progress); resolve(null); },
                });
                progress.lastChild.onclick = function(e) {
                    download.abort();
                    this.parentNode.remove();
                    if(downloadQueueCard.childElementCount == 1) downloadQueueTitle.style.display = 'none';
                };

            });
        } else {
            return new Promise(function(resolve, reject) {
                const download = GM_xmlhttpRequest({
                    method: 'GET',
                    url,
                    responseType: 'blob',
                    headers: headerFlag ? {
                        'Referer': 'https://' + location.host,
                        'Origin': 'https://' + location.host
                    } : null,
                    onprogress: (e) => {
                        const percent = e.done / e.total * 100;
                        progress.style.background = 'linear-gradient(to right, green ' + percent + '%, transparent ' + percent + '%)';
                        progress.firstChild.textContent = name + ' [' + percent.toFixed(0) + '%]';
                    },
                    onload: ({ status, response }) => {
                        const timeout = setTimeout(() => {
                            progress.remove();
                            if(downloadQueueCard.childElementCount == 1) downloadQueueTitle.style.display = 'none';
                        }, 1000);
                        progress.lastChild.onclick = function(e) {
                            clearTimeout(timeout);
                            this.parentNode.remove();
                            if(downloadQueueCard.childElementCount == 1) downloadQueueTitle.style.display = 'none';
                        };
                        promptSave(response, name);
                        resolve(null);
                    },
                    onabort: function(e) { resolve(null); },
                    onerror: function(e) { onFail(e, url, name, headerFlag, progress); resolve(null); },
                    ontimeout: function(e) { onFail(e, url, name, headerFlag, progress); resolve(null); },
                });
                progress.lastChild.onclick = function(e) {
                    download.abort();
                    this.parentNode.remove();
                    if(downloadQueueCard.childElementCount == 1) downloadQueueTitle.style.display = 'none';
                };
            });
        }
    }

    function buildName(nameSetting, originalName, ext, userName, userId, postId, postUid, index, postTime, content, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetContent, retweetRegion) {
        let setName = nameSetting;
        setName = setName.replace('{ext}', ext);
        setName = setName.replace('{original}', originalName);
        setName = setName.replace('{username}', userName);
        setName = setName.replace('{userid}', userId);
        setName = setName.replace('{mblogid}', postId);
        setName = setName.replace('{uid}', postUid);
        setName = setName.replace('{index}', index);
        setName = setName.replace('{content}', content.substring(0, 25));
        setName = setName.replace('{region}', region);
        let YYYY, MM, DD, HH, mm, ss;
        const postAt = new Date(postTime);
        if (postTime) {
            YYYY = postAt.getFullYear().toString();
            MM = (postAt.getMonth() + 1).toString().padStart(2, '0');
            DD = postAt.getDate().toString().padStart(2, '0');
            HH = postAt.getHours().toString().padStart(2, '0');
            mm = postAt.getMinutes().toString().padStart(2, '0');
            ss = postAt.getSeconds().toString().padStart(2, '0');
        }
        setName = setName.replace('{YYYY}', YYYY);
        setName = setName.replace('{MM}', MM);
        setName = setName.replace('{DD}', DD);
        setName = setName.replace('{HH}', HH);
        setName = setName.replace('{mm}', mm);
        setName = setName.replace('{ss}', ss);
        return setName.replace(/[<|>|*|"|\/|\|:|?|\n]/g, '_');
    }

    function showPicker(downloadList, packName, textContent, callback) {
        const existing = document.getElementById('wb-download-picker');
        if (existing) existing.remove();

        const ORANGE = '#ff8200';

        const overlay = elements.createAs('div', {
            id: 'wb-download-picker',
            style: `
                position: fixed;
                top: 0; left: 0; right: 0; bottom: 0;
                background: rgba(0,0,0,0.6);
                z-index: 1000000001;
                display: flex;
                align-items: center;
                justify-content: center;
            `
        }, document.body);

        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) { overlay.remove(); callback([]); }
        });

        const container = elements.createAs('div', {
            style: `
                background: #fff;
                border-radius: 12px;
                width: 90vw;
                max-width: 560px;
                height: 80vh;
                display: flex;
                flex-direction: column;
                box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            `
        }, overlay);

        const header = elements.createAs('div', {
            style: `
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 14px 20px;
                border-bottom: 1px solid #eee;
                flex-shrink: 0;
            `
        }, container);

        elements.createAs('span', {
            textContent: '选择要下载的文件（共 ' + downloadList.length + ' 项）',
            style: 'font-size: 15px; font-weight: bold; color: #333;'
        }, header);

        elements.createAs('span', {
            textContent: '\u2715',
            style: 'font-size: 20px; cursor: pointer; color: #999; padding: 0 4px; line-height: 1;',
            onclick: () => { overlay.remove(); callback([]); }
        }, header);

        const listContainer = elements.createAs('div', {
            style: `
                flex: 1 1 0;
                overflow-y: auto;
                padding: 14px 20px;
                min-height: 0;
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
                grid-auto-rows: min-content;
                gap: 12px;
                align-content: start;
            `
        }, container);

        const checkboxes = [];

        downloadList.forEach((item, i) => {
            const card = elements.createAs('div', {
                style: `
                    position: relative;
                    border-radius: 8px;
                    overflow: hidden;
                    cursor: pointer;
                    border: 2px solid ` + ORANGE + `;
                    background: #fff;
                    transition: border-color 0.2s;
                    display: flex;
                    flex-direction: column;
                `
            }, listContainer);

            const imgWrap = elements.createAs('div', {
                style: `
                    position: relative;
                    width: 100%;
                    aspect-ratio: 1;
                    overflow: hidden;
                `
            }, card);

            if (item.type === 'video') {
                const vidBg = elements.createAs('div', {
                    style: 'width:100%;height:100%;background:#222;display:flex;align-items:center;justify-content:center;'
                }, imgWrap);
                if (item.previewUrl) {
                    elements.createAs('img', {
                        src: item.previewUrl,
                        style: 'width:100%;height:100%;object-fit:cover;position:absolute;top:0;left:0;opacity:0.6;',
                        onerror: function() { this.remove(); }
                    }, vidBg);
                }
                elements.createAs('div', {
                    innerHTML: '<svg width="32" height="32" viewBox="0 0 16 16" style="fill:' + ORANGE + ';position:relative;z-index:1;"><path d="M4 2.5a.5.5 0 0 1 .8-.4l8 5.5a.5.5 0 0 1 0 .8l-8 5.5a.5.5 0 0 1-.8-.4v-11z"/></svg>'
                }, vidBg);
            } else {
                elements.createAs('img', {
                    src: item.previewUrl || item.url,
                    style: 'width:100%;height:100%;object-fit:cover;display:block;',
                    onerror: function() { this.style.display = 'none'; }
                }, imgWrap);
            }

            const cb = elements.createAs('input', {
                type: 'checkbox',
                checked: true,
                style: `
                    position: absolute;
                    top: 6px;
                    right: 6px;
                    width: 20px;
                    height: 20px;
                    cursor: pointer;
                    accent-color: ` + ORANGE + `;
                    z-index: 2;
                    margin: 0;
                `
            }, imgWrap);
            checkboxes.push(cb);

            elements.createAs('span', {
                textContent: (item.type === 'video' ? '视频' : '图片') + ' ' + (i + 1),
                style: `
                    display: block;
                    text-align: center;
                    padding: 6px 4px;
                    font-size: 12px;
                    color: #666;
                    user-select: none;
                    flex-shrink: 0;
                `
            }, card);

            card.addEventListener('click', function(e) {
                if (e.target !== cb) {
                    cb.checked = !cb.checked;
                    updateSelectionStyle();
                    updateDownloadBtn();
                }
            });

            function updateSelectionStyle() {
                card.style.borderColor = cb.checked ? ORANGE : '#ddd';
            }

            cb.addEventListener('change', function() {
                updateSelectionStyle();
                updateDownloadBtn();
            });
        });

        const footer = elements.createAs('div', {
            style: `
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 12px 20px;
                border-top: 1px solid #eee;
                gap: 10px;
                flex-shrink: 0;
            `
        }, container);

        const btnBase = 'padding: 7px 15px; border: none; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: bold; transition: opacity 0.2s;';

        const leftGroup = elements.createAs('div', {
            style: 'display: flex; gap: 8px;'
        }, footer);

        elements.createAs('button', {
            textContent: '全选',
            style: btnBase + 'background: #f0f0f0; color: #333;',
            onclick: () => {
                checkboxes.forEach(cb => cb.checked = true);
                updateDownloadBtn();
            }
        }, leftGroup);

        elements.createAs('button', {
            textContent: '反选',
            style: btnBase + 'background: #f0f0f0; color: #333;',
            onclick: () => {
                checkboxes.forEach(cb => cb.checked = !cb.checked);
                updateDownloadBtn();
            }
        }, leftGroup);

        const rightGroup = elements.createAs('div', {
            style: 'display: flex; gap: 8px;'
        }, footer);

        elements.createAs('button', {
            textContent: '取消',
            style: btnBase + 'background: #f0f0f0; color: #333;',
            onclick: () => { overlay.remove(); callback([]); }
        }, rightGroup);

        const downloadBtn = elements.createAs('button', {
            textContent: '下载选中 (' + downloadList.length + ')',
            style: btnBase + 'background: ' + ORANGE + '; color: #fff;',
            onclick: () => {
                const selected = downloadList.filter((_, idx) => checkboxes[idx].checked);
                if (selected.length === 0) return;
                overlay.remove();
                callback(selected);
            }
        }, rightGroup);

        function updateDownloadBtn() {
            const count = checkboxes.filter(cb => cb.checked).length;
            downloadBtn.textContent = '下载选中 (' + count + ')';
            if (count === 0) {
                downloadBtn.disabled = true;
                downloadBtn.style.opacity = '0.45';
            } else {
                downloadBtn.disabled = false;
                downloadBtn.style.opacity = '1';
            }
        }

        checkboxes.forEach(cb => {
            cb.addEventListener('change', updateDownloadBtn);
        });
    }

    async function runBatch(downloadList, packName, textContent) {
        let zip = new JSZip();
        let promises = downloadList.map(async function(ele, idx) {
            return await startFetch(ele.url, ele.name, ele.headerFlag, true).then(function(data) {
                const currDate = new Date();
                const dateWithOffset = new Date(currDate.getTime() - currDate.getTimezoneOffset() * 60000);
                if (data) zip.file(downloadList[idx].name, data, { date: dateWithOffset });
            });
        });
        const responseList = await Promise.all(promises);
        const content = await zip.generateAsync({ type: 'blob', streamFiles: true });
        if (zip.files && Object.keys(zip.files).length > 0) promptSave(content, packName);
    }

    async function parseVideo(mediaInfo, padLength, userName, userId, postId, postUid, index, postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion) {
        const newList = [];
        let largeVidUrl = mediaInfo.playback_list ? mediaInfo.playback_list[0].play_info.url : ( mediaInfo.mp4_hd_url || mediaInfo.stream_url_hd || mediaInfo.stream_url );
        if(mediaInfo.hasOwnProperty('h5_url') && mediaInfo.h5_url) {
            const urlObj = new URL(mediaInfo.h5_url);
            const fid = urlObj.searchParams.get('fid');
            let url = 'https://' + location.host + '/tv/api/component?page=/tv/show/' + fid;
            let data = 'data={"Component_Play_Playinfo":{"oid":"' + fid + '"}}';
            let tvRes = await bridgeCall(url, 'POST', data);
            if(tvRes && tvRes.data && tvRes.data.Component_Play_Playinfo && tvRes.data.Component_Play_Playinfo.urls && Object.keys(tvRes.data.Component_Play_Playinfo.urls).length > 0) {
                largeVidUrl = tvRes.data.Component_Play_Playinfo.urls[Object.keys(tvRes.data.Component_Play_Playinfo.urls)[0]];
                if(largeVidUrl.startsWith('//')) {
                    largeVidUrl = 'http:' + largeVidUrl;
                }
            }
        }
        let vidName = largeVidUrl.split('?')[0];
        vidName = vidName.split('/')[vidName.split('/').length - 1].split('?')[0];
        let originalName = vidName.split('.')[0];
        let ext = vidName.split('.')[1];
        const setName = buildName('{original}.{ext}', originalName, ext, userName, userId, postId, postUid, index.toString().padStart(padLength, '0'), postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion);
        newList.push({ url: largeVidUrl, name: setName, headerFlag: true, type: 'video' });
        if(mediaInfo.hasOwnProperty('big_pic_info')) {
            let picUrl = mediaInfo.big_pic_info.pic_big.url;
            let largePicUrl = picUrl.replace('/orj480/', '/large/');
            let picName = largePicUrl.split('/')[largePicUrl.split('/').length - 1].split('?')[0];
            let originalName = picName.split('.')[0];
            let ext = picName.split('.')[1];
            const setName = buildName('{original}.{ext}', originalName, ext, userName, userId, postId, postUid, index.toString().padStart(padLength, '0'), postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion);
            newList.push({ url: largePicUrl, name: setName, headerFlag: true, type: 'image', previewUrl: largePicUrl.replace('/large/', '/thumb150/').replace('/oslarge/', '/thumb150/') });
        }
        return newList;
    }

    function parseImage(pic, padLength, userName, userId, postId, postUid, index, postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion) {
        let newList = [];
        let picUrl = pic.largest?.url || pic.pic_big?.url;
        let picSize = picUrl.split('/')[3];
        let largePicUrl = picUrl.replace('/' + picSize + '/', '/large/');
        let picName = largePicUrl.split('/')[largePicUrl.split('/').length - 1].split('?')[0];
        let originalName = picName.split('.')[0];
        let ext = picName.split('.')[1];
        const setName = buildName('{original}.{ext}', originalName, ext, userName, userId, postId, postUid, index.toString().padStart(padLength, '0'), postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion);
        newList.push({ url: largePicUrl, name: setName, headerFlag: true, type: 'image', previewUrl: largePicUrl.replace('/large/', '/thumb150/').replace('/oslarge/', '/thumb150/') });
        if(pic.hasOwnProperty('video')) {
            let videoUrl = pic.video;
            let videoName = videoUrl.split('%2F')[videoUrl.split('%2F').length - 1].split('?')[0];
            videoName = videoName.split('/')[videoName.split('/').length - 1].split('?')[0];
            if (!videoName.includes('.')) videoName = videoUrl.split('/')[videoUrl.split('/').length - 1].split('?')[0];
            let originalName = videoName.split('.')[0];
            let ext = videoName.split('.')[1];
            const setName = buildName('{original}.{ext}', originalName, ext, userName, userId, postId, postUid, index.toString().padStart(padLength, '0'), postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion);
            newList.push({ url: videoUrl, name: setName, headerFlag: true, type: 'video' });
        }
        return newList;
    }

    async function fetchMedia(id, idx = -1) {
        let resJson;
        if (location.host == 's.weibo.com') {
            resJson = await bridgeCall('https://weibo.com/ajax/statuses/show?id=' + id);
        } else {
            resJson = await xhrCall('https://' + location.host + '/ajax/statuses/show?id=' + id);
        }
        let status = resJson;
        let retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion;
        if(resJson.hasOwnProperty('retweeted_status')) {
            status = resJson.retweeted_status;
            retweetPostId = resJson.mblogid;
            retweetUserName = resJson.user.screen_name;
            retweetUserId = resJson.user.idstr;
            retweetPostUid = resJson.idstr;
            retweetPostTime = resJson.created_at;
            retweetText = resJson.text_raw;
            retweetRegion = resJson.region_name ? resJson.region_name.split(/\s/).pop() : '';
        }
        const postId = status.mblogid;
        const picInfos = status.pic_infos;
        const mixMediaInfo = status.mix_media_info;
        const userName = status.user.screen_name;
        const userId = status.user.idstr;
        const postUid = status.idstr;
        const postTime = status.created_at;
        const textRaw = status.text_raw;
        const pageInfo = status.page_info || resJson.page_info;
        const region = status.region_name ? status.region_name.split(/\s/).pop() : '';
        let downloadList = [];
        if (picInfos) {
            let padLength = Object.entries(picInfos).length.toString().length;
            if (idx === -1) {
                let index = 0;
                for (const [id, pic] of Object.entries(picInfos)) {
                    index += 1;
                    downloadList = downloadList.concat(parseImage(pic, padLength, userName, userId, postId, postUid, index, postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion));
                }
            } else {
                const pic = Object.entries(picInfos)[idx][1];
                downloadList = downloadList.concat(parseImage(pic, padLength, userName, userId, postId, postUid, idx + 1, postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion));
            }
        }
        if (mixMediaInfo && mixMediaInfo.items) {
            let padLength = Object.entries(mixMediaInfo.items).length.toString().length;
            if (idx === -1) {
                let index = 0;
                for (const [id, media] of Object.entries(mixMediaInfo.items)) {
                    index += 1;
                    if(media.type === 'video') {
                        downloadList = downloadList.concat(await parseVideo(media.data.media_info, padLength, userName, userId, postId, postUid, index, postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion));
                        downloadList = downloadList.concat(parseImage(media.data.pic_info, padLength, userName, userId, postId, postUid, index, postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion));
                    } else if (media.type === 'pic') {
                        downloadList = downloadList.concat(parseImage(media.data, padLength, userName, userId, postId, postUid, index, postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion));
                    }
                }
            } else {
                const media = Object.entries(mixMediaInfo.items)[idx][1];
                if(media.type === 'video') {
                    downloadList = downloadList.concat(await parseVideo(media.data.media_info, padLength, userName, userId, postId, postUid, idx + 1, postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion));
                    downloadList = downloadList.concat(parseImage(media.data.pic_info, padLength, userName, userId, postId, postUid, idx + 1, postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion));
                } else if (media.type === 'pic') {
                    downloadList = downloadList.concat(parseImage(media.data, padLength, userName, userId, postId, postUid, idx + 1, postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion));
                }
            }
        }
        if (pageInfo && pageInfo.media_info) {
            downloadList = downloadList.concat(await parseVideo(pageInfo.media_info, 0, userName, userId, postId, postUid, 0, postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion));
        }
        const packName = buildName('{mblogid}.zip', '{original}', '{ext}', userName, userId, postId, postUid, '{index}', postTime, textRaw, region, retweetPostId, retweetUserName, retweetUserId, retweetPostUid, retweetPostTime, retweetText, retweetRegion);
        return [downloadList, packName, undefined];
    }

    // ======================================================
    // 微博阅读助手功能
    // ======================================================

    let ttPolicy;
    if (window.trustedTypes && window.trustedTypes.createPolicy) {
        try {
            ttPolicy = window.trustedTypes.createPolicy('wb-assistant-' + Math.random().toString(36).substring(2, 9), {
                createHTML: (string) => string
            });
        } catch (e) {
            ttPolicy = { createHTML: (string) => string };
        }
    } else {
        ttPolicy = { createHTML: (string) => string };
    }

    const elements = {
        createAs(nodeType, config, appendTo) {
            const element = document.createElement(nodeType);
            if (config) {
                Object.entries(config).forEach(([key, value]) => {
                    if (key === 'innerHTML') {
                        element.innerHTML = ttPolicy.createHTML(value);
                    } else {
                        element[key] = value;
                    }
                });
            }
            if (appendTo) appendTo.appendChild(element);
            return element;
        },
        getAs(selector) {
            return document.body.querySelector(selector);
        }
    };

    const style = elements.createAs('style', {
        textContent: `
            .wb-icon-btn {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 18px;
                height: 18px;
                border-radius: 22%;
                cursor: pointer;
                transition: background-color 0.3s, transform 0.2s;
                background-color: #ff8200;
                color: white;
                text-decoration: none;
                flex-shrink: 0;
            }

            .wb-icon-btn:hover {
                background-color: #e67300;
                transform: scale(1.1);
            }

            .wb-icon-btn svg {
                width: 13px;
                height: 13px;
                fill: currentColor;
            }
        `
    }, document.head);

    const wbViewer = {
        buttonCheckInterval: null,

        getRenderData() {
            const _window = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;
            if (_window.$render_data && _window.$render_data.length > 0 && _window.$render_data[0].status) {
                return _window.$render_data[0].status;
            }
            return null;
        },

        getTextContent() {
            const status = this.getRenderData();
            if (status && status.text) {
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = status.text.replace(/<br\s*\/?>/gi, '\n');
                return tempDiv.textContent.trim();
            }

            const textEl = document.querySelector('.wbpro-feed-content') ||
                           document.querySelector('.detail_wbtext') ||
                           document.querySelector('.WB_text') ||
                           document.querySelector('div[node-type="feed_list_content"]') ||
                           document.querySelector('.card-txt');
            if (textEl) {
                const clone = textEl.cloneNode(true);
                clone.querySelectorAll('br').forEach(br => br.replaceWith('\n'));
                return clone.textContent.trim();
            }
            return '';
        },

        saveAsMarkdown() {
            const status = this.getRenderData();
            const content = this.getTextContent();
            if (!content) {
                this.showToast('未找到微博正文内容');
                return;
            }

            const author = (status && status.user && status.user.screen_name) || '';
            const createdAt = (status && status.created_at) || '';
            const sourceUrl = window.location.href;

            let md = '';
            if (author) md += `> **${author}**\n\n`;
            if (createdAt) md += `*${createdAt}*\n\n`;
            md += content + '\n';

            if (status && status.pics && status.pics.length > 0) {
                md += '\n';
                status.pics.forEach((pic, i) => {
                    const imgUrl = (pic.largest && pic.largest.url) || (pic.large && pic.large.url) || pic.url || '';
                    if (imgUrl) {
                        md += `\n![图片${i + 1}](${imgUrl})\n`;
                    }
                });
            }

            md += `\n> [查看原文](${sourceUrl})\n`;

            const name = this.extractName();
            const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
            this.triggerDownload(`${name}.md`, blob);
            this.showToast('Markdown 文档已保存！');
        },

        toLargeImageUrl(url) {
            if (!url) return url;
            return url.replace(/\/(mw690|orj360|mw1024|mw2048|thumbnail|thumb150|small|bmiddle|wap360|wap720)\//, '/large/');
        },

        generateImageUrls(status) {
            const pics = status.pics;
            if (!pics || pics.length === 0) return [];

            return pics.map(pic => {
                let bestUrl = (pic.largest && pic.largest.url) ||
                              (pic.large && pic.large.url) ||
                              pic.url ||
                              '';
                bestUrl = this.toLargeImageUrl(bestUrl);
                return bestUrl;
            }).filter(url => url);
        },

        triggerDownload(name, blob) {
            const blobUrl = URL.createObjectURL(blob);
            const tempLink = document.createElement("a");
            tempLink.href = blobUrl;
            tempLink.download = name;
            document.body.appendChild(tempLink);
            tempLink.click();
            document.body.removeChild(tempLink);
            URL.revokeObjectURL(blobUrl);
        },

        extractPostId() {
            const status = this.getRenderData();
            if (status && status.mblogid) return status.mblogid;
            const match = location.href.match(/\/(\d+)\/([A-Za-z0-9]+)/);
            if (match) return match[2];
            return null;
        },

        loadHtml2Canvas() {
            return new Promise((resolve, reject) => {
                if (typeof html2canvas !== 'undefined') { resolve(); return; }
                const script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';
                script.onload = () => resolve();
                script.onerror = () => reject(new Error('html2canvas 加载失败'));
                document.head.appendChild(script);
            });
        },

        async takeScreenshot() {
            const self = this;
            const postId = this.extractPostId();
            if (!postId) {
                this.showToast('无法获取微博ID');
                return;
            }

            let mobileData = null;
            try {
                const mobileUA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1';
                mobileData = await bridgeCall('https://m.weibo.cn/statuses/show?id=' + postId, 'GET', null, mobileUA);
            } catch (e) {
                console.error('手机版微博 API 请求失败:', e);
            }

            let status = mobileData || this.getRenderData();

            let author = '';
            let avatarUrl = '';
            let createdAt = '';
            let source = '';
            let text = '';
            let reposts = 0;
            let comments = 0;
            let attitudes = 0;
            let pics = [];

            if (status) {
                author = (status.user && status.user.screen_name) || '';
                avatarUrl = (status.user && (status.user.avatar_hd || status.user.avatar_large || status.user.profile_image_url)) || '';
                createdAt = status.created_at || '';
                source = status.source || '';
                text = status.text || status.text_raw || '';
                reposts = status.reposts_count || 0;
                comments = status.comments_count || 0;
                attitudes = status.attitudes_count || 0;
                pics = status.pics || [];

                if (text && text.includes('<')) {
                    const tempDiv = document.createElement('div');
                    tempDiv.innerHTML = text.replace(/<br\s*\/?>/gi, '\n');
                    text = tempDiv.textContent.trim();
                }
            }

            if (!author) {
                const usernameEl = this.findUsernameElement();
                if (usernameEl) {
                    author = usernameEl.textContent.trim();
                    const avatarImg = usernameEl.closest('header')?.querySelector('img') ||
                                      usernameEl.closest('[class*="head"]')?.querySelector('img') ||
                                      document.querySelector('header img[src*="sinaimg.cn"]');
                    if (avatarImg) avatarUrl = avatarImg.src;
                }
            }
            if (!createdAt) {
                const timeEl = document.querySelector('.head-info_time_6sFQg, ._time_1tpft_33, .head_ct time, .from a');
                if (timeEl) createdAt = timeEl.textContent.trim() || timeEl.getAttribute('datetime') || timeEl.getAttribute('title') || '';
            }
            if (!text) {
                text = this.getTextContent();
            }
            if (!text) {
                this.showToast('未找到微博正文内容');
                return;
            }

            this.showToast('正在生成截图...');

            try {
                await this.loadHtml2Canvas();
            } catch (e) {
                this.showToast('截图库加载失败，请检查网络');
                return;
            }

            let imageUrls = [];
            if (pics.length > 0) {
                imageUrls = pics.map(pic => {
                    let url = (pic.largest && pic.largest.url) ||
                              (pic.large && pic.large.url) ||
                              pic.url || '';
                    return this.toLargeImageUrl(url);
                }).filter(url => url);
            }
            if (imageUrls.length === 0 && status) {
                imageUrls = this.generateImageUrls(status);
            }
            if (imageUrls.length === 0) {
                const imgs = document.querySelectorAll('.wbpro-feed-content img, .detail_wbtext img, .WB_editor_iframe_new img, .card-feed .img img');
                for (const img of imgs) {
                    const src = img.src || img.getAttribute('data-src') || '';
                    if (src && src.includes('sinaimg.cn')) {
                        imageUrls.push(this.toLargeImageUrl(src));
                    }
                }
            }

            let picsHtml = '';
            if (imageUrls.length > 0) {
                if (imageUrls.length === 1) {
                    picsHtml = `<div style="margin-top:10px;border-radius:6px;overflow:hidden;border:1px solid #f0f0f0;"><img src="${imageUrls[0]}" crossorigin="anonymous" style="width:100%;display:block;" onerror="this.style.display='none'" /></div>`;
                } else {
                    const gridCols = imageUrls.length === 4 ? 2 : (imageUrls.length <= 2 ? imageUrls.length : 3);
                    picsHtml = `<div style="display:grid;grid-template-columns:repeat(${gridCols},1fr);gap:3px;margin-top:10px;">` +
                        imageUrls.map(url => {
                            return `<div style="border-radius:2px;overflow:hidden;border:1px solid #f0f0f0;aspect-ratio:1;background-image:url(${url});background-size:cover;background-position:center;background-repeat:no-repeat;"></div>`;
                        }).join('') +
                        `</div>`;
                }
            }

            let statsHtml = '';
            if (reposts > 0 || comments > 0 || attitudes > 0) {
                statsHtml = `<div style="display:flex;gap:24px;margin-top:14px;color:#999;font-size:13px;border-top:1px solid #f0f0f0;padding-top:12px;">
                    <span style="display:flex;align-items:center;gap:3px;"><svg width="14" height="14" viewBox="0 0 24 24" fill="#999"><path d="M4.75 3.79l4.603 4.3-1.706 1.82L6 8.38v7.37c0 .97.784 1.75 1.75 1.75H13V20H7.75c-2.347 0-4.25-1.9-4.25-4.25V8.38L1.853 9.91.147 8.09l4.603-4.3zm14.5 12.42l-4.603-4.3 1.706-1.82L18 11.62V4.25C18 3.28 17.216 2.5 16.25 2.5H11V0h5.25C18.597 0 20.5 1.9 20.5 4.25v7.37l1.647-1.53 1.706 1.82-4.603 4.3z"/></svg>${reposts}</span>
                    <span style="display:flex;align-items:center;gap:3px;"><svg width="14" height="14" viewBox="0 0 24 24" fill="#999"><path d="M12 1.996c6.073 0 11.004 4.93 11.004 11.004S18.073 24.004 12 24.004.996 19.074.996 13 .997 1.996 12 1.996zM12 23c5.523 0 10-4.477 10-10S17.523 3 12 3 2 7.477 2 13s4.477 10 10 10zm0-3.75a6.25 6.25 0 1 1 0-12.5 6.25 6.25 0 0 1 0 12.5z"/></svg>${comments}</span>
                    <span style="display:flex;align-items:center;gap:3px;"><svg width="14" height="14" viewBox="0 0 24 24" fill="#999"><path d="M16.697 5.5c-1.222-.06-2.679.51-3.89 2.16l-.805 1.09-.806-1.09C9.984 6.01 8.526 5.44 7.304 5.5 5.524 5.58 4 7.493 4 9.99c0 2.926 1.782 5.435 3.602 7.368.945 1.004 2.01 1.89 2.97 2.657l.527.418.038.028.035-.026.554-.437c.964-.767 2.028-1.653 2.973-2.658C18.217 15.425 20 12.916 20 9.99c0-2.497-1.524-4.41-3.303-4.49z"/></svg>${attitudes}</span>
                </div>`;
            }

            const safeAuthor = author || '微博用户';
            const largeAvatar = avatarUrl.replace(/\/orj360\//, '/large/').replace(/\/crop\..+?\//, '/large/');

            const container = document.createElement('div');
            container.style.cssText = 'position:fixed;left:-9999px;top:0;width:414px;background:#ffffff;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Helvetica Neue","Microsoft YaHei",sans-serif;color:#333;z-index:-1;padding:0;';
            container.innerHTML =
                `<div style="background:#fff;padding:12px 16px;border-bottom:1px solid #f0f0f0;">` +
                    `<div style="font-size:17px;font-weight:600;text-align:center;color:#333;">微博正文</div>` +
                `</div>` +
                `<div style="padding:16px;">` +
                    `<div style="display:flex;align-items:center;margin-bottom:10px;">` +
                        (largeAvatar ? `<img src="${largeAvatar}" crossorigin="anonymous" style="width:40px;height:40px;border-radius:50%;margin-right:10px;flex-shrink:0;" onerror="this.style.display='none'" />` :
                         `<div style="width:40px;height:40px;border-radius:50%;background:#ff8200;color:#fff;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:bold;margin-right:10px;flex-shrink:0;">${safeAuthor.charAt(0) || 'W'}</div>`) +
                        `<div style="flex:1;min-width:0;">` +
                            `<div style="font-size:16px;font-weight:600;color:#333;line-height:1.3;">${safeAuthor}</div>` +
                            (createdAt ? `<div style="font-size:12px;color:#999;margin-top:1px;">${createdAt}${source ? ' · ' + source.replace(/<[^>]+>/g, '') : ''}</div>` : '') +
                        `</div>` +
                    `</div>` +
                    `<div style="font-size:17px;line-height:1.7;color:#333;word-break:break-all;white-space:pre-wrap;margin-top:6px;">${text}</div>` +
                    picsHtml +
                    statsHtml +
                    (source ? `<div style="font-size:12px;color:#999;margin-top:12px;">${createdAt ? createdAt + ' · ' : ''}${source.replace(/<[^>]+>/g, '')}</div>` : '') +
                `</div>`;

            document.body.appendChild(container);

            await new Promise(r => setTimeout(r, 1000));

            try {
                const canvas = await html2canvas(container, {
                    scale: 3,
                    useCORS: true,
                    allowTaint: true,
                    backgroundColor: '#ffffff',
                    logging: false,
                });

                canvas.toBlob(blob => {
                    const name = self.extractName();
                    self.triggerDownload(`${name}_截图.png`, blob);
                    self.showToast('截图已保存！');
                }, 'image/png');
            } catch (err) {
                console.error('截图生成失败:', err);
                self.showToast('截图生成失败');
            } finally {
                if (container.parentNode) container.parentNode.removeChild(container);
            }
        },

        truncateString(str, maxLength) {
            if (str.length > maxLength) {
                const halfLength = Math.floor(maxLength / 2) - 1;
                return str.slice(0, halfLength) + '...' + str.slice(-halfLength);
            }
            return str;
        },

        extractName() {
            const status = this.getRenderData();
            let name = '';

            if (status) {
                const rawText = status.text || '';
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = rawText;
                const plainText = tempDiv.textContent.trim();
                const lines = plainText.split(/[\n\r]+/);
                name = lines[0] || plainText;
                name = name.replace(/[^\u4e00-\u9fa5a-zA-Z0-9 ~!@#$%&()_\-+=\[\];"',.！（）【】：“”，。《》？]/g, "");
            }

            if (!name) {
                name = document.title.replace(/[^\u4e00-\u9fa5a-zA-Z0-9 ~!@#$%&()_\-+=\[\];"',.！（）【】：“”，。《》？]/g, "").replace(/\s*微.*博\s*/g, '');
            }

            name = this.truncateString(name, 64);
            if (!name || name.trim() === '') {
                const url = window.location.href;
                const match = url.match(/\/([A-Za-z0-9]+)(?:\?|$)/);
                name = match ? match[1] : 'download';
            }
            return name;
        },

        showToast(message) {
            const toast = elements.createAs("div", {
                style: `
                    position: fixed;
                    top: 12%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    background-color: #ff8200;
                    color: white;
                    padding: 15px 20px;
                    border-radius: 8px;
                    font-size: 14px;
                    font-weight: bold;
                    z-index: 1000000000;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                `,
                textContent: message
            }, document.body);

            setTimeout(() => {
                if (document.body.contains(toast)) {
                    document.body.removeChild(toast);
                }
            }, 3000);
        },

        findUsernameElement() {
            const selectors = [
                '.Frame_name a:not([class*="woo"])',
                '.Frame_name span',
                '.head_name a',
                '[class*="isChaohua"]',
                '.detail_head .head_ct a',
                '.WB_feed_detail .WB_detail a[usercard]',
                '.Feed_header a[usercard]',
                '.card-feed .card-wrap a[usercard]',
                '.Frame_wrap a[usercard]',
                'a[usercard]',
            ];
            for (const sel of selectors) {
                try {
                    const elements = document.querySelectorAll(sel);
                    for (const el of elements) {
                        const text = el.textContent.trim();
                        if (text && text.length > 0 && text.length < 30 && el.offsetParent !== null) {
                            return el;
                        }
                    }
                } catch (e) {}
            }
            return null;
        },

        findRowParent(usernameEl) {
            let el = usernameEl.parentElement;
            while (el && el !== document.body) {
                const style = getComputedStyle(el);
                const display = style.display;
                if (display === 'flex' || display === 'inline-flex') {
                    return el;
                }
                el = el.parentElement;
            }
            if (el && el !== document.body) return el;
            return usernameEl.parentElement;
        },

        addButtons() {
            let buttonContainer = elements.getAs('#wb-helper-buttons');

            if (!buttonContainer) {
                buttonContainer = elements.createAs('div', {
                    id: 'wb-helper-buttons',
                    style: `
                        display: inline-flex;
                        align-items: center;
                        gap: 6px;
                        vertical-align: middle;
                        margin-left: 8px;
                        z-index: 999999;
                    `
                });
            }

            const usernameEl = this.findUsernameElement();

            if (buttonContainer.parentNode && buttonContainer.parentNode !== document.body) {
                if (!usernameEl || buttonContainer.previousSibling !== usernameEl) {
                    // DOM changed, re-insert
                }
            }

            if (!buttonContainer.parentNode || (usernameEl && buttonContainer.parentNode === document.body)) {
                if (usernameEl) {
                    const rowParent = this.findRowParent(usernameEl);
                    rowParent.appendChild(buttonContainer);
                    buttonContainer.style.cssText = `
                        display: inline-flex;
                        align-items: center;
                        gap: 6px;
                        vertical-align: middle;
                        margin-left: 8px;
                        z-index: 999999;
                    `;
                } else {
                    if (!buttonContainer.parentNode) {
                        document.body.appendChild(buttonContainer);
                    }
                    buttonContainer.style.cssText = `
                        position: fixed;
                        top: 12px;
                        right: 60px;
                        display: inline-flex;
                        align-items: center;
                        gap: 6px;
                        z-index: 999999;
                        background: rgba(255,255,255,0.9);
                        padding: 4px 8px;
                        border-radius: 20px;
                        box-shadow: 0 2px 8px rgba(0,0,0,0.15);
                    `;
                }
            }

            if (!elements.getAs('#wb-screenshot-btn')) {
                elements.createAs('a', {
                    id: 'wb-screenshot-btn',
                    href: 'javascript:void(0);',
                    className: 'wb-icon-btn',
                    title: '截图保存为图片',
                    innerHTML: '<svg xmlns="http://www.w3.org/2000/svg" width="1.17em" height="1em" viewBox="0 0 28 24">  <path d="M0 0h28v24H0z" fill="none" />  <path fill="currentColor" d="M13.846 9.692A4.16 4.16 0 0 1 18 13.846v.004a4.154 4.154 0 1 1-7.09-2.939a4 4 0 0 1 2.876-1.22h.063h-.003zm10.154-6h.055c1.002 0 1.908.414 2.554 1.081l.001.001a3.55 3.55 0 0 1 1.082 2.555v.058v-.003v12.924A3.693 3.693 0 0 1 24 24H3.692A3.693 3.693 0 0 1 0 20.308V7.33c0-1.002.414-1.908 1.081-2.554l.001-.001a3.55 3.55 0 0 1 2.555-1.082h.058h-.003h3.23l.735-1.962c.212-.507.557-.922.993-1.213l.01-.006A2.55 2.55 0 0 1 10.15 0h7.387a2.56 2.56 0 0 1 1.499.517L19.03.512c.445.297.791.712.996 1.201l.007.018l.735 1.962zM13.846 20.308l.091.001a6.2 6.2 0 0 0 4.472-1.896l.002-.002a6.2 6.2 0 0 0 1.897-4.474l-.001-.096v.005l.001-.092a6.2 6.2 0 0 0-1.896-4.472l-.002-.002c-1.167-1.172-2.781-1.897-4.565-1.897s-3.398.725-4.565 1.896a6.2 6.2 0 0 0-1.896 4.57v-.005l-.001.094c0 1.755.726 3.34 1.894 4.471l.002.002a6.2 6.2 0 0 0 4.474 1.897l.097-.001h-.005z" /></svg>',
                    onclick: () => this.takeScreenshot()
                }, buttonContainer);
            }

            if (!elements.getAs('#wb-copy-btn')) {
                elements.createAs('a', {
                    id: 'wb-copy-btn',
                    href: 'javascript:void(0);',
                    className: 'wb-icon-btn',
                    title: '保存为 Markdown 文档',
                    innerHTML: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.5a1 1 0 0 0-.8.4l-1.9 2.533a1 1 0 0 1-1.6 0L5.3 12.4a1 1 0 0 0-.8-.4H2a2 2 0 0 1-2-2V2zm7.194 2.766a1.688 1.688 0 0 0-.227-.272 1.467 1.467 0 0 0-.469-.324l-.008-.004A1.785 1.785 0 0 0 5.734 4C4.776 4 4 4.746 4 5.667c0 .92.776 1.666 1.734 1.666.343 0 .662-.095.931-.26-.137.389-.39.804-.81 1.22a.405.405 0 0 0 .011.59c.173.16.447.155.614-.01 1.334-1.329 1.37-2.758.941-3.706a2.461 2.461 0 0 0-.227-.4zM11 7.073c-.136.389-.39.804-.81 1.22a.405.405 0 0 0 .012.59c.172.16.446.155.613-.01 1.334-1.329 1.37-2.758.942-3.706a2.466 2.466 0 0 0-.228-.4 1.686 1.686 0 0 0-.227-.273 1.466 1.466 0 0 0-.469-.324l-.008-.004A1.785 1.785 0 0 0 10.07 4c-.957 0-1.734.746-1.734 1.667 0 .92.777 1.666 1.734 1.666.343 0 .662-.095.931-.26z"/></svg>',
                    onclick: () => this.saveAsMarkdown()
                }, buttonContainer);
            }

            if (!elements.getAs('#wb-download-btn')) {
                const self = this;
                const dlBtn = elements.createAs('a', {
                    id: 'wb-download-btn',
                    href: 'javascript:void(0);',
                    className: 'wb-icon-btn',
                    title: '下载视频',
                    innerHTML: '<svg width="14" height="14" viewBox="0 0 14 14"><path fill="currentColor" fill-rule="evenodd" d="M7 14A7 7 0 1 0 7 0a7 7 0 0 0 0 14m3.146-5.69l-2.793 2.793a.5.5 0 0 1-.707 0L3.854 8.31a.5.5 0 0 1 .353-.853H6V3.75a1 1 0 0 1 2 0v3.707h1.793a.5.5 0 0 1 .353.853" clip-rule="evenodd"/></svg>',
                }, buttonContainer);
                dlBtn.addEventListener('click', async (e) => {
                    e.preventDefault();
                    try {
                        const status = self.getRenderData();
                        let postId = null;
                        // 从 status 中获取 mblogid
                        if (status && status.mblogid) {
                            postId = status.mblogid;
                        }
                        // 从 URL 中尝试提取
                        if (!postId) {
                            const match = location.href.match(/\/(\d+)\/([A-Za-z0-9]+)/);
                            if (match) postId = match[2];
                        }
                        if (!postId) {
                            self.showToast('未找到可下载的微博');
                            return;
                        }
                        const [downloadList, packName, textContent] = await fetchMedia(postId);
                        if (!downloadList || downloadList.length === 0) {
                            self.showToast('未找到可下载的文件');
                            return;
                        }
                        showPicker(downloadList, packName, textContent, async function(selected) {
                            if (selected.length === 0) return;
                            await runBatch(selected, packName, textContent);
                        });
                    } catch (err) {
                        console.error('下载出错:', err);
                        self.showToast('下载失败，请重试');
                    }
                });
            }

        },

        startButtonCheck() {
            if (this.buttonCheckInterval) {
                clearInterval(this.buttonCheckInterval);
            }
            this.buttonCheckInterval = setInterval(() => {
                this.addButtons();
            }, 200);
        },

        init() {
            this.addButtons();
            this.startButtonCheck();
            console.log('微博浏览助手初始化成功');

            let lastUrl = location.href;
            new MutationObserver(() => {
                if (lastUrl !== location.href) {
                    lastUrl = location.href;
                    setTimeout(() => {
                        this.addButtons();
                    }, 300);
                }
            }).observe(document.body, {
                childList: true,
                subtree: true
            });
        }
    };

    // 微博长文不关注看全文
    function disableArticleHiding() {
        if (document.getElementById("SinaAutoDisableHiding")) {
            return;
        }
        var style = document.createElement("style");
        style.type = "text/css";
        var cssString = ".arc-body-main,.s_card,.WB_editor_iframe_new,#article_body,.WB_editor_iframe_word {overflow:hidden !important; height:auto !important; max-height:99999999px !important;} #float-btn,.look_more,.look_more_a,.artical_add_box,.arc-body-main-more, #article_body .pictureBottomBtn, .collapseWrapper, #article_body .shareA, #article_body .mask, .landad-inner{display: none !important}";
        try {
            style.appendChild(document.createTextNode(cssString));
        } catch (ex) {
            style.styleSheet.cssText = cssString;
        }
        style.setAttribute("id", "SinaAutoDisableHiding");
        var head = document.getElementsByTagName("head")[0];
        head.appendChild(style);
    }
    setInterval(disableArticleHiding, 1000);
    disableArticleHiding();

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => wbViewer.init());
    } else {
        wbViewer.init();
    }
})();
