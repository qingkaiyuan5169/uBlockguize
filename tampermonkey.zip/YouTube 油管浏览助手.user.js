// ==UserScript==
// @name               YouTube 油管浏览助手
// @name:zh-CN         YouTube 油管浏览助手
// @name:en            YouTube Enhancer Tools
// @description        增强功能：查看封面、下载字幕、下载视频、AI 总结字幕。
// @description:zh-CN  增强功能：查看封面、下载字幕、下载视频、AI 总结字幕。
// @description:en     Enhanced Features: View Cover, Download Subtitles, Download Video, AI Subtitle Summary.
// @namespace          https://www.runningcheese.com/userscripts
// @author             RunningCheese
// @version            3.9
// @match              http*://www.youtube.com/*
// @match              http*://m.youtube.com/*
// @match              https://www.doubao.com/chat/*
// @match              https://chatgpt.com/*
// @match              https://chat.deepseek.com/*
// @match              https://www.qianwen.com/*
// @match              https://gemini.google.com/*
// @icon               https://t1.gstatic.cn/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&size=32&url=https://www.youtube.com
// @grant              GM_setValue
// @grant              GM_getValue
// @grant              GM_registerMenuCommand
// @grant              GM_addElement
// @grant              unsafeWindow
// @license            MIT
// @downloadURL https://update.greasyfork.org/scripts/543423/YouTube%20%E6%B2%B9%E7%AE%A1%E6%B5%8F%E8%A7%88%E5%8A%A9%E6%89%8B.user.js
// @updateURL https://update.greasyfork.org/scripts/543423/YouTube%20%E6%B2%B9%E7%AE%A1%E6%B5%8F%E8%A7%88%E5%8A%A9%E6%89%8B.meta.js
// ==/UserScript==

(function() {
    'use strict';

    // ═══════════════════════════════════════════
    //  AI 自动填写模块
    // ═══════════════════════════════════════════

    const BILI_PENDING_KEY = 'ytb_ai_pending';

    function _sleep(ms) {
        return new Promise(function(resolve) { setTimeout(resolve, ms); });
    }

    function _waitFor(getter, timeoutMs, intervalMs) {
        var deadline = Date.now() + (timeoutMs || 25000);
        function check() {
            var value = getter();
            if (value) return Promise.resolve(value);
            if (Date.now() >= deadline) return Promise.resolve(null);
            return _sleep(intervalMs || 250).then(check);
        }
        return check();
    }

    function _isVisibleElement(el) {
        if (!el) return false;
        try {
            var style = getComputedStyle(el);
            if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
            var rect = el.getBoundingClientRect();
            return rect.width > 0 && rect.height > 0;
        } catch (e) { return false; }
    }

    // 接收端专用的 Toast（若当前页面已有 showToast 则复用）
    function showToast(msg, duration) {
        var toast = document.getElementById('u2b-ai-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'u2b-ai-toast';
            toast.style.cssText = 'position:fixed;top:5%;left:50%;transform:translateX(-50%);background:#3F7FEA;color:#fff;padding:16px 18px;min-height:20px;min-width:180px;line-height:1.2;border-radius:13px;font-size:14px;font-family:sans-serif;z-index:2147483647;pointer-events:none;opacity:0;transition:opacity 0.25s ease;box-shadow:0 2px 8px rgba(0,122,255,0.25),0 0 0 0.5px rgba(0,122,255,0.1);box-sizing:border-box;display:flex;align-items:center;justify-content:center;';
            document.body.appendChild(toast);
        }
        toast.textContent = msg;
        toast.style.opacity = '1';
        clearTimeout(toast._timer);
        toast._timer = setTimeout(function() { toast.style.opacity = '0'; }, duration || 2000);
    }

    function _setNativeInputValue(el, value) {
        var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        var setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
        if (setter) setter.call(el, value);
        else el.value = value;
    }

    // 填入内容（支持 textarea 和 contenteditable）
    function _fillAiInput(input, prompt) {
        // 分别压缩每段，保留段落间的空行
        prompt = prompt.split(/\n{2,}/).map(function(s) {
            return s.replace(/\r\n/g, ' ').replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();
        }).join('\n\n\n');
        input.focus();
        if (input instanceof HTMLTextAreaElement || input instanceof HTMLInputElement) {
            _setNativeInputValue(input, prompt);
            input.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: prompt }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
            return;
        }
        // contenteditable 元素（用 insertHTML + <br> 确保换行正确渲染）
        input.focus();
        window.getSelection().removeAllRanges();
        var range = document.createRange();
        range.selectNodeContents(input);
        window.getSelection().addRange(range);
        var html = prompt.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
        document.execCommand('insertHTML', false, html);
    }

    // 查找 AI 发送按钮
    function _findAiSendButton() {
        var selectors = [
            '#flow-end-msg-send',
            'button[data-testid="send-button"]',
            'button[aria-label*="Send"]',
            'button[aria-label*="发送"]',
            'form button[type="submit"]'
        ];
        var buttons = [];
        selectors.forEach(function(selector) {
            Array.from(document.querySelectorAll(selector)).forEach(function(btn) { buttons.push(btn); });
        });
        return buttons.find(function(btn) {
            return _isVisibleElement(btn) && !btn.disabled && btn.getAttribute('aria-disabled') !== 'true' && !btn.closest('[aria-hidden="true"]');
        }) || null;
    }

    // 平台配置
    var platformInfo = {
        doubao:   { label: '豆包',    url: 'https://www.doubao.com/chat/',     host: 'www.doubao.com' },
        qianwen:  { label: '千问',    url: 'https://www.qianwen.com/',         host: 'www.qianwen.com' },
        deepseek: { label: 'DeepSeek', url: 'https://chat.deepseek.com/',      host: 'chat.deepseek.com' },
        chatgpt:  { label: 'ChatGPT', url: 'https://chatgpt.com/',            host: 'chatgpt.com' },
        gemini:   { label: 'Gemini',  url: 'https://gemini.google.com/',       host: 'gemini.google.com' },
    };

    // 平台专用选择器
    var platformSelectors = {
        doubao: [
            '[data-testid="chat_input_input"]',
            'div[contenteditable="true"][data-testid="chat_input_input"]',
            'div[contenteditable="true"]',
            'textarea[placeholder]'
        ],
        generic: [
            '#prompt-textarea',
            '#chat-input',
            'textarea[placeholder*="Send a message"]',
            'textarea[placeholder*="给"]',
            'textarea[placeholder*="输入"]',
            'textarea[placeholder*="提问"]',
            'div[contenteditable="true"]',
            'textarea[placeholder]'
        ]
    };

    function _findInputBySelectors(selectorList) {
        var candidates = [];
        selectorList.forEach(function(selector) {
            Array.from(document.querySelectorAll(selector)).forEach(function(el) { candidates.push(el); });
        });
        return candidates.find(function(el) { return _isVisibleElement(el) && !el.closest('[aria-hidden="true"]'); }) || null;
    }

    async function _sendPendingToPlatform(platform, prompt) {
        var selectors = platformSelectors[platform] || platformSelectors.generic;
        var input = await _waitFor(function() { return _findInputBySelectors(selectors); }, 30000, 300);
        var info = platformInfo[platform] || { label: platform };
        if (!input) {
            showToast('未找到 ' + info.label + ' 输入框，请手动粘贴', 3000);
            return false;
        }
        _fillAiInput(input, prompt);
        await _sleep(800);
        if (platform === 'deepseek') {
            // DeepSeek 使用回车发送
            input.focus();
            input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
            input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
            return true;
        }
        var sendButton = await _waitFor(_findAiSendButton, 10000, 250);
        if (sendButton) {
            sendButton.click();
            return true;
        } else {
            showToast('已填入 Prompt，请手动发送', 2000);
            return false;
        }
    }

    function _readPendingTask() {
        if (typeof GM_getValue !== 'function') return null;
        try {
            var raw = GM_getValue(BILI_PENDING_KEY, '');
            if (!raw) return null;
            var task = JSON.parse(raw);
            if (!task || !task.prompt) return null;
            if (Date.now() - Number(task.createdAt || 0) > 300000) {
                GM_setValue(BILI_PENDING_KEY, '');
                return null;
            }
            return task;
        } catch (err) {
            return null;
        }
    }

    function _clearPendingTask() {
        if (typeof GM_setValue === 'function') {
            GM_setValue(BILI_PENDING_KEY, '');
        }
    }

    function _runAiAdapter() {
        var task = _readPendingTask();
        if (!task) return;
        var platform = task.platform || 'doubao';
        var info = platformInfo[platform] || { label: platform };
        showToast('检测到待发送内容，正在填入 ' + info.label + '...', 2000);
        _sendPendingToPlatform(platform, task.prompt).then(function() {
            _clearPendingTask();
        });
    }

    function setupAiReceiver() {
        setTimeout(_runAiAdapter, 1500);
    }

    // 如果在 AI 平台页面，只运行接收端模式
    var _host = location.hostname.toLowerCase();
    var aiHosts = Object.values(platformInfo).map(function(v) { return v.host; });
    if (aiHosts.indexOf(_host) !== -1 || _host === 'doubao.com') {
        setupAiReceiver();
        return;
    }



    let ttPolicy;
    if (window.trustedTypes && window.trustedTypes.createPolicy) {
        try {
            ttPolicy = window.trustedTypes.createPolicy('yt-assistant-' + Math.random().toString(36).substring(2, 9), {
                createHTML: (string) => string
            });
        } catch (e) {
            ttPolicy = { createHTML: (string) => string };
        }
    } else {
        ttPolicy = { createHTML: (string) => string };
    }

    // 简化的元素创建工具
    const elements = {
        createAs(nodeType, config, appendTo) {
            const element = document.createElement(nodeType);
            if (config) {
                Object.entries(config).forEach(([key, value]) => {
                    if (key === 'innerHTML') {
                        element.innerHTML = ttPolicy.createHTML(value);
                    } else {
                        element[key] = value;
                    }
                });
            }
            if (appendTo) appendTo.appendChild(element);
            return element;
        },
        getAs(selector) {
            return document.body.querySelector(selector);
        }
    };

    // 创建预览图片元素
    const preview = elements.createAs("img", {
        id: "preview",
        style: `
            position: absolute;
            z-index: 2000;
            max-width: 60vw;
            max-height: 60vh;
            border: 1px solid #fff;
            border-radius: 4px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            display: none;
            z-index: 1000000000;
        `
    }, document.body);


// 添加点击事件监听器
preview.addEventListener('click', function() {
    this.style.display = 'none';
});

// 点击网页其他区域时关闭缩略图
document.addEventListener('click', function(e) {
    if (e.target.closest('#preview') || e.target.closest('#yt-thumbnail-btn')) {
        return;
    }
    preview.style.display = 'none';
});


    // 添加CSS样式
    const style = elements.createAs('style', {
        textContent: `
            .yt-icon-btn {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 16px;
                height: 16px;
                border-radius: 5px;
                cursor: pointer;
                margin-left: 8px;
                transition: background-color 0.3s, transform 0.2s;
                padding: 2px;
                overflow: visible;
            }

            .yt-icon-btn:hover {
                transform: scale(1.1);
            }

            .yt-icon-btn svg {
                width: 14px;
                height: 14px;
                fill: currentColor;
            }

            .yt-subtitle-btn {
                color: white;
                background-color: #FF0000;
            }

            .yt-subtitle-btn:hover {
                background-color: #CC0000;
                color: white;
            }

            .yt-thumbnail-btn {
                color: white;
                background-color: #FF0000;
            }

            .yt-thumbnail-btn:hover {
                background-color: #CC0000;
                color: white;
            }

            .yt-download-btn {
                color: white;
                background-color: #FF0000;
            }

            .yt-download-btn:hover {
                background-color: #CC0000;
                color: white;
            }

        `
    }, document.head);

    // ffmpeg 命令生成器小书签代码
    const YT_DLP_BM_CODE = `!function(){'use strict';var K='ytdlpgen_bm_state_v1',D={mode:'video',dataAction:'list',quality:'1080',fps:'30',vcodec:'avc1',acodec:'mp4a',audioFormat:'mp3',audioQuality:'0',clipEnable:'off',clipStart:'',clipEnd:'',subs:'off',subLang:'zh-CN,zh-Hans,en.*',subAuto:!1,embedThumb:!1,embedChapters:!1,sponsorblock:'off',cookies:'none',cookieManual:'firefox:D:\\Browser\\RunningCheeseFirefox\\Profiles',cookieFile:'~/Downloads/cookies.txt',noPlaylist:'no',proxy:'\\u5173\\u95ed',proxyCustom:'',fastDownload:'12',liveAction:'now',liveFragments:'3',liveChat:'\\u5173\\u95ed',platform:'windows',output:'%HOMEPATH%/Downloads/Video/%25(title)s [%25(id)s].%25(ext)s',_lastCfg:''},S=function(){var o={};for(var k in D)o[k]=D[k];try{var d=JSON.parse(localStorage.getItem(K));if(d&&'object'==typeof d)for(var k in d)k in D&&(o[k]=d[k])}catch(e){}return o}();(function(){var u=navigator.userAgent,c=/Win/.test(u)?'windows':/Mac/.test(u)?'macos':'linux';if(c!==S.platform&&S.platform===D.platform){S.platform=c;'macos'===c||'linux'===c?S.output='~/Downloads/Video/%(title)s [%(id)s].%(ext)s':S.output='%HOMEPATH%/Downloads/Video/%(title)s [%(id)s].%(ext)s'}})();function src(){var h=location.hostname;if(/(^|\\.)youtube\\.com$/.test(h)){var p=new URLSearchParams(location.search),v=p.get('v');if(v){var u='https://www.youtube.com/watch?v='+v;if('no'===S.noPlaylist){var l=p.get('list');l&&(u+='&list='+l)}return u}return location.origin+location.pathname}if('youtu.be'===h){var i=location.pathname.replace(/^\\//,'').split('/')[0];if(i)return'https://youtu.be/'+i}return location.href}function q(s){return'"'+String(s).replace(/"/g,'\\\\"')+'"'}var s,TIERS=[360,480,720,1080,1440,2160,4320],VKBPS={360:300,480:600,720:1500,1080:3e3,1440:6e3,2160:14e3,4320:3e4};var _sh,_sr;function pt(t){if(null==t)return null;if(!(t=String(t).trim()))return null;if(/^\\d+(\\.\\d+)?$/.test(t))return parseFloat(t);var p=t.split(':').map(Number);return p.some(function(n){return isNaN(n)})?null:p.reduce(function(a,n){return 60*a+n},0)}function hs(b){return b>=1e9?(b/1e9).toFixed(2)+' GB':b>=1e6?Math.round(b/1e6)+' MB':Math.max(1,Math.round(b/1e3))+' KB'}function el(t,a,c){var n=document.createElement(t);if(a)for(var k in a)'text'===k?n.textContent=a[k]:n.setAttribute(k,a[k]);return(c||[]).forEach(function(x){n.appendChild(x)}),n}function sr(l,o,v,oc){var s=el('select');return o.forEach(function(x){var e=el('option',{value:x[0],text:x[1]});x[0]===v&&(e.selected=!0),s.appendChild(e)}),s.addEventListener('change',function(){oc(s.value)}),{row:el('div',{class:'ytdlp-row'},[el('label',{class:'lbl',text:l}),s]),sel:s,full:o.length>6}}function tr(l,v,p,oc){var i=el('input',{type:'text',value:v||'',placeholder:p||''});return i.addEventListener('input',function(){oc(i.value)}),{row:el('div',{class:'ytdlp-row full'},[el('label',{class:'lbl',text:l}),i]),inp:i}}function cr(l,c,oc){var b=el('input',{type:'checkbox'});return b.checked=!!c,b.addEventListener('change',function(){oc(b.checked)}),{row:el('label',{},[b,el('span',{text:l})])}}(s=document.createElement('style')).textContent='#ytdlp-panel{position:fixed;top:12%;right:5%;transform:translateY(16px) scale(.97);z-index:2147483647;width:20%;max-width:50%;min-width:420px;min-height:630px;max-height:80vh;overflow:hidden;display:flex;flex-direction:column;background:#fff;color:#333;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,.25);font:13px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;opacity:0;visibility:hidden;transition:transform .35s cubic-bezier(.16,1,.3,1),opacity .25s ease,visibility 0s linear .25s}#ytdlp-panel.open{transform:translateY(0) scale(1);opacity:1;visibility:visible;transition:transform .35s cubic-bezier(.16,1,.3,1),opacity .25s ease,visibility 0s linear}#ytdlp-header{display:flex;justify-content:space-between;align-items:center;padding:6px 10px;font-size:14px;color:#333;border-bottom:1px solid #eee}#ytdlp-header .ttl{font-weight:bold;color:#333}#ytdlp-header .x{width:20px;height:20px;border-radius:50%;border:none;background:transparent;color:#999;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .2s}#ytdlp-header .x:hover{background:#dadada}#ytdlp-body{padding:16px 18px 6px;overflow-y:auto;display:grid;grid-template-columns:repeat(4,1fr);gap:10px 16px;align-content:start}.ytdlp-sec{grid-column:1/-1;font-size:12px;font-weight:600;letter-spacing:.3px;color:#86868b;text-transform:uppercase;margin:6px 0 2px}.ytdlp-sec:first-child{margin-top:0}.ytdlp-row{display:flex;flex-direction:column;min-width:0}.ytdlp-row.full{grid-column:1/-1}.ytdlp-row>label.lbl{display:block;margin-bottom:4px;font-size:12px;font-weight:500;color:#6e6e73}.ytdlp-row select,.ytdlp-row input[type=text]{width:100%25;box-sizing:border-box;background:#f5f5f7;color:#1d1d1f;border:1px solid #d2d2d7;border-radius:8px;padding:7px 9px;margin-top: 5px;font-size:12.5px;font-family:inherit;outline:none;height:32px;transition:border-color .15s,box-shadow .15s,background .15s}.ytdlp-row select:focus,.ytdlp-row input[type=text]:focus{border-color:#007aff;background:#fff;box-shadow:0 0 0 3px rgba(0,122,255,.12)}.ytdlp-row select:hover,.ytdlp-row input[type=text]:hover{border-color:#b8b8be}.ytdlp-inline{display:flex;gap:6px;align-items:center}.ytdlp-inline>*{flex:1;min-width:0}#ytdlp-body>label{display:flex;align-items:center;gap:8px;padding:4px 9px;border-radius:8px;cursor:pointer;background:#f5f5f7;border:1px solid #d2d2d7;transition:border-color .15s}#ytdlp-body>label:hover{border-color:#b8b8be}#ytdlp-body>label input{-webkit-appearance:none;appearance:none;width:16px;height:16px;flex:none;border-radius:4px;border:1px solid #d2d2d7;background:#fff;cursor:pointer;position:relative;transition:border-color .15s,background .15s}#ytdlp-body>label input:checked{background:#007aff;border-color:#007aff}#ytdlp-body>label input:checked::after{content:"";position:absolute;left:4.5px;top:1px;width:4px;height:8px;border:solid #fff;border-width:0 1.5px 1.5px 0;transform:rotate(45deg)}#ytdlp-body>label span{cursor:pointer;flex:1;font-size:12.5px}.ytdlp-hint{font-size:10.5px;color:#86868b;margin-top:3px;line-height:1.35;grid-column:1/-1}.ytdlp-btn-time{background:transparent;color:#007aff;border:1px solid #d2d2d7;border-radius:6px;padding:0 8px;height:32px;margin-top:5px;box-sizing:border-box;cursor:pointer;font-size:15px;white-space:nowrap;transition:background .15s;display:inline-flex;align-items:center;justify-content:center}.ytdlp-btn-time:hover{background:#f0f0f2}.ytdlp-row input[type=text]{background:#fff}#ytdlp-footer{padding:8px 18px 10px;border-radius:8px;display:flex;flex-direction:column;flex:1;min-height:0;gap:10px}#ytdlp-footer .ytdlp-row{flex:1;min-height:0}#ytdlp-preview{width:100%25;box-sizing:border-box;min-height:130px;flex:1;overflow:auto;background:#f9f9f9;color:#333;border:1px solid #eee;border-radius:8px;padding:10px;margin:4px 0 8px;font:13px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;white-space:pre-wrap;word-break:break-all;outline:none}#ytdlp-preview .tok-prog{color:#e62e4d;font-weight:600}#ytdlp-preview .tok-flag{color:#007aff}#ytdlp-preview .tok-str{color:#bf5b00}#ytdlp-preview .tok-url{color:#388e3c;text-decoration:underline;text-decoration-color:rgba(56,142,60,.35)}#ytdlp-preview .tok-val{color:#7c3aed}.ytdlp-rsh{position:absolute;right:2px;bottom:2px;width:14px;height:14px;cursor:nwse-resize;z-index:10;pointer-events:auto;opacity:0}.ytdlp-disabled{display:none}',_sh=document.createElement('div'),_sr=_sh.attachShadow({mode:'closed'}),_sr.appendChild(s);var ov=null,pr=null,cmd='',lr=[],nlr=[],vr=[],ar=[],subsr=[],dr=[],ndr=[],ap=[],dp=[],lp=[];function sv(){try{localStorage.setItem(K,JSON.stringify(S))}catch(e){}}function rf(){var t=function(){var h,hf,ff,t=[];function a(v){t.push({t:'flag',v:v})}function b(v){t.push({t:'val',v:v})}function c(v){t.push({t:'str',v:q(v)})}t.push({t:'prog',v:'macos'===S.platform?'yt-dlp_macos':'linux'===S.platform?'yt-dlp_linux':'yt-dlp'}),'live'===S.mode?('danmaku_only'===S.liveChat?(a('--skip-download'),a('--write-subs'),a('--sub-langs'),b('live_chat')):('now'===S.liveAction?(a('--no-live-from-start'),a('--live')):'wait'===S.liveAction?(a('--wait-for-video'),b('60-300'),a('--live-from-start')):a('--live-from-start'),a('--embed-thumbnail'),a('--embed-metadata'),a('--merge-output-format'),b('mp4'),'\\u5173\\u95ed'!==S.liveFragments&&(a('--concurrent-fragments'),b(S.liveFragments)),'chat'===S.liveChat&&(a('--write-subs'),a('--sub-langs'),b('live_chat')))):'data'===S.mode?('list'===S.dataAction?a('-F'):(a('--skip-download'),'subs'===S.dataAction?a('--write-subs'):'thumb'===S.dataAction?a('--write-thumbnail'):'desc'===S.dataAction?a('--write-description'):a('--write-comments'))):'audio'===S.mode?(a('-x'),a('--audio-format'),b(S.audioFormat),a('--audio-quality'),b(S.audioQuality)):(a('-f'),c('bestvideo'+(hf='best'!==(h=S.quality)?'[height<='+h+']':'')+(ff='any'!==S.fps?'[fps<='+S.fps+']':'')+('any'!==S.vcodec?'[vcodec^='+S.vcodec+']':'')+'+bestaudio'+('any'!==S.acodec?'[acodec^='+S.acodec+']':'')+'/bestvideo'+hf+ff+'+bestaudio/best'+hf),'avc1'===S.vcodec&&(a('--merge-output-format'),b('mp4')));var st=String(S.clipStart).trim(),en=String(S.clipEnd).trim();return 'data'!==S.mode&&'danmaku_only'!==S.liveChat&&'off'!==S.clipEnable&&(st||en)&&(a('--download-sections'),c('*'+(st||'0')+'-'+(en||'inf')),a('--force-keyframes-at-cuts')),'data'!==S.mode&&'audio'!==S.mode&&'off'!==S.subs&&(a('embed'===S.subs?'--embed-subs':'--write-subs'),a('--sub-langs'),c(S.subLang||'zh-CN,zh-Hans,en.*'),a('--write-auto-subs')),'audio'===S.mode&&(a('--embed-thumbnail'),a('--embed-metadata')),'live'!==S.mode&&'data'!==S.mode&&('sponsor'===S.sponsorblock?(a('--sponsorblock-remove'),b('sponsor')):'all'===S.sponsorblock&&(a('--sponsorblock-remove'),b('all'))),'data'!==S.mode&&'danmaku_only'!==S.liveChat&&('file'===S.cookies?(S.cookieFile&&S.cookieFile.trim()&&(a('--cookies'),c(S.cookieFile.trim()))):'manual'===S.cookies?(S.cookieManual&&S.cookieManual.trim()&&(a('--cookies-from-browser'),c(S.cookieManual.trim()))):'none'!==S.cookies&&(a('--cookies-from-browser'),b(S.cookies))),'live'!==S.mode&&('yes'===S.noPlaylist?a('--yes-playlist'):a('--no-playlist')),'live'!==S.mode&&'data'!==S.mode&&'\\u5173\\u95ed'!==S.fastDownload&&(a('-N'),b(S.fastDownload)),'\\u5173\\u95ed'!==S.proxy&&('custom'!==S.proxy||S.proxyCustom)&&(a('--proxy'),c('custom'===S.proxy?S.proxyCustom:S.proxy)),S.output&&S.output.trim()&&(a('-o'),c(S.output.trim())),t.push({t:'url',v:q(src())}),t}();cmd=t.map(function(x){return x.v}).join(' ');pr&&function(c,t){c.textContent='',t.forEach(function(tk,i){i>0&&c.appendChild(document.createTextNode(' '));var s=document.createElement('span');s.className='tok-'+tk.t,s.textContent=tk.v,c.appendChild(s)})}(pr,t);vr.forEach(function(r){r.classList.toggle('ytdlp-disabled','video'!==S.mode)}),ar.forEach(function(r){r.classList.toggle('ytdlp-disabled','audio'!==S.mode)}),subsr.forEach(function(r){r.classList.toggle('ytdlp-disabled','video'!==S.mode)}),dr.forEach(function(r){r.classList.toggle('ytdlp-disabled','data'!==S.mode)}),ndr.forEach(function(r){r.classList.toggle('ytdlp-disabled','data'===S.mode)}),lr.forEach(function(r){r.classList.toggle('ytdlp-disabled','live'!==S.mode)}),nlr.forEach(function(r){r.classList.toggle('ytdlp-disabled','live'===S.mode)}),ap.forEach(function(r){r.classList.toggle('ytdlp-disabled','audio'!==S.mode)}),dp.forEach(function(r){r.classList.toggle('ytdlp-disabled','data'!==S.mode)}),lp.forEach(function(r){r.classList.toggle('ytdlp-disabled','live'!==S.mode)}),sv()}function cpn(){ov&&(ov.classList.remove('open'),document.removeEventListener('keydown',esk,!0),setTimeout(function(){_sh&&_sh.parentNode&&_sh.parentNode.removeChild(_sh)},300))}function esk(e){if('Escape'===e.key){e.stopPropagation();var t=Date.now();esk._last&&t-esk._last<500?(esk._last=0,cpn()):esk._last=t}}ov=function(){var b=el('div',{id:'ytdlp-body'}),pf=sr('\\u5e73\\u53f0',[['windows','Windows'],['macos','macOS'],['linux','Linux']],S.platform,function(v){S.platform=v,'macos'===v||'linux'===v?(S.output='~/Downloads/Video/%(title)s [%(id)s].%(ext)s',ot.value='~/Downloads/Video/%(title)s [%(id)s].%(ext)s'):(S.output='%HOMEPATH%/Downloads/Video/%(title)s [%(id)s].%(ext)s',ot.value='%HOMEPATH%/Downloads/Video/%(title)s [%(id)s].%(ext)s'),rf()}),mt=el('div',{style:'display:flex;width:100%;background:#e5e5ea;border-radius:8px;padding:2px'});[['video','\\u89c6\\u9891'],['audio','\\u97f3\\u9891'],['data','\\u6570\\u636e'],['live','\\u76f4\\u64ad']].forEach(function(x){var tb=el('div',{text:x[1],style:'flex:1;text-align:center;padding:8px 4px;cursor:pointer;font-size:12.5px;border-radius:6px;color:'+(x[0]===S.mode?'#1d1d1f':'#6e6e73')+';background:'+(x[0]===S.mode?'#fff':'transparent')+';box-shadow:'+(x[0]===S.mode?'0 1px 3px rgba(0,0,0,0.12)':'none')+';white-space:nowrap;transition:all .2s'});tb.dataset.mode=x[0];tb.addEventListener('click',function(){mt.querySelectorAll('[data-mode]').forEach(function(t){t.style.background='transparent';t.style.boxShadow='none';t.style.color='#6e6e73'});tb.style.background='#fff';tb.style.boxShadow='0 1px 3px rgba(0,0,0,0.12)';tb.style.color='#1d1d1f';S.mode=tb.dataset.mode;rf()});mt.appendChild(tb)});b.insertBefore(el('div',{class:'ytdlp-row full'},[mt]),b.firstChild);var la=sr('\\u76f4\\u64ad',[['now','\\u5f53\\u524d\\u65f6\\u95f4\\u5f00\\u59cb'],['fromstart','\\u4ece\\u5934\\u5f00\\u59cb\\u5f55\\u5236'],['wait','\\u8e72\\u5b88\\u5f00\\u64ad\\u5f55\\u5236']],S.liveAction,function(v){S.liveAction=v,rf()});b.appendChild(la.row),lr.push(la.row);var lc=sr('\\u591a\\u7ebf\\u7a0b\\u4e0b\\u8f7d',[['\\u5173\\u95ed','\\u5173\\u95ed'],['2','2'],['3','3'],['4','4'],['5','5'],['6','6']],S.liveFragments,function(v){S.liveFragments=v,rf()});b.appendChild(lc.row),lr.push(lc.row);var lh=sr('\\u4e0b\\u8f7d\\u5f39\\u5e55',[['\\u5173\\u95ed','\\u5173\\u95ed'],['chat','\\u540c\\u65f6\\u4e0b\\u8f7d\\u5f39\\u5e55'],['danmaku_only','\\u4ec5\\u4e0b\\u8f7d\\u5f39\\u5e55']],S.liveChat,function(v){S.liveChat=v,rf()});b.appendChild(lh.row),lr.push(lh.row);var da=sr('\\u6570\\u636e',[['list','\\u67e5\\u770b\\u53ef\\u7528\\u4e0b\\u8f7d\\u8d44\\u6e90'],['subs','\\u4ec5\\u4e0b\\u8f7d\\u5b57\\u5e55'],['thumb','\\u4ec5\\u4e0b\\u8f7d\\u5c01\\u9762'],['desc','\\u4ec5\\u4e0b\\u8f7d\\u7b80\\u4ecb'],['comments','\\u4ec5\\u4e0b\\u8f7d\\u8bc4\\u8bba']],S.dataAction,function(v){S.dataAction=v,rf()});b.appendChild(da.row),dr.push(da.row);var ql=sr('\\u5206\\u8fa8\\u7387',[['best','\\u6700\\u4f73'],['4320','8K'],['2160','4K'],['1440','2K'],['1080','1080p'],['720','720p'],['480','480p'],['360','360p']],S.quality,function(v){S.quality=v,rf()});b.appendChild(ql.row),vr.push(ql.row);var fp=sr('\\u5e27\\u7387',[['any','\\u4e0d\\u9650'],['30','\\u226430'],['60','\\u226460']],S.fps,function(v){S.fps=v,rf()});b.appendChild(fp.row),vr.push(fp.row);var vc=sr('\\u89c6\\u9891\\u7f16\\u7801',[['avc1','H.264'],['vp9','VP9'],['av01','AV1'],['any','\\u4e0d\\u9650']],S.vcodec,function(v){S.vcodec=v,rf()});b.appendChild(vc.row),vr.push(vc.row);var ac=sr('\\u97f3\\u9891\\u7f16\\u7801',[['mp4a','AAC'],['opus','Opus'],['any','\\u4e0d\\u9650']],S.acodec,function(v){S.acodec=v,rf()});b.appendChild(ac.row),vr.push(ac.row);var af=sr('\\u97f3\\u9891\\u683c\\u5f0f',[['mp3','MP3'],['m4a','M4A'],['opus','Opus'],['wav','WAV'],['flac','FLAC']],S.audioFormat,function(v){S.audioFormat=v,rf()});b.appendChild(af.row),ar.push(af.row);var aq=sr('\\u97f3\\u8d28',[['0','\\u6700\\u4f73'],['320K','320k'],['256K','256k'],['192K','192k'],['128K','128k']],S.audioQuality,function(v){S.audioQuality=v,rf()});b.appendChild(aq.row),ar.push(aq.row);var ss=sr('\\u5b57\\u5e55',[['off','\\u5173\\u95ed'],['embed','\\u5185\\u5d4c\\u5b57\\u5e55'],['file','\\u5916\\u6302\\u5b57\\u5e55']],S.subs,function(v){S.subs=v,rf()});b.appendChild(ss.row),subsr.push(ss.row);var px=sr('\\u4ee3\\u7406',[['\\u5173\\u95ed','\\u5173\\u95ed'],['127.0.0.1:1080','127.0.0.1:1080'],['127.0.0.1:10808','127.0.0.1:10808'],['127.0.0.1:7890','127.0.0.1:7890'],['custom','\\u81ea\\u5b9a\\u4e49']],S.proxy,function(v){if(v==='custom'){var val=prompt('\\u8f93\\u5165\\u4ee3\\u7406\\u5730\\u5740:',S.proxyCustom||'');if(val){S.proxyCustom=val;S.proxy='custom'}else{S.proxy='\\u5173\\u95ed';px.sel.value='\\u5173\\u95ed'}}else{S.proxy=v}rf()});b.appendChild(px.row),ndr.push(px.row),nlr.push(px.row);var fd=sr('\\u591a\\u7ebf\\u7a0b\\u4e0b\\u8f7d',[['\\u5173\\u95ed','\\u5173\\u95ed'],['4','4'],['8','8'],['12','12'],['16','16'],['24','24']],S.fastDownload,function(v){S.fastDownload=v,rf()});b.appendChild(fd.row),ndr.push(fd.row),nlr.push(fd.row);var np=sr('\\u5217\\u8868\\u6279\\u91cf\\u4e0b\\u8f7d',[['no','\\u5173\\u95ed'],['yes','\\u5f00\\u542f']],S.noPlaylist,function(v){S.noPlaylist=v,rf()});b.appendChild(np.row),nlr.push(np.row);var sp=sr('\\u5e7f\\u544a\\u8fc7\\u6ee4',[['off','\\u5173\\u95ed'],['sponsor','\\u8fc7\\u6ee4\\u8d5e\\u52a9\\u5e7f\\u544a'],['all','\\u8fc7\\u6ee4\\u6240\\u6709\\u5e7f\\u544a']],S.sponsorblock,function(v){S.sponsorblock=v,rf()});b.appendChild(sp.row),ndr.push(sp.row),nlr.push(sp.row);var ce=sr('\\u89c6\\u9891\\u88c1\\u526a',[['off','\\u5173\\u95ed'],['on','\\u5f00\\u542f']],S.clipEnable,function(v){S.clipEnable=v,cl.style.display='on'===v?'':'none',rf()});b.appendChild(ce.row),ndr.push(ce.row);var hv=!!document.querySelector('video'),si=el('input',{type:'text',value:S.clipStart,placeholder:'\\u65f6:\\u5206:\\u79d2'});si.addEventListener('input',function(){S.clipStart=si.value,rf()});var ei=el('input',{type:'text',value:S.clipEnd,placeholder:'\\u65f6:\\u5206:\\u79d2'});function cts(){var v=document.querySelector('video');if(!v||isNaN(v.currentTime))return'';var t=Math.floor(v.currentTime);return String(Math.floor(t/3600)).padStart(2,'0')+':'+String(Math.floor(t%253600/60)).padStart(2,'0')+':'+String(t%2560).padStart(2,'0')}ei.addEventListener('input',function(){S.clipEnd=ei.value,rf()});var sg=el('div',{class:'ytdlp-row'},[el('label',{class:'lbl',text:'\\u526a\\u88c1\\u5f00\\u59cb'}),el('div',{class:'ytdlp-inline',style:'gap:16px'},[si])]),eg=el('div',{class:'ytdlp-row'},[el('label',{class:'lbl',text:'\\u526a\\u88c1\\u7ed3\\u675f'}),el('div',{class:'ytdlp-inline',style:'gap:16px'},[ei])]);if(hv){var sB=el('button',{class:'ytdlp-btn-time',text:'\\u23f1'});sB.title='\\u4f7f\\u7528\\u64ad\\u653e\\u5668\\u65f6\\u95f4',sB.addEventListener('click',function(){si.value=cts(),S.clipStart=si.value,rf()});var eB=el('button',{class:'ytdlp-btn-time',text:'\\u23f1'});eB.title='\\u4f7f\\u7528\\u64ad\\u653e\\u5668\\u65f6\\u95f4',eB.addEventListener('click',function(){ei.value=cts(),S.clipEnd=ei.value,rf()}),sg.querySelector('.ytdlp-inline').appendChild(sB),eg.querySelector('.ytdlp-inline').appendChild(eB)}var cl=el('div',{class:'ytdlp-row full',style:'on'===S.clipEnable?'':'display:none'},[el('div',{class:'ytdlp-inline',style:'gap:16px'},[sg,eg])]);b.appendChild(cl),ndr.push(cl);!function(){var d=el('div',{class:'ytdlp-row full'});d.appendChild(el('label',{class:'lbl',text:'\\xa0'}));var i=el('input',{type:'text',disabled:true});i.style.visibility='hidden';d.appendChild(i);var aph=d;b.appendChild(aph);ap=[aph];var dph=el('div',{class:'ytdlp-row full'});dph.appendChild(el('label',{class:'lbl',text:'\\xa0'}));var ip=el('input',{type:'text',disabled:true});ip.style.visibility='hidden';dph.appendChild(ip);b.appendChild(dph);dp=[dph];var lph1=el('div',{class:'ytdlp-row full'});lph1.appendChild(el('label',{class:'lbl',text:'\\xa0'}));var ip1=el('input',{type:'text',disabled:true});ip1.style.visibility='hidden';lph1.appendChild(ip1);b.appendChild(lph1);lp=[lph1];var lph2=el('div',{class:'ytdlp-row full'});lph2.appendChild(el('label',{class:'lbl',text:'\\xa0'}));var ip2=el('input',{type:'text',disabled:true});ip2.style.visibility='hidden';lph2.appendChild(ip2);b.appendChild(lph2);lp.push(lph2)}();var ckSel=el('select');[['none','\\u5173\\u95ed'],['firefox','Firefox'],['chrome','Chrome'],['edge','Edge'],['safari','Safari'],['file','\\u4ece\\u6587\\u4ef6\\u8bfb\\u53d6'],['manual','\\u4ece\\u6d4f\\u89c8\\u5668\\u8bfb\\u53d6']].forEach(function(x){var e=el('option',{value:x[0],text:x[1]});x[0]===S.cookies&&(e.selected=!0),ckSel.appendChild(e)});var ckInp=el('input',{type:'text',value:'file'===S.cookies?S.cookieFile||D.cookieFile||'':'manual'===S.cookies?S.cookieManual||D.cookieManual||'':'',placeholder:'\\u8def\\u5f84\\u6216 Cookie \\u5b57\\u7b26\\u4e32'});ckInp.disabled='file'!==S.cookies&&'manual'!==S.cookies;ckInp.style.background='file'!==S.cookies&&'manual'!==S.cookies?'#f5f5f7':'#fff';ckSel.addEventListener('change',function(){S.cookies=ckSel.value,ckInp.disabled='file'!==ckSel.value&&'manual'!==ckSel.value,ckInp.style.background='file'!==ckSel.value&&'manual'!==ckSel.value?'#f5f5f7':'#fff','file'===ckSel.value?ckInp.value=S.cookieFile||D.cookieFile:'manual'===ckSel.value?ckInp.value=S.cookieManual||D.cookieManual:ckInp.value='',rf()});ckInp.addEventListener('input',function(){S.cookieManual=ckInp.value,S.cookieFile=ckInp.value,rf()});var rstBtn=el('span',{style:'cursor:pointer;font-size:12px;color:#007aff;',text:'\\u6062\\u590d\\u9ed8\\u8ba4'});rstBtn.addEventListener('click',function(){for(var k in D)S[k]=D[k];(function(){var u=navigator.userAgent,c=/Win/.test(u)?'windows':/Mac/.test(u)?'macos':'linux';'windows'!==c&&(S.platform=c,'macos'===c||'linux'===c?S.output='~/Downloads/Video/%(title)s [%(id)s].%(ext)s':S.output='%HOMEPATH%/Downloads/Video/%(title)s [%(id)s].%(ext)s')})();cs.value='';lastCfg=null;mt.querySelectorAll('[data-mode]').forEach(function(t){t.style.background=t.dataset.mode===S.mode?'#fff':'transparent';t.style.boxShadow=t.dataset.mode===S.mode?'0 1px 3px rgba(0,0,0,0.12)':'none';t.style.color=t.dataset.mode===S.mode?'#1d1d1f':'#6e6e73'});la.sel.value=S.liveAction;lc.sel.value=S.liveFragments;lh.sel.value=S.liveChat;da.sel.value=S.dataAction;ql.sel.value=S.quality;fp.sel.value=S.fps;vc.sel.value=S.vcodec;ac.sel.value=S.acodec;af.sel.value=S.audioFormat;aq.sel.value=S.audioQuality;ss.sel.value=S.subs;px.sel.value=S.proxy;fd.sel.value=S.fastDownload;np.sel.value=S.noPlaylist;sp.sel.value=S.sponsorblock;ce.sel.value=S.clipEnable;pf.sel.value=S.platform;ckSel.value=S.cookies;si.value=S.clipStart;ei.value=S.clipEnd;ckInp.value='';ckInp.disabled=!0;ckInp.style.background='#f5f5f7';ot.value=S.output;cl.style.display='none';sv();rf()});var ckRow=el('div',{style:'display:grid;grid-template-columns:repeat(4,1fr);gap:0 16px;grid-column:1/-1'},[el('div',{style:'display:flex;align-items:center;justify-content:space-between;grid-column:1/-1;margin-bottom:4px'},[el('span',{style:'font-size:12px;font-weight:500;color:#6e6e73',text:'Cookie'}),rstBtn]),el('div',{class:'ytdlp-row',style:'grid-column:1'},[ckSel]),el('div',{class:'ytdlp-row',style:'grid-column:2/5'},[ckInp])]);var ot=el('input',{type:'text',value:S.output||'',placeholder:D.output});ot.addEventListener('input',function(){S.output=ot.value,rf()});var cs=el('select',{style:'-webkit-appearance:none;-moz-appearance:none;appearance:none;border:none;background:transparent;color:#007aff;text-decoration:underline;font-size:12px;cursor:pointer;outline:none;padding:0;direction:rtl'});cs.appendChild(el('option',{value:'',text:'\\u9ed8\\u8ba4\\u914d\\u7f6e',disabled:true,selected:true}));for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);0===k.indexOf('ytdlp_cfg_')&&cs.appendChild(el('option',{value:k,text:k.replace('ytdlp_cfg_','')}))}cs.appendChild(el('option',{value:'save',text:'\\u4fdd\\u5b58\\u5f53\\u524d\\u914d\\u7f6e'}));cs.appendChild(el('option',{value:'delete',text:'\\u5220\\u9664\\u5f53\\u524d\\u914d\\u7f6e'}));var CD={video:{mode:'video',quality:'1080',fps:'30',vcodec:'avc1',acodec:'mp4a',subs:'off',sponsorblock:'off',fastDownload:'16'},audio:{mode:'audio',audioFormat:'mp3',audioQuality:'0'},data:{mode:'data',dataAction:'list'},live:{mode:'live',liveAction:'now',liveFragments:'3',liveChat:'\\u5173\\u95ed'}},lastCfg=null;cs.addEventListener('change',function(){var v=cs.value;if(!v)return;if('save'===v){var n=prompt('\\u8f93\\u5165\\u914d\\u7f6e\\u540d\\u79f0:');if(n)try{localStorage.setItem('ytdlp_cfg_'+n,JSON.stringify(S)),cs.appendChild(el('option',{value:'ytdlp_cfg_'+n,text:n}))}catch(e){}cs.value='';return}if('delete'===v){if(lastCfg){try{localStorage.removeItem(lastCfg)}catch(e){}for(var i=0;i<cs.options.length;i++)cs.options[i].value===lastCfg&&cs.removeChild(cs.options[i])}cs.value='';return}0===v.indexOf('ytdlp_cfg_')&&(lastCfg=v,S._lastCfg=v);if(0===v.indexOf('ytdlp_cfg_')){try{var d=JSON.parse(localStorage.getItem(v));if(d)for(var k in D)k in d&&(S[k]=d[k]);S._lastCfg=v;cs.value=v}catch(e){}}else if('default'===v){for(var k in D)S[k]=D[k]}else{for(var k in D)S[k]=D[k];var d=CD[v];if(d)for(var k in d)S[k]=d[k]}mt.querySelectorAll('[data-mode]').forEach(function(t){t.style.background=t.dataset.mode===S.mode?'#fff':'transparent';t.style.boxShadow=t.dataset.mode===S.mode?'0 1px 3px rgba(0,0,0,0.12)':'none';t.style.color=t.dataset.mode===S.mode?'#1d1d1f':'#6e6e73'});la.sel.value=S.liveAction;lc.sel.value=S.liveFragments;lh.sel.value=S.liveChat;da.sel.value=S.dataAction;ql.sel.value=S.quality;fp.sel.value=S.fps;vc.sel.value=S.vcodec;ac.sel.value=S.acodec;af.sel.value=S.audioFormat;aq.sel.value=S.audioQuality;ss.sel.value=S.subs;px.sel.value=S.proxy;fd.sel.value=S.fastDownload;np.sel.value=S.noPlaylist;sp.sel.value=S.sponsorblock;ce.sel.value=S.clipEnable;pf.sel.value=S.platform;ckSel.value=S.cookies;si.value=S.clipStart;ei.value=S.clipEnd;'file'===S.cookies?ckInp.value=S.cookieFile||D.cookieFile:'manual'===S.cookies?ckInp.value=S.cookieManual||D.cookieManual:(ckInp.value='');ckInp.disabled='file'!==S.cookies&&'manual'!==S.cookies;ckInp.style.background='file'!==S.cookies&&'manual'!==S.cookies?'#f5f5f7':'#fff';ot.value=S.output;cl.style.display='on'===S.clipEnable?'':'none';sv();rf()});if(S._lastCfg){for(var i=0;i<cs.options.length;i++){if(cs.options[i].value===S._lastCfg){cs.value=S._lastCfg;cs.dispatchEvent(new Event('change'));break}}}var pfRow=el('div',{style:'display:grid;grid-template-columns:repeat(4,1fr);gap:0 16px;grid-column:1/-1'},[el('div',{style:'display:flex;align-items:center;justify-content:space-between;grid-column:1/-1;margin-bottom:4px'},[el('span',{style:'font-size:12px;font-weight:500;color:#6e6e73',text:'\\u4fdd\\u5b58\\u4f4d\\u7f6e'}),cs]),el('div',{class:'ytdlp-row',style:'grid-column:1'},[pf.sel]),el('div',{class:'ytdlp-row',style:'grid-column:2/5'},[ot])]);var xb=el('button',{class:'x',text:'\\u2715',title:'\\u5173\\u95ed (Esc)'}),hd=el('div',{id:'ytdlp-header'},[el('div',{class:'ttl',text:'\\u25bc yt-dlp \\u547d\\u4ee4\\u751f\\u6210\\u5668'}),xb]);pr=el('pre',{id:'ytdlp-preview'});var ct=el('span',{style:'font-size:12px;color:#6e6e73;margin-left:auto;transition:color .3s',text:'\\u70b9\\u51fb\\u590d\\u5236'}),p,ox,oy,dx,dy,dg,rh,rg,ft=el('div',{id:'ytdlp-footer'},[ckRow,pfRow,el('div',{class:'ytdlp-row'},[el('label',{class:'lbl',style:'display:flex;align-items:center'},[el('span',{text:'\\u547d\\u4ee4\\u9884\\u89c8'}),function(){var _a=el('a',{href:'https://www.runningcheese.com/onekey-video-download',target:'_blank',style:'color:#6e6e73;text-decoration:none;font-size:12px;cursor:pointer;transition:color .3s',text:'\\uff08\\u4f7f\\u7528\\u8bf4\\u660e\\uff09'});_a.addEventListener('mouseenter',function(){this.style.color='#007aff'});_a.addEventListener('mouseleave',function(){this.style.color='#6e6e73'});return _a}(),ct]),pr])]),pn=el('div',{id:'ytdlp-panel'},[hd,b,ft,el('div',{class:'ytdlp-rsh'})]);return pr.addEventListener('click',function(){!function(t){try{if(navigator.clipboard&&navigator.clipboard.writeText)return navigator.clipboard.writeText(t)}catch(e){}try{var a=document.createElement('textarea');a.value=t,a.style.cssText='position:fixed;opacity:0;left:-9999px',document.body.appendChild(a),a.select(),document.execCommand('copy'),document.body.removeChild(a)}catch(e){}}(cmd);var _b=pr.style.background;pr.style.background='#e6f7ff';ct.textContent='\\u5df2\\u590d\\u5236!';ct.style.color='#1a73e8';setTimeout(function(){pr.style.background=_b;setTimeout(function(){ct.textContent='\\u70b9\\u51fb\\u590d\\u5236';ct.style.color='#6e6e73'},1000)},300)}),xb.addEventListener('click',cpn),p=pn,ox=0,oy=0,dx=0,dy=0,dg=!1,hd.addEventListener('mousedown',function(e){if(!e.target.closest('.x')){dg=!0;var r=p.getBoundingClientRect();ox=e.clientX-r.left,oy=e.clientY-r.top,p.style.transition='none',p.style.position='fixed',p.style.margin='0',p.style.left=r.left+'px',p.style.top=r.top+'px',p.style.transform='none',e.preventDefault()}}),window.addEventListener('mousemove',function(e){dg&&(dx=e.clientX-ox,dy=e.clientY-oy,p.style.left=Math.max(8,Math.min(dx,window.innerWidth-p.offsetWidth-8))+'px',p.style.top=Math.max(8,Math.min(dy,window.innerHeight-40))+'px')}),window.addEventListener('mouseup',function(){dg=!1}),rh=pn.querySelector('.ytdlp-rsh'),rg=!1,rh.addEventListener('mousedown',function(e){rg=!0;var r=pn.getBoundingClientRect();pn.style.transition='none';if('none'!==pn.style.transform){pn.style.position='fixed';pn.style.margin='0';pn.style.left=r.left+'px';pn.style.top=r.top+'px';pn.style.transform='none'}e.stopPropagation();e.preventDefault()}),window.addEventListener('mousemove',function(e){if(rg){var r=pn.getBoundingClientRect(),nw=Math.max(420,Math.min(e.clientX-r.left,window.innerWidth-r.left-8)),nh=Math.max(360,Math.min(e.clientY-r.top,window.innerHeight-40));pn.style.width=nw+'px';pn.style.height=nh+'px'}}),window.addEventListener('mouseup',function(){rg=!1}),pn}(),document.addEventListener('keydown',esk,!0),document.body.appendChild(_sh),_sr.appendChild(ov),rf(),ov.offsetWidth,ov.classList.add('open'),function(){var _ul=location.href;setInterval(function(){location.href!==_ul&&(_ul=location.href,rf())},500)}()}();`;

    function runYtDlpBm() {
        try {
            GM_addElement(document.body, 'script', { textContent: YT_DLP_BM_CODE });
        } catch(e) {
            console.error('[U2B] yt-dlp-bm error:', e);
            alert('[U2B] error:\n' + e.message);
        }
    }

    // YouTube缩略图和字幕查看器主体
    const youtubeViewer = {
        videoId: null,
        buttonAdded: false,
        buttonCheckInterval: null,

        // 获取当前视频ID
        getVideoId() {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get('v');
        },

        // 检查是否在视频页面
        isVideoPage() {
            return window.location.pathname.includes('/watch');
        },

        // 获取YouTube缩略图URL
        getThumbnailUrl() {
            const videoId = this.getVideoId();
            if (!videoId) return null;

            // 返回最高质量的缩略图
            return `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
        },

        // ===== 字幕功能 =====

        // ---------- 状态 ----------
        _subState: {
            allSubtitles: [],
            currentSubtitleData: null,
            selectedSubtitleId: null,

            isLoading: false,
            currentVideoKey: null,
        },

        _trustedPolicy: null,

        // ---------- 工具函数 ----------
        _safeHtml(element, html) {
            if (this._trustedPolicy) {
                element.innerHTML = this._trustedPolicy.createHTML(html);
            } else {
                element.innerHTML = html;
            }
        },

        _escHtml(str) {
            return String(str == null ? '' : str)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        },


        // ---------- 轨道获取（从 movie_player / window / InnerTube）----------
        _getCaptionsFromMoviePlayer() {
            try {
                const doc = (typeof unsafeWindow !== 'undefined' && unsafeWindow.document) || document;
                const el = doc.getElementById('movie_player');
                if (el && typeof el.getAudioTrack === 'function') {
                    const at = el.getAudioTrack();
                    const tracks = at && at.captionTracks;
                    if (tracks && tracks.length) {
                        console.log('[U2B] 通道0a: movie_player.getAudioTrack', tracks.length, '轨道');
                        return tracks.map((t, i) => ({
                            id: i, lan: t.languageCode || t.lang_code || 'unknown',
                            lan_doc: (t.name && t.name.simpleText) || t.displayName || t.languageName || t.languageCode || 'Unknown',
                            subtitle_url: t.url || t.baseUrl, isAuto: t.kind === 'asr', body: null
                        }));
                    }
                }
            } catch (e) { console.log('[U2B] 通道0a 错误:', e); }
            try {
                const doc = (typeof unsafeWindow !== 'undefined' && unsafeWindow.document) || document;
                const el = doc.getElementById('movie_player');
                if (el && typeof el.getPlayerResponse === 'function') {
                    const pr = el.getPlayerResponse();
                    const ct = pr && pr.captions && pr.captions.playerCaptionsTracklistRenderer && pr.captions.playerCaptionsTracklistRenderer.captionTracks;
                    if (ct && ct.length) {
                        console.log('[U2B] 通道0b: getPlayerResponse', ct.length, '轨道');
                        return ct.map((t, i) => ({
                            id: i, lan: t.languageCode || t.lang_code || 'unknown',
                            lan_doc: (t.name && t.name.simpleText) || t.displayName || t.languageName || t.languageCode || 'Unknown',
                            subtitle_url: t.url || t.baseUrl, isAuto: t.kind === 'asr', body: null
                        }));
                    }
                }
            } catch (e) { console.log('[U2B] 通道0b 错误:', e); }
            return [];
        },

        _getTracksFromWindow() {
            try {
                const pr = (typeof unsafeWindow !== 'undefined' && unsafeWindow.ytInitialPlayerResponse) || window.ytInitialPlayerResponse;
                if (!pr) {
                    for (const s of document.querySelectorAll('script')) {
                        const text = s.textContent || '';
                        if (text.includes('ytInitialPlayerResponse')) {
                            const m = text.match(/ytInitialPlayerResponse\s*=\s*(\{.+?\});/);
                            if (m) { try { return JSON.parse(m[1]); } catch(e) {} }
                        }
                    }
                }
                if (pr) {
                    const ct = pr.captions && pr.captions.playerCaptionsTracklistRenderer && pr.captions.playerCaptionsTracklistRenderer.captionTracks;
                    if (ct && ct.length) {
                        console.log('[U2B] 通道A: ytInitialPlayerResponse', ct.length, '轨道');
                        return ct.map((t, i) => ({
                            id: i, lan: t.languageCode || t.lang_code || 'unknown',
                            lan_doc: (t.name && t.name.simpleText) || t.displayName || t.languageName || t.languageCode || 'Unknown',
                            subtitle_url: t.url || t.baseUrl, isAuto: t.kind === 'asr', body: null
                        }));
                    }
                }
            } catch (e) { console.log('[U2B] 通道A 错误:', e); }
            return [];
        },

        async _fetchTracksFromInnertube(videoId) {
            try {
                let apiKey = '';
                try {
                    const cfg = (typeof unsafeWindow !== 'undefined' && unsafeWindow.ytcfg);
                    if (cfg && typeof cfg.get === 'function') apiKey = cfg.get('INNERTUBE_API_KEY');
                } catch(e) {}
                if (!apiKey) {
                    for (const s of document.querySelectorAll('script')) {
                        const m = (s.textContent || '').match(/"INNERTUBE_API_KEY":"([^"]+)"/);
                        if (m) { apiKey = m[1]; break; }
                    }
                }
                const keyParam = apiKey ? `key=${encodeURIComponent(apiKey)}&` : '';
                const body = {
                    context: { client: { clientName: 'ANDROID', clientVersion: '20.10.38', hl: 'en', gl: 'US' } },
                    videoId
                };
                const resp = await fetch(`https://www.youtube.com/youtubei/v1/player?${keyParam}prettyPrint=false`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-YouTube-Client-Name': '3',
                        'X-YouTube-Client-Version': '20.10.38'
                    },
                    body: JSON.stringify(body),
                    credentials: 'omit'
                });
                if (!resp.ok) return [];
                const data = await resp.json();
                const ct = data.captions && data.captions.playerCaptionsTracklistRenderer && data.captions.playerCaptionsTracklistRenderer.captionTracks;
                if (ct && ct.length) {
                    console.log('[U2B] 通道C: InnerTube ANDROID', ct.length, '轨道');
                    return ct.map((t, i) => ({
                        id: i, lan: t.languageCode || t.lang_code || 'unknown',
                        lan_doc: (t.name && t.name.simpleText) || t.displayName || t.languageName || t.languageCode || 'Unknown',
                        subtitle_url: t.url || t.baseUrl, isAuto: t.kind === 'asr', body: null
                    }));
                }
            } catch (e) { console.log('[U2B] 通道C 错误:', e); }
            return [];
        },

        async _fetchCaptionTracks() {
            const videoId = this.getVideoId();
            if (!videoId) return [];
            let tracks = this._getCaptionsFromMoviePlayer();
            if (tracks.length) return tracks;
            tracks = this._getTracksFromWindow();
            if (tracks.length) return tracks;
            tracks = await this._fetchTracksFromInnertube(videoId);
            return tracks;
        },

        // ---------- 字幕内容获取（含 PoToken 处理）----------
        _sanitizeCaptionUrl(url) {
            if (!url) return url;
            return url
                .replace(/([?&])exp=xpe(&|$)/g, (_, p1, p2) => p2 ? p1 : '')
                .replace(/([?&])potc=\d+(&|$)/g, (_, p1, p2) => p2 ? p1 : '')
                .replace(/([?&])pot=[^&]*(&|$)/g, (_, p1, p2) => p2 ? p1 : '')
                .replace(/[?&]$/, '');
        },

        async _fetchSubtitleContent(baseUrl) {
            if (!baseUrl || baseUrl.length < 10) return [];
            const fmtOrder = ['json3', 'srv3', 'vtt', 'ttml'];
            const variants = (() => {
                const sani = this._sanitizeCaptionUrl(baseUrl);
                return sani && sani !== baseUrl ? [baseUrl, sani] : [baseUrl];
            })();
            for (const variant of variants) {
                for (const fmt of fmtOrder) {
                    try {
                        let url;
                        if (variant.includes('fmt=')) {
                            url = variant.replace(/fmt=[^&]+/, `fmt=${fmt}`);
                        } else {
                            url = variant + `&fmt=${fmt}`;
                        }
                        const resp = await fetch(url, { credentials: 'include' });
                        if (!resp.ok) continue;
                        const text = await resp.text();
                        if (!text || text.length === 0) continue;
                        const result = this._parseSubtitle(text, fmt);
                        if (result && result.length > 0) return result;
                    } catch (e) { console.log('[U2B]', fmt, '失败:', e.message); }
                }
            }
            // 兜底：通过 InnerTube ANDROID 重取
            const videoId = this.getVideoId();
            if (videoId) {
                const fresh = await this._fetchTracksFromInnertube(videoId);
                if (fresh.length) {
                    const langMatch = baseUrl.match(/[?&]lang=([^&]+)/);
                    const wanted = langMatch ? decodeURIComponent(langMatch[1]) : null;
                    const pick = (wanted && fresh.find(t => t.lan === wanted || t.lan.startsWith(wanted.split('-')[0]))) || fresh[0];
                    if (pick && pick.subtitle_url && pick.subtitle_url !== baseUrl) {
                        for (const fmt of fmtOrder) {
                            try {
                                let url;
                                if (pick.subtitle_url.includes('fmt=')) {
                                    url = pick.subtitle_url.replace(/fmt=[^&]+/, `fmt=${fmt}`);
                                } else {
                                    url = pick.subtitle_url + `&fmt=${fmt}`;
                                }
                                const resp = await fetch(url, { credentials: 'include' });
                                if (!resp.ok) continue;
                                const text = await resp.text();
                                if (!text || text.length === 0) continue;
                                const result = this._parseSubtitle(text, fmt);
                                if (result && result.length > 0) return result;
                            } catch (e) {}
                        }
                    }
                }
            }
            return [];
        },

        _parseSubtitle(text, fmt) {
            switch (fmt) {
                case 'vtt': return this._parseVtt(text);
                case 'ttml': return this._parseTtml(text);
                case 'srv3':
                case 'json3': return this._parseJson3(text);
                default: return [];
            }
        },

        _parseVtt(vttText) {
            const subtitles = [];
            const lines = vttText.split('\n');
            let currentSub = null;
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i].trim();
                if (!line || line.startsWith('WEBVTT') || line.startsWith('NOTE') || line.startsWith('Kind:') || line.startsWith('Language:')) continue;
                const timeMatch = line.match(/(\d{2}:\d{2}:\d{2}[\.,]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[\.,]\d{3})/);
                if (timeMatch) {
                    if (currentSub && currentSub.content) subtitles.push(currentSub);
                    currentSub = { from: this._parseVttTime(timeMatch[1]), to: this._parseVttTime(timeMatch[2]), content: '' };
                    continue;
                }
                if (/^\d+$/.test(line)) continue;
                if (currentSub) {
                    if (currentSub.content) currentSub.content += ' ' + line;
                    else currentSub.content = line;
                }
            }
            if (currentSub && currentSub.content) subtitles.push(currentSub);
            return subtitles.map(s => ({ ...s, content: s.content.replace(/<[^>]+>/g, '').trim() })).filter(s => s.content.length > 0);
        },

        _parseVttTime(timeStr) {
            const parts = timeStr.replace(',', '.').split(':');
            return parseInt(parts[0]) * 3600 + parseInt(parts[1]) * 60 + parseFloat(parts[2]);
        },

        _parseTtml(ttmlText) {
            try {
                const parser = new DOMParser();
                const doc = parser.parseFromString(ttmlText, 'text/xml');
                const paragraphs = doc.querySelectorAll('p[begin][end]');
                const subtitles = [];
                paragraphs.forEach(p => {
                    const begin = this._parseTtmlTime(p.getAttribute('begin'));
                    const end = this._parseTtmlTime(p.getAttribute('end'));
                    const content = p.textContent.trim();
                    if (content) subtitles.push({ from: begin, to: end, content });
                });
                return subtitles;
            } catch(e) { return []; }
        },

        _parseTtmlTime(timeStr) {
            if (!timeStr) return 0;
            if (timeStr.endsWith('ms')) return parseFloat(timeStr) / 1000;
            if (timeStr.endsWith('s')) return parseFloat(timeStr);
            const parts = timeStr.split(':');
            if (parts.length === 3) return parseInt(parts[0]) * 3600 + parseInt(parts[1]) * 60 + parseFloat(parts[2]);
            return parseFloat(timeStr) || 0;
        },

        _parseJson3(jsonText) {
            try {
                const data = JSON.parse(jsonText);
                if (!data.events) return [];
                return data.events
                    .filter(e => e.segs)
                    .map(e => ({
                        from: e.tStartMs / 1000,
                        to: (e.tStartMs + (e.dDurationMs || 0)) / 1000,
                        content: e.segs.map(s => s.utf8 || '').join('')
                    }))
                    .filter(s => s.content.trim().length > 0);
            } catch(e) { return []; }
        },

        _fmtSRTTime(t) {
            var h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60);
            var s = Math.floor(t % 60), ms = Math.floor((t % 1) * 1000);
            return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s + ',' + (ms < 100 ? '0' : '') + (ms < 10 ? '0' : '') + ms;
        },

        _toSRT(body) {
            return body.map(function(item, i) {
                var text = (item.content || '').split('\n')[0].trim();
                return (i + 1) + '\n' + this._fmtSRTTime(item.from) + ' --> ' + this._fmtSRTTime(item.to) + '\n' + text + '\n';
            }, this).join('\n');
        },

        // ---------- 字幕面板 ----------
        _subtitleStylesInjected: false,

        _injectSubtitleStyles() {
            if (this._subtitleStylesInjected) return;
            this._subtitleStylesInjected = true;
            const css = `
                .subtitle-panel {
                    position: fixed;
                    top: 15%;
                    right: 5%;
                    transform: translate(-50%, 0);
                    z-index: 100000;
                    font-size: 14px;
                    color: #333;
                }
                .subtitle-frame {
                    width: 300px; height: 60vh;
                    background: #fff; border: none; border-radius: 10px;
                    padding: 0px; box-shadow: 0 4px 12px rgba(0,0,0,0.25);
                    flex-direction: column; overflow: hidden; border: 1px solid #ddd;
                    position: relative;
                }
                @keyframes subtitle-spin { to { transform: rotate(360deg); } }
                .subtitle-header {
                    display: flex; justify-content: space-between; align-items: center;
                    padding: 7px 10px; background: #F1F4F7;
                    margin-bottom: 4px; cursor: move; user-select: none; flex-shrink: 0;
                    gap: 4px;
                }
                .subtitle-header select {
                    font-size:13px;color:#333;border:none;
                    border-radius:6px;cursor:pointer;outline:none;
                    max-width:200px;font-family:inherit;margin-right: auto;background: transparent;
                }
                .subtitle-close-btn {
                    cursor: pointer; color: #666; width: 20px; height: 20px;
                    display: flex; align-items: center; justify-content: center;
                    border-radius: 50%; font-size: 14px; transition: all 0.2s;
                    flex-shrink: 0; border: none; background: none;
                }
                .subtitle-close-btn:hover { background: #dadada; }
                .subtitle-content {
                    flex: 1; overflow: hidden; padding: 2px 0px 2px 12px;
                    line-height: 1.6; white-space: pre-wrap; font-size: 14px; color: #333;
                }
                .subtitle-text-area {
                    width: 100%; height: 100%; min-height: 200px; padding: 0; margin: 0;
                    overflow-y: auto; overflow-x: hidden;
                    border: none; background: transparent; border-radius: 0;
                    color: #333; font-size: 14px; line-height: 1.6; resize: none;
                    white-space: pre-wrap; word-wrap: break-word;
                    outline: none; font-family: inherit;
                }
                .subtitle-loading, .subtitle-empty {
                    display: flex; flex-direction: column; align-items: center;
                    justify-content: center; padding: 40px 20px; color: #999;min-height: 126px;
                }
                .subtitle-resizer {
                    position: absolute; right: 0; bottom: 0;
                    width: 14px; height: 14px; cursor: nwse-resize; z-index: 10;
                }
                .subtitle-spinner {
                    width: 28px; height: 28px; border: 2px solid rgba(0,0,0,0.1);
                    border-top-color: #FF0000; border-radius: 50%;
                    animation: subtitle-spin 0.8s linear infinite; margin-bottom: 12px;
                }
                .subtitle-footer {
                    display: flex; padding: 8px 4px;
                    flex-shrink: 0; justify-content: space-between;
                }
                .subtitle-btn {
                    width: 100%; flex: 1; padding: 4px 0;
                    border: none; border-radius: 6px; cursor: pointer;
                    font-size: 13px; color: #333; background: #ededed;
                    transition: background 0.15s;
                }
                .subtitle-btn:hover { background: #d1d1d6; }
                .subtitle-btn:disabled { opacity: 0.4; cursor: not-allowed; }
                .subtitle-toast {
                    position: fixed; top: 5%; left: 50%;
                    transform: translateX(-50%);
                    background: #3F7FEA; color: #fff; padding: 16px 18px;
                    min-height: 20px; min-width: 180px; line-height: 1.2;
                    border-radius: 13px; font-size: 14px;
                    font-family: sans-serif; z-index: 2147483647;
                    pointer-events: none; opacity: 0;
                    transition: opacity 0.25s ease;
                    box-shadow: 0 2px 8px rgba(0,122,255,0.25), 0 0 0 0.5px rgba(0,122,255,0.1);
                    box-sizing: border-box;
                    display: flex; align-items: center; justify-content: center;
                }
                .subtitle-toast.show { opacity: 1; }
                .subtitle-toast.error { background: #f44336; }
                .subtitle-text-area::-webkit-scrollbar,
                .subtitle-content::-webkit-scrollbar { width: 10px; }
                .subtitle-text-area::-webkit-scrollbar-track,
                .subtitle-content::-webkit-scrollbar-track { background: transparent; }
                .subtitle-text-area::-webkit-scrollbar-thumb,
                .subtitle-content::-webkit-scrollbar-thumb { background: #ccc; border-radius: 3px; }
                .subtitle-text-area::-webkit-scrollbar-thumb:hover,
                .subtitle-content::-webkit-scrollbar-thumb:hover { background: #aaa; }
                .subtitle-text-area { scrollbar-width: auto; scrollbar-color: #ccc transparent; }
                .subtitle-content { scrollbar-width: auto; scrollbar-color: #ccc transparent; }
            `;
            const styleEl = document.createElement('style');
            styleEl.textContent = css;
            document.head.appendChild(styleEl);
        },

        _showToast(message, isError = false) {
            let toast = document.querySelector('.subtitle-toast');
            if (!toast) {
                toast = document.createElement('div');
                toast.className = 'subtitle-toast';
                document.body.appendChild(toast);
            }
            toast.textContent = message;
            toast.classList.toggle('error', isError);
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 2500);
        },

        _setLoading(loading) {
            this._subState.isLoading = loading;
            this._updateSubContent();
        },

        // ---------- 统一获取字幕 ----------
        /** 按优先级选取最佳字幕：zh-CN → zh-TW → en → 其他 → 自动 */
        _pickBestSubtitle(tracks) {
            const find = (pred) => tracks.find(pred);
            const langMatch = (code) => (t) => {
                const l = t.lan?.toLowerCase();
                const d = (t.lan_doc || '').toLowerCase();
                return l === code || l.startsWith(code + '-') || l.startsWith(code + '_') || d.includes(code);
            };
            return find((t) => !t.isAuto && (langMatch('zh-cn')(t) || langMatch('zh-hans')(t) || t.lan_doc?.includes('Chinese (Simplified)') || t.lan_doc?.includes('Chinese(Simplified)')))
                || find((t) => !t.isAuto && (langMatch('zh-tw')(t) || langMatch('zh-hant')(t) || t.lan_doc?.includes('Chinese (Traditional)') || t.lan_doc?.includes('Chinese(Traditional)')))
                || find((t) => !t.isAuto && (langMatch('zh')(t) || t.lan_doc?.includes('Chinese')))
                || find((t) => !t.isAuto && (langMatch('en')(t) || t.lan === 'en'))
                || find((t) => !t.isAuto)
                || tracks[0];
        },

        async _fetchAllSubtitles(force = false) {
            const videoKey = this.getVideoId();
            const st = this._subState;
            if (!force && videoKey === st.currentVideoKey && st.allSubtitles.length > 0) return;

            st.currentVideoKey = videoKey;
            st.allSubtitles = [];
            st.currentSubtitleData = null;
            st.selectedSubtitleId = null;

            this._setLoading(true);
            try {
                st.allSubtitles = await this._fetchCaptionTracks();
                if (st.allSubtitles.length > 0) {
                    const best = this._pickBestSubtitle(st.allSubtitles);
                    await this._loadSubtitle(best);
                }
            } catch (e) { console.log('[U2B] 获取字幕出错:', e); }
            this._setLoading(false);
            this._updateSubUI();
        },

        async _loadSubtitle(subtitle) {
            if (!subtitle) return;
            const st = this._subState;
            st.selectedSubtitleId = subtitle.id;

            if (subtitle.body && subtitle.body.length > 0) {
                st.currentSubtitleData = subtitle;
                this._updateSubUI();
                this._updateSubContent();
                return;
            }

            this._setLoading(true);
            const body = await this._fetchSubtitleContent(subtitle.subtitle_url);
            subtitle.body = body;
            st.currentSubtitleData = subtitle;
            this._setLoading(false);
            this._updateSubUI();
            this._updateSubContent();
        },

        _getFormattedText() {
            const st = this._subState;
            if (!st.currentSubtitleData?.body) return '';
            return st.currentSubtitleData.body.map(item => item.content).join('\n');
        },

        // ---------- 创建面板 ----------
        _createSubPanel() {
            if (document.querySelector('.subtitle-panel')) return;
            this._injectSubtitleStyles();

            const container = document.createElement('div');
            container.className = 'subtitle-panel';
            this._safeHtml(container, `
                <div class="subtitle-frame">
                    <div class="subtitle-header">
                        <select id="subtitle-select"></select>
                        <button class="subtitle-close-btn" title="关闭">✕</button>
                    </div>
                    <div class="subtitle-content">
                        <div class="subtitle-empty">正在获取字幕</div>
                    </div>
                    <div class="subtitle-footer">
                        <div style="flex:1;margin:0 4px;position:relative;">
                            <button class="subtitle-btn" id="subtitle-ai-btn" disabled>AI 总结 ▾</button>
                        </div>
                        <div style="flex:1;margin:0 4px;position:relative;">
                            <button class="subtitle-btn" id="subtitle-download-btn" disabled>下载 ▾</button>
                        </div>
                    </div>
                    <div class="subtitle-resizer"></div>
                </div>
            `);
            document.body.appendChild(container);
            this._bindSubEvents(container);

            // 面板右下角缩放手柄
            const panelResizer = container.querySelector('.subtitle-resizer');
            if (panelResizer) {
                let panelResizing = false, panelStartX, panelStartY, panelStartW, panelStartH;
                panelResizer.addEventListener('mousedown', function(e) {
                    e.preventDefault(); e.stopPropagation();
                    panelResizing = true;
                    const rect = container.getBoundingClientRect();
                    panelStartX = e.clientX; panelStartY = e.clientY;
                    panelStartW = rect.width; panelStartH = rect.height;
                    if (container.style.transform !== 'none') {
                        container.style.transform = 'none';
                        container.style.left = rect.left + 'px';
                        container.style.top = rect.top + 'px';
                    }
                });
                document.addEventListener('mousemove', function(e) {
                    if (!panelResizing) return;
                    const dw = e.clientX - panelStartX, dh = e.clientY - panelStartY;
                    let newW = panelStartW + dw, newH = panelStartH + dh;
                    newW = Math.max(200, Math.min(newW, window.innerWidth - parseInt(container.style.left)));
                    newH = Math.max(200, Math.min(newH, window.innerHeight - parseInt(container.style.top)));
                    container.style.width = newW + 'px'; container.style.height = newH + 'px';
                    container.style.maxWidth = 'none'; container.style.maxHeight = 'none';
                    // 同步 .subtitle-frame 尺寸
                    const frame = container.querySelector('.subtitle-frame');
                    if (frame) { frame.style.width = newW + 'px'; frame.style.height = newH + 'px'; }
                });
                document.addEventListener('mouseup', function() { panelResizing = false; });
                document.addEventListener('mouseleave', function() { panelResizing = false; });
            }
        },

        _bindSubEvents(container) {
            const headerEl = container.querySelector('.subtitle-header');
            const panelEl = container.querySelector('.subtitle-frame');
            const closeBtn = container.querySelector('.subtitle-close-btn');
            const downloadBtn = container.querySelector('#subtitle-download-btn');
            const downloadWrap = downloadBtn?.parentElement;
            const aiBtn = container.querySelector('#subtitle-ai-btn');
            const aiWrap = aiBtn?.parentElement;

            // AI 总结预设提示词
            var aiPresets = [
                { text: '1、极简总结', prompt: '请总结以上内容：\n此外，我极度没有耐心，不想动脑子，且有阅读困难。请用最直接的大白话告诉我这段内容到底在讲什么，在能解释清楚的前提下，废话越少越好，禁止使用专业术语。请按以下顺序直接输出：1.【总结】\n直接告诉我核心意思；2.【详细】\n用极简的白话说明来龙去脉；3.【摘录】\n用无序列表列出最重要的几个要点。' },
                { text: '2、要点清单', prompt: '请将以上内容整理成简洁的要点清单，要求：1. 用 markdown 的项目符号格式；2. 每个点都简洁明了；3. 按重要性排序；4. 分类呈现（如适用）；5. 突出关键词或数字。' },
                { text: '3、表格总结', prompt: '请将以上内容的重点提取并整理成 markdown 表格，要求条理清晰，重点突出，易于阅读，表格应当包含以下列：主题、简介。' },
                { text: '4、学习笔记', prompt: '请基于以上内容，生成一份结构清晰的学习笔记，使用 Markdown 格式输出，包括：1.【主题】文章主题与核心论点；2.【大纲】用层级列表展示文章结构；3.【关键字】解释文章中出现的重要概念/术语；4.【金句】3-5条值得记录的金句语录。' },
                { text: '5、孩童解释', prompt: '请用简单易懂的语言解释以上内容，就像向一个五年级学生解释一样，解释要生动有趣，便于理解，但不能有失准确性。要求：1. 使用简单的词汇；2. 多用比喻和类比；3. 避免专业术语；4. 循序渐进地解释。' },
                { text: '6、幽默解释', prompt: '请用轻松幽默的语气总结这段内容，幽默要得体，不失专业性，使用markdown格式。要求：1. 口语化表达；2. 适当使用梗和比喻；3. 保持内容准确性；4. 增加趣味性类比。' },
                { text: '7、生成 SVG', prompt: '请仔细阅读以上内容，并按照以下步骤创建一个引人入胜且信息丰富的SVG知识图解：\n1. 分析阶段：\n• 识别并提取文章中的核心概念、关键观点和它们之间的逻辑关系。\n• 确定最适合表达这些内容的图解类型（思维导图、流程图、概念图、比较图等）。\n• 考虑目标受众和他们的认知需求。\n2. 设计阶段：\n• 创建清晰的视觉层次结构，突出最重要的信息。\n• 使用适当的视觉隐喻和符号，使抽象概念更容易理解。\n• 应用一致的配色方案（2-5 种互补色），增强可读性和美感。\n• 平衡文字与视觉元素，确保简洁性和完整性。\n• 使用视觉分组、对比和空间关系传达概念间的联系。\n3. 优化阶段：\n• 简化复杂信息，去除不必要的细节。\n• 确保图解自成一体，无需原文也能传达完整信息。\n• 验证图解是否准确反映了原文的核心思想\n请使用SVG格式创建这个知识图解，确保它既能独立传达核心信息，又能以视觉上吸引人的方式呈现。图解应该是概念性的，而不仅是文本内容的重新排列。' },
                { text: '8、生成 PPT', prompt: '请基于以上内容生成一个可直接保存为 .html 的完整 HTML PPT。\n硬性要求：\n1. 只输出完整 HTML 文档，从 <!doctype html> 或 <html> 开始，不要 Markdown 代码块，不要解释。\n2. 必须做成真正的翻页演示稿，不要输出普通文章排版。\n3. 每页必须图文并茂：使用 CSS 图形、SVG、图标、流程图、卡片、对比表、时间线、指标块等视觉元素。\n4. 可以使用内联 CSS、内联 SVG、emoji、少量内联 JS；如使用外部图片/字体/CDN，必须有纯 CSS/SVG 降级，不能依赖外部资源才能看。\n5. 视觉风格要现代、清晰、适合全屏演示。' },
                { text: '9、生成 HTML', prompt: '请基于以上内容生成一个可以直接保存为 .html 的可视化总结页面。\n硬性要求：\n1. 只输出完整 HTML 文档，从 <!doctype html> 或 <html> 开始，不要 Markdown 代码块，不要解释。\n2. 页面必须信息密度高，不能只有空白卡片、空标题、占位符或无正文。\n3. 必须图文并茂：使用 CSS 图形、SVG、图标、流程图、卡片、对比表、时间线、指标块等视觉元素。\n4. 可以使用内联 CSS、内联 SVG、emoji、少量内联 JS；如使用外部图片/字体/CDN，必须有纯 CSS/SVG 降级，不能依赖外部资源才能看。\n5. 视觉风格要现代、清晰、适合全屏查看，不要输出普通文章排版。' },
            ];
            var aiPlatform = 'doubao'; // 当前选择的 AI 平台
            if (typeof GM_getValue === 'function') {
                var saved = GM_getValue('ytb_ai_platform', '');
                if (saved) aiPlatform = saved;
            }

            this._fetchAllSubtitles();
            panelEl.style.display = 'flex';

            // 拖动功能
            let isDragging = false;
            let offsetX, offsetY;

            headerEl.onmousedown = function(e) {
                if (e.target.tagName === 'SELECT') return;
                isDragging = true;
                const rect = container.getBoundingClientRect();
                offsetX = e.clientX - rect.left;
                offsetY = e.clientY - rect.top;
                container.style.transform = 'none';
                container.style.left = rect.left + 'px';
                container.style.top = rect.top + 'px';
                e.preventDefault();
            };

            document.addEventListener('mousemove', function(e) {
                if (!isDragging) return;
                let newLeft = e.clientX - offsetX;
                let newTop = e.clientY - offsetY;
                const rect = container.getBoundingClientRect();
                newLeft = Math.max(0, Math.min(newLeft, window.innerWidth - rect.width));
                newTop = Math.max(0, Math.min(newTop, window.innerHeight - rect.height));
                container.style.left = newLeft + 'px';
                container.style.top = newTop + 'px';
            });

            document.addEventListener('mouseup', function() { isDragging = false; });
            document.addEventListener('mouseleave', function() { isDragging = false; });

            closeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                container.style.display = 'none';
            });

            // 下载菜单（SRT / TXT / 复制）
            if (downloadBtn && downloadWrap) {
                downloadBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const old = document.getElementById('subtitle-dl-menu');
                    if (old) { old.remove(); return; }
                    const menu = document.createElement('div');
                    menu.id = 'subtitle-dl-menu';
                    menu.style.cssText = 'position:absolute;bottom:100%;left:0;right:0;background:#fff;border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,0.2);padding:4px;z-index:999;margin-bottom:4px;';
                    // SRT
                    const srtOpt = document.createElement('div');
                    srtOpt.textContent = 'SRT 字幕';
                    srtOpt.style.cssText = 'padding:6px 8px;border-radius:4px;cursor:pointer;font-size:13px;color:#333;';
                    srtOpt.onmouseover = function() { this.style.background = '#f0f0f0'; };
                    srtOpt.onmouseout = function() { this.style.background = ''; };
                    srtOpt.onclick = (e) => {
                        e.stopPropagation();
                        menu.remove();
                        const body = this._subState.currentSubtitleData?.body;
                        if (!body) { showToast('暂无字幕数据'); return; }
                        const srt = this._toSRT(body);
                        const blob = new Blob([srt], {type: 'text/plain;charset=utf-8'});
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = document.title.replace(/[\\/:*?"<>|]/g, '_') + '.srt';
                        document.body.appendChild(a); a.click(); a.remove();
                        URL.revokeObjectURL(url);
                    };
                    menu.appendChild(srtOpt);
                    // TXT
                    const txtOpt = document.createElement('div');
                    txtOpt.textContent = 'TXT 字幕';
                    txtOpt.style.cssText = 'padding:6px 8px;border-radius:4px;cursor:pointer;font-size:13px;color:#333;';
                    txtOpt.onmouseover = function() { this.style.background = '#f0f0f0'; };
                    txtOpt.onmouseout = function() { this.style.background = ''; };
                    txtOpt.onclick = (e) => {
                        e.stopPropagation();
                        menu.remove();
                        const text = this._getFormattedText();
                        if (!text) { showToast('暂无字幕数据'); return; }
                        const blob = new Blob([text], {type: 'text/plain;charset=utf-8'});
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = document.title.replace(/[\\/:*?"<>|]/g, '_') + '.txt';
                        document.body.appendChild(a); a.click(); a.remove();
                        URL.revokeObjectURL(url);
                    };
                    menu.appendChild(txtOpt);
                    // 复制字幕
                    const cpyOpt = document.createElement('div');
                    cpyOpt.textContent = '复制 字幕';
                    cpyOpt.style.cssText = 'padding:6px 8px;border-radius:4px;cursor:pointer;font-size:13px;color:#333;';
                    cpyOpt.onmouseover = function() { this.style.background = '#f0f0f0'; };
                    cpyOpt.onmouseout = function() { this.style.background = ''; };
                    cpyOpt.onclick = (e) => {
                        e.stopPropagation();
                        menu.remove();
                        const text = this._getFormattedText();
                        if (text) {
                            navigator.clipboard.writeText(text).then(() => {
                                this._showToast('✓ 已复制到剪贴板');
                            }).catch(() => {
                                try {
                                    const el = document.createElement('textarea');
                                    el.value = text;
                                    el.style.position = 'fixed';
                                    el.style.opacity = '0';
                                    document.body.appendChild(el);
                                    el.select();
                                    document.execCommand('copy');
                                    el.remove();
                                    this._showToast('✓ 已复制到剪贴板');
                                } catch(e) {}
                            });
                        }
                    };
                    menu.appendChild(cpyOpt);
                    downloadWrap.appendChild(menu);
                    menu.addEventListener('click', function(e) { e.stopPropagation(); });
                });
            }

            // AI 总结菜单
            if (aiBtn && aiWrap) {
                const _viewer = this;
                aiBtn.disabled = false;
                function showAIMenu() {
                    const old = document.getElementById('subtitle-ai-menu');
                    if (old) old.remove();
                    const menu = document.createElement('div');
                    menu.id = 'subtitle-ai-menu';
                    menu.style.cssText = 'position:absolute;bottom:100%;left:0;right:0;background:#fff;border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,0.2);padding:4px;z-index:999;margin-bottom:4px;';
                    aiPresets.forEach(p => {
                        const opt = document.createElement('div');
                        opt.textContent = p.text;
                        opt.style.cssText = 'padding:6px 8px;border-radius:4px;cursor:pointer;font-size:13px;color:#333;';
                        opt.onmouseover = function() { this.style.background = '#f0f0f0'; };
                        opt.onmouseout = function() { this.style.background = ''; };
                        opt.onclick = function(e) {
                            e.stopPropagation();
                            menu.remove();
                            // 优先从 textarea DOM 读取
                            var textArea = document.querySelector('.subtitle-text-area');
                            var text = textArea ? textArea.value : '';
                            if (!text) {
                                text = _viewer._getFormattedText();
                            }
                            if (!text) {
                                _viewer._showToast('请等待字幕加载完成后再试', true);
                                return;
                            }
                            var content = text + '\n\n' + p.prompt;
                            var info = platformInfo[aiPlatform] || { label: '豆包', url: 'https://www.doubao.com/chat/' };
                            var toastMsg = '已复制字幕到剪贴板，正在打开 ' + info.label;
                            // 方式一：clipboard API（异步）
                            navigator.clipboard.writeText(content).then(function() {
                                _viewer._showToast(toastMsg);
                                if (typeof GM_setValue === 'function') {
                                    GM_setValue('ytb_ai_pending', JSON.stringify({
                                        prompt: content,
                                        platform: aiPlatform,
                                        createdAt: Date.now()
                                    }));
                                }
                                setTimeout(function() { window.open(info.url, '_blank'); }, 1000);
                            }).catch(function() {
                                // 方式二：execCommand 同步复制
                                var copied = false;
                                try {
                                    var el = document.createElement('textarea');
                                    el.value = content;
                                    el.style.cssText = 'position:fixed;left:0;top:0;width:0;height:0;opacity:0;';
                                    document.body.appendChild(el);
                                    el.focus();
                                    el.select();
                                    copied = document.execCommand('copy');
                                    el.remove();
                                } catch(e2) {}
                                if (copied) {
                                    _viewer._showToast(toastMsg);
                                } else {
                                    _viewer._showToast('复制失败，请手动复制', true);
                                }
                                if (typeof GM_setValue === 'function') {
                                    GM_setValue('ytb_ai_pending', JSON.stringify({
                                        prompt: content,
                                        platform: aiPlatform,
                                        createdAt: Date.now()
                                    }));
                                }
                                setTimeout(function() { window.open(info.url, '_blank'); }, 500);
                            });
                        };
                        menu.appendChild(opt);
                    });
                    // 自定义提示词
                    var customPrompts = [];
                    if (typeof GM_getValue === 'function') {
                        try { customPrompts = JSON.parse(GM_getValue('ytb_custom_prompts', '[]')); } catch(e) {}
                    }
                    customPrompts.forEach(function(cp) {
                        var opt = document.createElement('div');
                        opt.style.cssText = 'padding:6px 8px;border-radius:4px;cursor:pointer;font-size:13px;color:#333;display:flex;align-items:center;';
                        opt.onmouseover = function() { this.style.background = '#f0f0f0'; };
                        opt.onmouseout = function() { this.style.background = ''; };
                        var label = document.createElement('span');
                        label.style.cssText = 'flex:1;';
                        label.textContent = cp.text;
                        opt.appendChild(label);
                        var delBtn = document.createElement('span');
                        delBtn.textContent = '✕';
                        delBtn.style.cssText = 'color:#999;cursor:pointer;padding:0 2px;font-size:12px;flex-shrink:0;';
                        delBtn.onmouseover = function() { this.style.color = '#e00'; };
                        delBtn.onmouseout = function() { this.style.color = '#999'; };
                        delBtn.onclick = function(e) {
                            e.stopPropagation();
                            menu.remove();
                            var idx = customPrompts.indexOf(cp);
                            if (idx !== -1) {
                                customPrompts.splice(idx, 1);
                                if (typeof GM_setValue === 'function') {
                                    GM_setValue('ytb_custom_prompts', JSON.stringify(customPrompts));
                                }
                            }
                            _viewer._showToast('已删除提示词');
                            showAIMenu();
                        };
                        opt.appendChild(delBtn);
                        opt.onclick = function(e) {
                            e.stopPropagation();
                            menu.remove();
                            var textArea = document.querySelector('.subtitle-text-area');
                            var text = textArea ? textArea.value : '';
                            if (!text) {
                                text = _viewer._getFormattedText();
                            }
                            var content = text + '\n\n' + cp.prompt;
                            var info = platformInfo[aiPlatform] || { label: '豆包', url: 'https://www.doubao.com/chat/' };
                            var toastMsg = '已复制到剪贴板，正在打开 ' + info.label;
                            navigator.clipboard.writeText(content).then(function() {
                                _viewer._showToast(toastMsg);
                                if (typeof GM_setValue === 'function') {
                                    GM_setValue('ytb_ai_pending', JSON.stringify({
                                        prompt: content,
                                        platform: aiPlatform,
                                        createdAt: Date.now()
                                    }));
                                }
                                setTimeout(function() { window.open(info.url, '_blank'); }, 1000);
                            }).catch(function() {
                                var el = document.createElement('textarea');
                                el.value = content;
                                el.style.cssText = 'position:fixed;left:0;top:0;width:0;height:0;opacity:0;';
                                document.body.appendChild(el);
                                el.focus();
                                el.select();
                                var copied = document.execCommand('copy');
                                el.remove();
                                if (copied) {
                                    _viewer._showToast(toastMsg);
                                } else {
                                    _viewer._showToast('复制失败，请手动复制', true);
                                }
                                if (typeof GM_setValue === 'function') {
                                    GM_setValue('ytb_ai_pending', JSON.stringify({
                                        prompt: content,
                                        platform: aiPlatform,
                                        createdAt: Date.now()
                                    }));
                                }
                                setTimeout(function() { window.open(info.url, '_blank'); }, 500);
                            });
                        };
                        menu.appendChild(opt);
                    });
                    // 添加提示词选项
                    var addOpt = document.createElement('div');
                    addOpt.textContent = '＋ 添加提示词';
                    addOpt.style.cssText = 'padding:6px 8px;border-radius:4px;cursor:pointer;font-size:13px;color:#333;';
                    addOpt.onmouseover = function() { this.style.background = '#f0f0f0'; };
                    addOpt.onmouseout = function() { this.style.background = ''; };
                    addOpt.onclick = function(e) {
                        e.stopPropagation();
                        menu.remove();
                        var label = prompt('请输入提示词名称：');
                        if (!label || !label.trim()) return;
                        var promptText = prompt('请输入提示词内容：');
                        if (!promptText || !promptText.trim()) return;
                        if (typeof GM_getValue === 'function') {
                            var list = [];
                            try { list = JSON.parse(GM_getValue('ytb_custom_prompts', '[]')); } catch(e2) {}
                            list.push({ text: label.trim(), prompt: promptText.trim() });
                            GM_setValue('ytb_custom_prompts', JSON.stringify(list));
                        }
                        _viewer._showToast('已添加提示词');
                        showAIMenu();
                    };
                    menu.appendChild(addOpt);
                    // 平台下拉选择
                    var selectWrap = document.createElement('div');
                    selectWrap.style.cssText = 'padding:1px 1px;display:flex;align-items:center;gap:4px;';
                    var select = document.createElement('select');
                    select.style.cssText = 'flex:1;padding:3px 4px;border:1px solid #ddd;border-radius:4px;font-size:12px;outline:none;cursor:pointer;background:#fff;text-align:center;';
                    var platOrder = ['doubao', 'qianwen', 'deepseek', 'chatgpt', 'gemini'];
                    platOrder.forEach(function(key) {
                        var opt = document.createElement('option');
                        opt.value = key;
                        opt.textContent = platformInfo[key].label;
                        select.appendChild(opt);
                    });
                    select.value = aiPlatform;
                    select.onchange = function(e) {
                        e.stopPropagation();
                        aiPlatform = select.value;
                        if (typeof GM_setValue === 'function') {
                            GM_setValue('ytb_ai_platform', select.value);
                        }
                    };
                    selectWrap.appendChild(select);
                    menu.appendChild(selectWrap);
                    aiWrap.appendChild(menu);
                    menu.addEventListener('click', function(e) { e.stopPropagation(); });
                }
                aiBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const old = document.getElementById('subtitle-ai-menu');
                    if (old) { old.remove(); return; }
                    showAIMenu();
                });

                // 点击页面其他位置关闭所有弹出菜单
                if (!document._subtitleClickBound) {
                    document._subtitleClickBound = true;
                    document.addEventListener('click', function() {
                        var m = document.getElementById('subtitle-ai-menu');
                        if (m) m.remove();
                        m = document.getElementById('subtitle-dl-menu');
                        if (m) m.remove();
                    });
                }
            }
        },

        _updateSubUI() {
            const st = this._subState;
            const downloadBtn = document.querySelector('#subtitle-download-btn');
            const aiBtn = document.querySelector('#subtitle-ai-btn');
            const subtitleSelect = document.querySelector('#subtitle-select');

            if (subtitleSelect) {
                if (st.allSubtitles.length > 0) {
                    const html = st.allSubtitles.map(sub => {
                        const selected = sub.id === st.selectedSubtitleId ? 'selected' : '';
                        return `<option value="${sub.id}" ${selected}>${sub.lan_doc}</option>`;
                    }).join('');
                    this._safeHtml(subtitleSelect, html);
                    subtitleSelect.onchange = () => {
                        const sub = st.allSubtitles.find(s => s.id == subtitleSelect.value);
                        if (sub) this._loadSubtitle(sub);
                    };
                } else {
                    this._safeHtml(subtitleSelect, '<option value="">暂无字幕</option>');
                }
            }

            if (downloadBtn) downloadBtn.disabled = false;
            if (aiBtn) aiBtn.disabled = false;
        },

        _updateSubContent() {
            const st = this._subState;
            const content = document.querySelector('.subtitle-content');
            if (!content) return;

            if (st.isLoading) {
                this._safeHtml(content, '<div class="subtitle-loading"><div class="subtitle-spinner"></div><div>正在获取字幕...</div></div>');
                return;
            }

            if (!st.currentSubtitleData?.body) {
                this._safeHtml(content, '<div class="subtitle-empty">当前视频没有字幕</div>');
                return;
            }

            this._safeHtml(content, `<textarea class="subtitle-text-area">${this._escHtml(this._getFormattedText())}</textarea>`);
        },

        // ===== 主入口：按钮点击后调用 =====
        async showSubtitleInPanel() {
            const existing = document.querySelector('.subtitle-panel');
            if (existing) {
                existing.style.display = existing.style.display === 'none' ? 'block' : 'none';
                if (existing.style.display !== 'none') {
                    this._fetchAllSubtitles();
                }
                return;
            }
            // 初始化 Trusted Types
            if (window.trustedTypes && window.trustedTypes.createPolicy && !this._trustedPolicy) {
                try {
                    this._trustedPolicy = window.trustedTypes.createPolicy('u2bPolicy', {
                        createHTML: (string) => string
                    });
                } catch (e) {}
            }
            this._createSubPanel();
        },

        // 打开snapany.com下载视频并复制链接
        openDownloadPage() {
            const currentUrl = window.location.href;
            navigator.clipboard.writeText(currentUrl).then(() => {
                this.showToast('已复制视频地址，正在打开下载页面!');
                setTimeout(() => {
                  window.open('https://snapwc.com/zh', '_blank');
                }, 500);
            }).catch(err => {
                console.error('复制失败:', err);
                this.showToast('前往下载页面');
                window.open('https://snapwc.com/zh', '_blank');
            });
        },

        // 显示提示消息
        showToast(message) {
            var el = document.getElementById('u2b-toast');
            if (!el) {
                el = document.createElement('div');
                el.id = 'u2b-toast';
                el.style.cssText = 'position:fixed;top:5%;left:50%;transform:translateX(-50%);background:#3F7FEA;color:#fff;padding:16px 18px;min-height:20px;min-width:180px;line-height:1.2;border-radius:13px;font-size:14px;font-family:sans-serif;z-index:2147483647;pointer-events:none;opacity:0;transition:opacity 0.25s ease;box-shadow:0 2px 8px rgba(0,122,255,0.25),0 0 0 0.5px rgba(0,122,255,0.1);box-sizing:border-box;display:flex;align-items:center;justify-content:center;';
                document.body.appendChild(el);
            }
            el.textContent = message;
            el.style.opacity = '1';
            clearTimeout(el._timer);
            el._timer = setTimeout(function() { el.style.opacity = '0'; }, 2000);
        },

        // 添加字幕和缩略图按钮到YouTube logo右边
        addButtons() {
            if (elements.getAs('#yt-subtitle-btn') && elements.getAs('#yt-thumbnail-btn') && elements.getAs('#yt-download-btn')) {
                return;
            }

            // 查找YouTube topbar logo元素
            const logoElement = elements.getAs('ytd-masthead ytd-topbar-logo-renderer') ||
                               elements.getAs('ytd-masthead #logo') ||
                               elements.getAs('ytd-topbar-logo-renderer') ||
                               elements.getAs('#masthead-logo');

            if (!logoElement) {
                console.log('找不到YouTube logo元素');
                return;
            }

            // 创建按钮容器
            let buttonContainer = elements.getAs('#yt-helper-buttons');
            if (!buttonContainer) {
                buttonContainer = elements.createAs('div', {
                    id: 'yt-helper-buttons',
                    style: `
                        display: flex;
                        align-items: center;
                        margin-left: 0px;
                        overflow: visible;
                    `
                });

                // 将按钮容器插入到logo的父元素中
                const logoParent = logoElement.parentElement;
                if (logoParent) {
                    logoParent.style.display = 'flex';
                    logoParent.style.alignItems = 'center';
                    logoParent.style.overflow = 'visible';
                    logoParent.insertBefore(buttonContainer, logoElement.nextSibling);
                }
            }

            // 创建缩略图按钮 - 只在视频页面显示
            if (!elements.getAs('#yt-thumbnail-btn') && this.isVideoPage() && this.getVideoId()) {
                const thumbnailBtn = elements.createAs('a', {
                    id: 'yt-thumbnail-btn',
                    href: 'javascript:void(0);',
                    className: 'yt-icon-btn yt-thumbnail-btn',
                    title: '点击查看/隐藏视频缩略图',
                    innerHTML: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M6.002 5.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/><path d="M2.002 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2h-12zm12 1a1 1 0 0 1 1 1v6.5l-3.777-1.947a.5.5 0 0 0-.577.093l-3.71 3.71-2.66-1.772a.5.5 0 0 0-.63.062L1.002 12V3a1 1 0 0 1 1-1h12z"/></svg>',
                    onclick: (e) => this.toggleThumbnailPreview(e)
                }, buttonContainer);
            }

            // 创建字幕按钮 - 只在视频页面显示
            if (!elements.getAs('#yt-subtitle-btn') && this.isVideoPage() && this.getVideoId()) {
                const subtitleBtn = elements.createAs('a', {
                    id: 'yt-subtitle-btn',
                    href: 'javascript:void(0);',
                    className: 'yt-icon-btn yt-subtitle-btn',
                    title: '获取视频字幕',
                    innerHTML: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.5a1 1 0 0 0-.8.4l-1.9 2.533a1 1 0 0 1-1.6 0L5.3 12.4a1 1 0 0 0-.8-.4H2a2 2 0 0 1-2-2V2zm7.194 2.766a1.688 1.688 0 0 0-.227-.272 1.467 1.467 0 0 0-.469-.324l-.008-.004A1.785 1.785 0 0 0 5.734 4C4.776 4 4 4.746 4 5.667c0 .92.776 1.666 1.734 1.666.343 0 .662-.095.931-.26-.137.389-.39.804-.81 1.22a.405.405 0 0 0 .011.59c.173.16.447.155.614-.01 1.334-1.329 1.37-2.758.941-3.706a2.461 2.461 0 0 0-.227-.4zM11 7.073c-.136.389-.39.804-.81 1.22a.405.405 0 0 0 .012.59c.172.16.446.155.613-.01 1.334-1.329 1.37-2.758.942-3.706a2.466 2.466 0 0 0-.228-.4 1.686 1.686 0 0 0-.227-.273 1.466 1.466 0 0 0-.469-.324l-.008-.004A1.785 1.785 0 0 0 10.07 4c-.957 0-1.734.746-1.734 1.667 0 .92.777 1.666 1.734 1.666.343 0 .662-.095.931-.26z"/></svg>',
                    onclick: () => this.showSubtitleInPanel()
                }, buttonContainer);
            }

            // 创建下载按钮 - 只在视频页面显示
            if (!elements.getAs('#yt-download-btn') && this.isVideoPage() && this.getVideoId()) {
                const _viewer = this;
                const downloadBtn = elements.createAs('a', {
                    id: 'yt-download-btn',
                    href: 'javascript:void(0);',
                    className: 'yt-icon-btn yt-download-btn',
                    title: '左键: yt-dlp 命令生成 | 右键: snapany.com 下载',
                    innerHTML: '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14"><path fill="currentColor" fill-rule="evenodd" d="M7 14A7 7 0 1 0 7 0a7 7 0 0 0 0 14m3.146-5.69l-2.793 2.793a.5.5 0 0 1-.707 0L3.854 8.31a.5.5 0 0 1 .353-.853H6V3.75a1 1 0 0 1 2 0v3.707h1.793a.5.5 0 0 1 .353.853" clip-rule="evenodd"/></svg>',
                    onclick: function(e) {
                        e.preventDefault();
                        runYtDlpBm();
                    },
                    oncontextmenu: function(e) {
                        e.preventDefault();
                        _viewer.openDownloadPage();
                    }
                }, buttonContainer);
            }

            this.buttonAdded = true;
            console.log('YouTube浏览助手按钮检查完成');
        },

        // 显示缩略图预览
        showThumbnailPreview(event) {
            const thumbnailUrl = this.getThumbnailUrl();
            if (thumbnailUrl) {
                preview.src = thumbnailUrl;
                const rect = event.currentTarget.getBoundingClientRect();
                preview.style.left = (rect.right + 10) + 'px';
                preview.style.top = rect.top + 'px';
                preview.style.width = 'auto';
                preview.style.height = 'auto';

                preview.onload = () => {
                    const screenWidth = window.innerWidth * 0.6;
                    const screenHeight = window.innerHeight * 0.6;

                    if (preview.naturalWidth > screenWidth || preview.naturalHeight > screenHeight) {
                        const widthRatio = screenWidth / preview.naturalWidth;
                        const heightRatio = screenHeight / preview.naturalHeight;
                        const ratio = Math.min(widthRatio, heightRatio);
                        preview.style.width = (preview.naturalWidth * ratio) + 'px';
                        preview.style.height = (preview.naturalHeight * ratio) + 'px';
                    }

                    const previewRect = preview.getBoundingClientRect();
                    if (previewRect.right > window.innerWidth) {
                        preview.style.left = (rect.left - previewRect.width - 10) + 'px';
                    }
                    if (previewRect.bottom > window.innerHeight) {
                        preview.style.top = (window.innerHeight - previewRect.height - 10) + 'px';
                    }

                    preview.style.display = 'block';
                };
            }
        },

        // 隐藏缩略图预览
        hideThumbnailPreview() {
            preview.style.display = 'none';
        },

        // 点击切换缩略图预览的显示与隐藏
        toggleThumbnailPreview(event) {
            if (preview.style.display === 'block') {
                this.hideThumbnailPreview();
            } else {
                const thumbnailUrl = this.getThumbnailUrl();
                if (thumbnailUrl) {
                    this.showThumbnailPreview(event);
                } else {
                    this.showToast('无法获取视频缩略图');
                }
            }
        },

        // 清理按钮
        cleanupButtons() {
            const subtitleBtn = elements.getAs('#yt-subtitle-btn');
            const thumbnailBtn = elements.getAs('#yt-thumbnail-btn');
            const downloadBtn = elements.getAs('#yt-download-btn');

            if (subtitleBtn) {
                subtitleBtn.remove();
            }
            if (thumbnailBtn) {
                thumbnailBtn.remove();
            }
            if (downloadBtn) {
                downloadBtn.remove();
            }
        },

        // 重置状态
        reset() {
            this.buttonAdded = false;
            this.videoId = null;
            if (this.buttonCheckInterval) {
                clearInterval(this.buttonCheckInterval);
                this.buttonCheckInterval = null;
            }
        },

        // 启动按钮检查
        startButtonCheck() {
            if (this.buttonCheckInterval) {
                clearInterval(this.buttonCheckInterval);
            }

            this.buttonCheckInterval = setInterval(() => {
                // 在视频页面检查按钮是否存在
                if (this.isVideoPage() && this.getVideoId()) {
                    if (!elements.getAs('#yt-subtitle-btn') || !elements.getAs('#yt-thumbnail-btn') || !elements.getAs('#yt-download-btn')) {
                        console.log('视频页面按钮已消失，重新添加');
                        this.addButtons();
                    }
                } else {
                    // 不在视频页面时清理按钮
                    this.cleanupButtons();
                }
            }, 2000);
        },

        // 初始化
        init() {
            // 无论在哪个页面都启动检查
            this.addButtons();
            this.startButtonCheck();
            console.log('YouTube浏览助手初始化成功');

            // 监听页面变化
            let lastUrl = location.href;
            new MutationObserver(() => {
                if (lastUrl !== location.href) {
                    lastUrl = location.href;
                    console.log('页面URL变化:', lastUrl);

                    // 延迟处理，等待页面元素加载
                    setTimeout(() => {
                        this.videoId = this.getVideoId();
                        this.addButtons();
                    }, 1000);
                }
            }).observe(document.body, {
                childList: true,
                subtree: true
            });
        }
    };

    // 等待页面加载完成后初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => youtubeViewer.init(), 1000);
        });
    } else {
        setTimeout(() => youtubeViewer.init(), 1000);
    }
})();